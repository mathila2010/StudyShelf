'use strict';
// Usage: npm run create-admin -- "Name" email@example.com "password"
// Creates an administrator, or promotes an existing account and sets its password.
const { db, now } = require('../server/db');
const A = require('../server/auth');

const [name, email, password] = process.argv.slice(2);
if (!name || !email || !password) { console.error('Usage: npm run create-admin -- "Name" email@example.com "password"'); process.exit(1); }
const prob = A.passwordProblem(password); if (prob) { console.error(prob); process.exit(1); }
const e = email.trim().toLowerCase();
const u = db.prepare('SELECT id FROM users WHERE email=?').get(e);
if (u) db.prepare("UPDATE users SET role='admin', disabled=0, password_hash=?, name=? WHERE id=?").run(A.hashPassword(password), name, u.id);
else db.prepare("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,'admin',?)").run(name, e, A.hashPassword(password), now());
console.log(`${u ? 'Updated' : 'Created'} administrator ${e}`);
