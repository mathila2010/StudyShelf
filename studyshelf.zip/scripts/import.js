'use strict';
// Usage: npm run import — re-reads every file in sources/ and updates the library.
const { doImport } = require('../server/routes/admin');
doImport(null).then(({ runId, summary }) => {
  console.log(`Import #${runId}: ${summary.lessons} lessons (${summary.created} new, ${summary.updated} updated, ${summary.skipped} kept because an admin edited them)`);
  console.log(`${summary.errors} errors, ${summary.warnings} warnings, ${summary.duplicates} duplicates merged. Details: Admin → Import.`);
}).catch(e => { console.error(e.message); process.exit(1); });
