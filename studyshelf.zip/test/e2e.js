// End-to-end walkthrough with Playwright (run against a running server).
// Usage: BASE=http://localhost:3000 ADMIN=admin@example.com:password SHOTS=/tmp/shots node test/e2e.js
const { chromium } = require('playwright');
const assert = require('assert');
const BASE = process.env.BASE || 'http://localhost:3000';
const [AE, AP] = (process.env.ADMIN || 'admin@example.com:admin12345').split(':');
const SHOTS = process.env.SHOTS || '';

(async () => {
  const browser = await chromium.launch();
  const errors = [];
  const results = [];
  const step = async (name, fn) => {
    try { await fn(); results.push(['ok', name]); }
    catch (e) { results.push(['FAIL', name, e.message.split('\n')[0]]); }
  };
  async function newPage(vp = { width: 1366, height: 900 }) {
    const ctx = await browser.newContext({ viewport: vp });
    const p = await ctx.newPage();
    p.on('pageerror', e => errors.push(`${p.url()} PAGEERROR ${e.message}`));
    p.on('console', m => { if (m.type() === 'error' && !/favicon|401|404|409|400/.test(m.text())) errors.push(`${p.url()} ${m.text().slice(0, 200)}`); });
    return p;
  }
  const shot = async (p, n) => { if (SHOTS) await p.screenshot({ path: `${SHOTS}/${n}.png`, fullPage: false }); };
  const email = `student${Date.now()}@example.com`;

  const p = await newPage();
  await step('guest home loads', async () => { await p.goto(BASE); await p.waitForSelector('.welcome h1'); });
  await step('guest can read a free lesson', async () => { await p.goto(BASE + '/lessons/history-g10-c01'); await p.waitForSelector('#noteBody h2'); });
  await step('history activity mounts', async () => { await p.waitForSelector('.sh-ix .wh h3', { timeout: 8000 }); });
  await step('guest blocked from locked lesson', async () => { await p.goto(BASE + '/lessons/history-g10-c02'); await p.waitForSelector('text=Log in to read this note'); });
  await step('search works for guests', async () => { await p.goto(BASE + '/notes?q=isotope'); await p.waitForSelector('.result'); });

  await step('sign up', async () => {
    await p.goto(BASE + '/signup');
    await p.fill('#name', 'Kavindi'); await p.fill('#email', email); await p.fill('#password', 'short');
    await p.click('button[type=submit]'); await p.waitForSelector('.error-box');
    await p.fill('#password', 'revise2026');
    await p.check('input[name=subjects][value=science]', { force: true });
    await p.click('button[type=submit]'); await p.waitForSelector('.greet h1');
    assert((await p.textContent('.greet h1')).includes('Kavindi'));
  });
  await shot(p, 'dashboard-new');
  await step('read lesson, switch tabs, mini-lab mounts', async () => {
    await p.goto(BASE + '/lessons/science-g10-c02');
    await p.waitForSelector('#noteBody h2');
    await p.waitForSelector('.sh-ix input[type=range], .sh-ix button, .sh-ix canvas', { timeout: 8000 });
    await p.click('.note-tabs [role=tab]:nth-child(2)');
    await p.waitForFunction(() => location.search.includes('tab=detailed'));
    await p.waitForSelector('#noteBody figure');
  });
  await shot(p, 'lesson-detailed');
  await step('bookmark, favourite, complete, revise', async () => {
    await p.click('#bmBtn'); await p.waitForSelector('#bmBtn[aria-pressed=true]');
    await p.click('#favBtn'); await p.waitForSelector('#favBtn[aria-pressed=true]');
    await p.click('#doneBtn'); await p.waitForSelector('#doneBtn:has-text("Completed")');
    await p.click('#reviseBtn'); await p.waitForSelector('#reviseBtn[aria-pressed=true]');
  });
  await step('text-to-speech panel opens', async () => { await p.click('#ttsBtn'); await p.waitForSelector('#ttsBar:not([hidden]) #tts-play'); });
  await step('lesson quiz: answer all, score saved', async () => {
    await p.goto(BASE + '/lessons/science-g10-c02/quiz'); await p.waitForSelector('.qopt');
    for (let i = 0; i < 30; i++) {
      await p.waitForSelector('.score-big, .qopt:not([disabled])');
      if (await p.$('.score-big')) break;
      await p.click('.qopt >> nth=0'); await p.click('#qnext');
    }
    await p.waitForSelector('.score-big'); await p.waitForSelector('text=Saved to your progress');
  });
  await shot(p, 'quiz-result');
  await step('flashcards flip and sort', async () => {
    await p.goto(BASE + '/lessons/science-g10-c02/flashcards'); await p.waitForSelector('.flash');
    await p.click('.flash'); await p.waitForSelector('.flash[aria-pressed=true]');
    await p.click('#gotc'); await p.click('#againc');
  });
  await step('practice test (timed off) runs', async () => {
    await p.goto(BASE + '/practice'); await p.waitForSelector('#pf');
    await p.click('#pf button[type=submit]'); await p.waitForSelector('#qhost .qopt');
  });
  await step('dashboard shows progress, bookmarks, continue', async () => {
    await p.goto(BASE + '/'); await p.waitForSelector('.continue'); await p.waitForSelector('.meters');
    assert(await p.$('text=Motion in a Straight Line'));
  });
  await shot(p, 'dashboard-used');
  await step('bookmarks page lists saved note', async () => { await p.goto(BASE + '/bookmarks'); await p.waitForSelector('.crow'); });
  await step('progress page shows quiz', async () => { await p.goto(BASE + '/progress'); await p.waitForSelector('table.data td'); });
  await step('filters on All notes', async () => {
    await p.goto(BASE + '/notes'); await p.selectOption('#f-subject', 'history'); await p.selectOption('#f-grade', '11');
    await p.waitForFunction(() => document.querySelectorAll('.crow').length === 8);
    await p.selectOption('#f-type', 'activity'); await p.waitForTimeout(300);
  });
  await step('subject timeline', async () => { await p.goto(BASE + '/subjects/history/timeline'); await p.waitForSelector('.timeline li'); });
  await step('profile update', async () => {
    await p.goto(BASE + '/profile'); await p.check('#pf input[name=grade][value="11"]', { force: true });
    await p.click('#pf button[type=submit]'); await p.waitForSelector('text=Profile saved');
  });
  await step('non-admin blocked from admin', async () => { await p.goto(BASE + '/admin'); await p.waitForSelector('text=Administrators only'); });
  await step('forgot password responds', async () => {
    const r = await p.evaluate(async e => (await fetch('/api/auth/forgot', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'StudyShelf' }, body: JSON.stringify({ email: e }) })).status, email);
    assert.strictEqual(r, 200);
  });
  await step('CSRF header required', async () => {
    const r = await p.evaluate(async () => (await fetch('/api/progress/1', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).status);
    assert.strictEqual(r, 403);
  });
  await step('log out', async () => { await p.goto(BASE + '/profile'); await p.click('#lo'); await p.waitForSelector('.welcome'); });

  // ---- admin
  const a = await newPage();
  await step('admin log in', async () => {
    await a.goto(BASE + '/login'); await a.fill('#email', AE); await a.fill('#password', AP); await a.click('button[type=submit]');
    await a.waitForSelector('.greet h1'); await a.goto(BASE + '/admin'); await a.waitForSelector('.stat-grid');
  });
  await shot(a, 'admin-overview');
  await step('admin notes list + filter', async () => { await a.goto(BASE + '/admin/content'); await a.waitForSelector('#rows tr'); await a.selectOption('#a-st', 'unrev'); });
  let newKey;
  await step('admin creates a lesson', async () => {
    await a.goto(BASE + '/admin/lessons/new'); await a.waitForSelector('#nf');
    await a.selectOption('#n-u', 'new'); await a.fill('#n-ut', 'Test unit'); await a.fill('#n-t', 'Test lesson about levers'); await a.fill('#n-sum', 'A test.');
    await a.click('#nf button[type=submit]'); await a.waitForURL(u => /\/admin\/lessons\//.test(u) && !/\/new$/.test(u)); await a.waitForSelector('[role=tab][data-k=notes]'); newKey = a.url().split('/').pop().split('?')[0];
  });
  await step('admin edits notes with preview and sanitising', async () => {
    await a.click('[role=tab][data-k=notes]'); await a.waitForSelector('#nt-h');
    await a.fill('#nt-h', '<section><h2>Levers</h2><p>A <mark>lever</mark> turns about a pivot.</p><img src=x onerror="alert(1)"><script>alert(2)</script></section>');
    await a.waitForSelector('#nt-prev h2'); await a.click('#saveNotes'); await a.waitForSelector('text=Some unsafe code was removed');
  });
  await step('admin adds flashcards and questions', async () => {
    await a.click('[role=tab][data-k=cards]'); await a.click('#addC'); await a.fill('#cf-0', 'Pivot'); await a.fill('#cb-0', 'The point a lever turns about'); await a.click('#saveC'); await a.waitForSelector('text=Flashcards saved');
    await a.click('[role=tab][data-k=questions]'); await a.click('#addQ'); await a.fill('#qp-0', 'What does a lever turn about?'); await a.fill('#qo-0', 'A pivot\nA wheel\nA spring'); await a.locator('#qo-0').blur();
    await a.click('#saveQ'); await a.waitForSelector('text=Questions saved');
  });
  await step('admin preview + publish', async () => {
    await a.click('[role=tab][data-k=preview]'); await a.waitForSelector('.badge-preview');
    await a.click('[role=tab][data-k=details]'); await a.click('#pubBtn'); await a.click('dialog button[value=ok]'); await a.waitForSelector('#pubBtn:has-text("Unpublish")');
  });
  await step('published lesson visible to students and sanitized', async () => {
    const html = await a.evaluate(async k => (await (await fetch('/api/lessons/' + k)).json()).lesson.notes[0].html, newKey);
    assert(!/onerror|<script/i.test(html), 'unsafe html kept');
  });
  await step('admin subjects page + add unit', async () => { await a.goto(BASE + '/admin/subjects'); await a.waitForSelector('form.subj'); });
  await step('admin media upload', async () => {
    await a.goto(BASE + '/admin/media'); await a.waitForSelector('#dz');
    await a.setInputFiles('#fi', { name: 'diagram.png', mimeType: 'image/png', buffer: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64') });
    await a.waitForSelector('text=1 file uploaded');
    await a.setInputFiles('#fi', { name: 'evil.exe', mimeType: 'application/x-msdownload', buffer: Buffer.from('MZ') });
    await a.waitForSelector('.error-box');
  });
  await step('admin users: reset link without email', async () => {
    await a.goto(BASE + '/admin/users'); await a.waitForSelector('tr[data-id]');
    await a.click(`tr:has-text("${email}") [data-a=reset]`); await a.click('dialog button[value=ok]'); await a.waitForSelector('dialog input[readonly]');
    await a.keyboard.press('Escape');
  });
  await step('admin users: turn off then on', async () => {
    await a.click(`tr:has-text("${email}") [data-a=disable]`); await a.click('dialog button[value=ok]'); await a.waitForSelector(`tr:has-text("${email}") >> text=Turned off`);
    await a.click(`tr:has-text("${email}") [data-a=disable]`); await a.click('dialog button[value=ok]'); await a.waitForTimeout(500);
  });
  await step('admin import report', async () => { await a.goto(BASE + '/admin/import'); await a.waitForSelector('text=Source websites'); await a.waitForSelector('tr[data-lvl]'); });
  await shot(a, 'admin-import');
  await step('admin deletes test lesson', async () => {
    await a.goto(BASE + '/admin/lessons/' + newKey); await a.click('#delBtn'); await a.fill('#cf-in', 'delete'); await a.click('dialog button[value=ok]'); await a.waitForURL(/admin\/content/);
  });

  // ---- mobile + tablet render
  for (const [n, vp] of [['mobile', { width: 390, height: 844 }], ['tablet', { width: 820, height: 1180 }]]) {
    const m = await newPage(vp);
    await step(`${n}: no horizontal scroll on key pages`, async () => {
      for (const path of ['/', '/subjects/ict', '/lessons/ict-g10-c01', '/lessons/science-g11-c04?tab=short', '/notes?q=enzyme', '/practice', '/login']) {
        await m.goto(BASE + path); await m.waitForTimeout(700);
        const w = await m.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
        assert(w <= 1, `${path} overflows by ${w}px`);
      }
    });
    if (SHOTS) { await m.goto(BASE + '/lessons/history-g11-c01'); await m.waitForTimeout(900); await shot(m, `${n}-lesson`); await m.goto(BASE + '/'); await m.waitForTimeout(600); await shot(m, `${n}-home`); }
  }

  await browser.close();
  for (const r of results) console.log(r.join('  '));
  console.log(errors.length ? 'Console errors:\n' + [...new Set(errors)].join('\n') : 'No console errors');
  process.exit(results.some(r => r[0] === 'FAIL') ? 1 : 0);
})();
