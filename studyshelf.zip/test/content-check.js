// Opens every lesson and every note tab; reports script errors, failed activities and broken images.
// Usage: BASE=http://localhost:3000 ADMIN=email:password node test/content-check.js
const { chromium } = require('playwright');
const BASE = process.env.BASE || 'http://localhost:3000';
const [AE, AP] = (process.env.ADMIN || 'admin@example.com:admin12345').split(':');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage();
  const errs = []; let cur = '';
  p.on('pageerror', e => errs.push(`${cur}: ${e.message}`));
  await p.goto(BASE + '/login'); await p.fill('#email', AE); await p.fill('#password', AP); await p.click('button[type=submit]'); await p.waitForSelector('.greet');
  const cat = await p.evaluate(async () => (await (await fetch('/api/catalog')).json()).lessons);
  let activities = 0, failed = [], broken = [], figures = 0;
  for (const l of cat) {
    for (let t = 0; t < l.kinds.length; t++) {
      cur = `${l.key}#${t}`;
      await p.goto(`${BASE}/lessons/${l.key}?tab=${l.kinds[t]}`); await p.waitForSelector('#noteBody');
      await p.waitForTimeout(350);
      if (await p.$('.sh-ix')) await p.waitForFunction(() => [...document.querySelectorAll('.sh-ix')].every(x => x.children.length), null, { timeout: 8000 }).catch(() => {});
      const r = await p.evaluate(() => ({
        ix: document.querySelectorAll('.sh-ix').length, fail: [...document.querySelectorAll('.sh-ix')].filter(x => x.querySelector('.ix-fail') || !x.children.length).map(x => x.dataset.name),
        broken: [...document.querySelectorAll('#noteBody img')].filter(i => i.complete && i.naturalWidth === 0).map(i => i.getAttribute('src')),
        figs: document.querySelectorAll('#noteBody figure').length
      }));
      activities += r.ix; figures += r.figs; failed.push(...r.fail.map(n => `${cur} ${n}`)); broken.push(...r.broken.map(s => `${cur} ${s}`));
    }
  }
  console.log(`${cat.length} lessons checked, ${activities} activities, ${figures} figures`);
  console.log('failed activities:', failed.length ? failed : 'none');
  console.log('broken images:', broken.length ? broken : 'none');
  console.log('script errors:', errs.length ? [...new Set(errs)] : 'none');
  await b.close();
  process.exit(failed.length || broken.length || errs.length ? 1 : 0);
})();
