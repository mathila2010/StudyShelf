// API tests: auth, permissions, privacy, sanitising, quizzes. Run with: npm test
// Uses a throwaway data folder, so it never touches your real database.
const { test, before, after } = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'studyshelf-test-'));
process.env.DATA_DIR = tmp;
process.env.ADMIN_EMAIL = 'admin@test.local';
process.env.ADMIN_PASSWORD = 'adminpass1';
process.env.NODE_ENV = 'test';
const { app, bootstrap } = require('../server/index');

let server, base;
before(async () => {
  await bootstrap();
  await new Promise(r => { server = app.listen(0, r); });
  base = `http://127.0.0.1:${server.address().port}`;
}, { timeout: 120000 });
after(() => { server && server.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

function client() {
  let cookie = '';
  return async (method, url, body) => {
    const headers = { 'X-Requested-With': 'StudyShelf' };
    if (cookie) headers.Cookie = cookie;
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const res = await fetch(base + '/api' + url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    const set = res.headers.get('set-cookie'); if (set) cookie = set.split(';')[0];
    let data = null; try { data = await res.json(); } catch (e) {}
    return { status: res.status, data };
  };
}

test('catalog lists all imported subjects and lessons', async () => {
  const c = client();
  const r = await c('GET', '/catalog');
  assert.strictEqual(r.status, 200);
  assert.deepStrictEqual(r.data.subjects.map(s => s.slug).sort(), ['business-accounting', 'history', 'ict', 'science']);
  assert.strictEqual(r.data.lessons.length, 88);
  const sci = r.data.lessons.find(l => l.key === 'science-g10-c02');
  assert.deepStrictEqual(sci.kinds, ['short', 'detailed'], 'science pocket + descriptive merged into one lesson');
});

test('guests read free lessons only', async () => {
  const c = client();
  assert.strictEqual((await c('GET', '/lessons/ict-g10-c01')).status, 200);
  const locked = await c('GET', '/lessons/ict-g10-c02');
  assert.strictEqual(locked.status, 401);
  assert.ok(locked.data.preview.title);
});

test('sign-up validates input and never stores plain passwords', async () => {
  const c = client();
  assert.strictEqual((await c('POST', '/auth/signup', { name: 'A', email: 'bad', password: 'abc12345', grade: 10 })).status, 400);
  assert.strictEqual((await c('POST', '/auth/signup', { name: 'A', email: 'a@x.lk', password: 'short', grade: 10 })).status, 400);
  assert.strictEqual((await c('POST', '/auth/signup', { name: 'A', email: 'a@x.lk', password: 'abc12345', grade: 9 })).status, 400);
  const ok = await c('POST', '/auth/signup', { name: 'Amaya', email: 'amaya@x.lk', password: 'abc12345', grade: 10, subjects: ['ict', 'nope'] });
  assert.strictEqual(ok.status, 201);
  assert.deepStrictEqual(ok.data.user.subjects, ['ict']);
  assert.strictEqual(ok.data.user.password_hash, undefined);
  const { db } = require('../server/db');
  const row = db.prepare('SELECT password_hash FROM users WHERE email=?').get('amaya@x.lk');
  assert.match(row.password_hash, /^scrypt\$/);
  assert.ok(!row.password_hash.includes('abc12345'));
  assert.strictEqual((await c('POST', '/auth/signup', { name: 'Again', email: 'AMAYA@x.lk', password: 'abc12345', grade: 10 })).status, 409);
});

test('login, session, logout', async () => {
  const c = client();
  assert.strictEqual((await c('POST', '/auth/login', { email: 'amaya@x.lk', password: 'wrongpass1' })).status, 401);
  assert.strictEqual((await c('POST', '/auth/login', { email: 'amaya@x.lk', password: 'abc12345' })).status, 200);
  assert.strictEqual((await c('GET', '/auth/me')).data.user.name, 'Amaya');
  assert.strictEqual((await c('GET', '/lessons/ict-g10-c02')).status, 200);
  await c('POST', '/auth/logout');
  assert.strictEqual((await c('GET', '/auth/me')).data.user, null);
});

test('mutations need the CSRF header', async () => {
  const res = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'amaya@x.lk', password: 'abc12345' }) });
  assert.strictEqual(res.status, 403);
});

test('students cannot use admin routes; admins can', async () => {
  const s = client(); await s('POST', '/auth/login', { email: 'amaya@x.lk', password: 'abc12345' });
  assert.strictEqual((await s('GET', '/admin/stats')).status, 403);
  const a = client(); await a('POST', '/auth/login', { email: 'admin@test.local', password: 'adminpass1' });
  assert.strictEqual((await a('GET', '/admin/stats')).status, 200);
});

test('progress, bookmarks and quiz scores are private to each student', async () => {
  const s = client(); await s('POST', '/auth/login', { email: 'amaya@x.lk', password: 'abc12345' });
  const L = (await s('GET', '/lessons/history-g10-c01')).data.lesson;
  await s('PUT', `/bookmarks/${L.id}/bookmark`);
  await s('POST', `/progress/${L.id}`, { completed: true });
  const q = L.questions[0];
  const att = await s('POST', '/quiz/attempt', { answers: { [q.id]: q.answer } });
  assert.deepStrictEqual([att.data.score, att.data.total], [1, 1]);
  const mine = (await s('GET', '/me/summary')).data;
  assert.strictEqual(mine.bookmarks.length, 1); assert.strictEqual(mine.quizzes.length, 1);
  const other = client(); await other('POST', '/auth/signup', { name: 'Nuwan', email: 'nuwan@x.lk', password: 'abc12345', grade: 11 });
  const theirs = (await other('GET', '/me/summary')).data;
  assert.strictEqual(theirs.bookmarks.length + theirs.quizzes.length + theirs.progress.length, 0);
});

test('search finds notes across subjects', async () => {
  const c = client();
  const r = await c('GET', '/search?q=photosynthesis');
  assert.ok(r.data.results.some(x => x.key === 'science-g11-c02'));
  const f = await c('GET', '/search?q=trial balance&subject=business-accounting');
  assert.ok(f.data.results.length && f.data.results.every(x => x.subject === 'business-accounting'));
});

test('admin note edits are sanitised and protected from re-import', async () => {
  const a = client(); await a('POST', '/auth/login', { email: 'admin@test.local', password: 'adminpass1' });
  const L = (await a('GET', '/admin/lessons/ict-g10-c03')).data.lesson;
  const r = await a('PUT', `/admin/lessons/${L.id}/notes`, { notes: [{ id: L.notes[0].id, kind: 'notes', title: 'Notes', html: '<h2>Binary</h2><p onclick="x()">Hi</p><script>alert(1)</script><a href="javascript:alert(1)">x</a>' }] });
  assert.strictEqual(r.status, 200); assert.ok(r.data.removed >= 2);
  const saved = (await a('GET', '/admin/lessons/ict-g10-c03')).data.lesson;
  assert.ok(!/onclick|<script|javascript:/i.test(saved.notes[0].html));
  assert.strictEqual(saved.locked, true);
  assert.strictEqual(saved.notes[0].toc[0].title, 'Binary');
});

test('the last administrator cannot be removed', async () => {
  const a = client(); await a('POST', '/auth/login', { email: 'admin@test.local', password: 'adminpass1' });
  const me = (await a('GET', '/auth/me')).data.user;
  assert.strictEqual((await a('PATCH', `/admin/users/${me.id}`, { role: 'student' })).status, 400);
});

test('password reset links work once', async () => {
  const a = client(); await a('POST', '/auth/login', { email: 'admin@test.local', password: 'adminpass1' });
  const users = (await a('GET', '/admin/users?q=amaya')).data.users;
  const r = await a('POST', `/admin/users/${users[0].id}/reset`);
  const token = new URL(r.data.link).searchParams.get('token');
  const c = client();
  assert.strictEqual((await c('POST', '/auth/reset', { token, password: 'newpass123' })).status, 200);
  assert.strictEqual((await c('POST', '/auth/reset', { token, password: 'newpass456' })).status, 400);
  assert.strictEqual((await client()('POST', '/auth/login', { email: 'amaya@x.lk', password: 'newpass123' })).status, 200);
});
