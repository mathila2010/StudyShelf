# StudyShelf

StudyShelf is one learning platform for Grade 10 and 11 (G.C.E. O/L) students. It brings together the notes from seven separate note websites. Students can sign in, choose their grade, read illustrated short and detailed notes, listen to them, take quizzes, use flashcards, bookmark lessons and track their progress. Administrators manage all the content from a built-in dashboard.

The original sites' content is **imported**, not linked. Their text, SVG diagrams, photographs, flashcards, quizzes and interactive activities (the Science mini-labs and History activities) now live inside the platform.

---

## What was imported

| Source file | Subject | Grades | Lessons | Brought across |
|---|---|---|---|---|
| `ict-g10-11.html` | ICT | 10, 11 | 15 | Notes, diagrams, callouts, key terms → flashcards, "Check yourself" → quizzes |
| `science-g10-pocket.html` + `science-g10-descriptive.html` | Science | 10 | 20 | Merged into one lesson per chapter with **Short notes** and **Detailed notes** tabs, plus figures, formulas, flip cards, MCQs and 11 mini-labs |
| `science-g11-pocket.html` + `science-g11-descriptive.html` | Science | 11 | 15 | Same as Grade 10, with 8 mini-labs, memory tricks, exam traps and summary tables |
| `business-accounting.html` | Business & Accounting | 10, 11 | 20 | Notes, definitions, exam alerts, memory hooks and quick checks with revealable answers |
| `history-companion.html` | History | 10, 11 | 18 | Notes, 80 photographs, takeaways, flashcards, quizzes, timeline events and 33 interactive activities |

**Total:** 4 subjects, 88 lessons, 351 figures, 80 images, 52 interactive activities, 686 flashcards and 716 quiz questions. Of those questions, 272 come from the original sites and 444 were generated automatically.

**Duplicates:** the Pocket and Descriptive Science sites cover the same 35 chapters. Each pair became one lesson, and repeated flashcards were skipped. Three chapter titles differed between the two sites; the Descriptive title is used and the other is kept as a search alias. The full list is in **Admin → Import**.

---

## Features

**Students**
- Sign up with a first name, email, password and grade. Subjects are optional. Students can log in, log out, reset a forgotten password, edit their profile, change their password and delete their account.
- A dashboard with a greeting, their grade and subjects, *Continue learning*, *Recommended next*, *Recently viewed*, bookmarks and favourites, progress by subject, *Recently added* and a search bar.
- **Subjects**: a shelf of subject covers. Each subject page lists its lessons by grade and unit, with status ticks.
- **All notes**: one search box across every subject, with filters for grade, subject, unit, content type, difficulty (once admins set it) and order.
- **The note reader**:
  - short and detailed tabs and a table of contents that tracks your position
  - unified callouts for definitions, examples, formulas, exam tips and facts
  - zoomable diagrams and live interactive activities
  - **Listen**, which reads the note aloud with a choice of speed and voice
  - Bookmark, Favourite, Print or save as PDF, Mark as completed and Revise later
  - related notes and previous/next lesson links
- **Quizzes**: multiple choice and true/false, one question at a time, with instant feedback and explanations. Every question shows a label saying where it came from: *From the original notes*, *Teacher-reviewed* or *Auto-generated, not yet reviewed*.
- **Flashcards**: flip, sort into "Got it" and "Again", shuffle, and use keyboard shortcuts.
- **Practice tests**: build a revision test by subject, grade, lessons, question type and length. Tests can be timed, and you can leave out auto-generated questions.
- **My progress**: completed lessons, quiz history and per-subject meters. This page is private, and scores are never shown to anyone else.
- A History timeline built from the dated events in every chapter.
- Light and dark mode, a mobile bottom bar, keyboard navigation, visible focus and support for reduced motion.

**Guests** can browse everything. They can read the first chapter of each subject and grade (8 lessons) and take practice tests on those lessons. Administrators can change which lessons are free.

**Administrators** (`/admin`)
- **Overview**: user and content counts, a 14-day activity chart, the most-read notes and the status of the last import.
- **Notes**:
  - Filter all lessons, including drafts, by subject, grade and status.
  - Create a lesson. New lessons start as drafts.
  - Edit details, guest access, difficulty and cover image.
  - Edit note tabs in HTML, with a live preview and buttons to insert callouts, tables and images.
  - Edit flashcards and quiz questions, and mark auto-generated items as reviewed.
  - Preview, publish or unpublish, and delete (you type "delete" to confirm).
- **Subjects & units**: add, rename, recolour, reorder, hide or delete subjects; manage units for each grade.
- **Files**: drag-and-drop upload of images, PDF, Word and PowerPoint files; copy a file's address; deleting warns you if a file is in use.
- **Users**:
  - Search accounts, make someone an admin or a student, and turn accounts off or on.
  - Send password resets. If email isn't set up, you get a one-hour link to pass on yourself.
  - Delete accounts. You can't remove the last administrator.
- **Import**: upload or replace source sites, run the import, and see each run's report (errors, warnings, merged duplicates). You can tick off items as reviewed.

---

## Run it locally

You need Node.js 20 or newer.

```bash
npm install
cp .env.example .env          # then edit: set ADMIN_EMAIL and ADMIN_PASSWORD
# for local http testing also set: NODE_ENV=development and COOKIE_SECURE=false
npm start                     # → http://localhost:3000
```

On first start the server creates the database in `data/` and imports every file in `sources/`, which takes about 15 seconds. It also creates the administrator from `ADMIN_EMAIL` and `ADMIN_PASSWORD`. You can also create or promote an administrator at any time:

```bash
npm run create-admin -- "Your Name" you@example.com "a-strong-password1"
```

## Deploy

StudyShelf is a single Node.js process with an SQLite database file. It needs **a host with a persistent disk**. Point `DATA_DIR` at that disk, because that is where the database, uploads and generated assets live.

- **Render**: push the folder to a Git repository, then choose *New → Blueprint*. `render.yaml` sets up the service and a 1 GB disk. Fill in `APP_URL`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` and the SMTP variables when Render asks for them.
- **Docker** (any VPS, Railway, Fly.io):
  ```bash
  docker build -t studyshelf .
  docker run -d -p 3000:3000 -v studyshelf-data:/data --env-file .env studyshelf
  ```
- **Plain VPS**: `npm ci --omit=dev`, then run `node server/index.js` under systemd or pm2, behind Nginx with HTTPS. Set `TRUST_PROXY=true`.

Always serve the site over **HTTPS** in production. Login cookies are marked `Secure`, so logins won't work over plain http unless you set `COOKIE_SECURE=false`.

### Things you need to connect

| What | Why | How |
|---|---|---|
| **SMTP email** (e.g. Gmail app password, Brevo, Mailgun, Amazon SES) | Password-reset emails | Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` and `MAIL_FROM`. Until you do, the forgot-password page explains that email isn't set up, and admins can make reset links in **Admin → Users**. |
| **A domain and HTTPS** | Secure cookies, reset links | Most hosts provide this. Set `APP_URL` to the public address. |
| **Backups** | The database is one file | Back up `DATA_DIR` (`studyshelf.db` and `media/`) every day. |

All secrets come from environment variables. Nothing secret is stored in the code.

---

## Maintaining the content

- **Edit a lesson:** go to Admin → Notes → Edit. Once you save an edit, the lesson is marked *Edited here*, and later imports won't overwrite it. To go back to the source version, use *Allow re-import to replace it*.
- **Add a new lesson or subject (for example Mathematics):** add the subject in **Subjects & units**, then use **New lesson**. Lessons stay as drafts until you publish them.
- **Update a source site:** upload the new `.html` in **Admin → Import**, or replace the file in `sources/`. Then click **Run import now**, or run `npm run import`. Imported lessons are refreshed in place. Students' bookmarks and progress are kept, and so are reviewed questions and questions you wrote yourself.
- **Review auto-generated questions:** go to Admin → Notes and set the status filter to *Has unreviewed questions*. On the Questions tab, edit each question or tick **Teacher-reviewed**. Reviewed questions lose their "auto-generated" label.
- **A new kind of source site:** the importer recognises the five formats above. For a site built differently, add an adapter in `server/importer/adapters/`. Each adapter is about 60–100 lines that turn a page into lessons. Until then, the import report lists the file as "unrecognised page format".

### How the import works
`server/importer/` opens each source page in an isolated jsdom window with its scripts running, so data such as `CH`, `DATA` and `CHAPTERS` is built exactly as the original page builds it. It then:
1. converts every chapter into the shared lesson format and maps each site's callouts to one style;
2. moves embedded base64 photos into `data/media/`;
3. merges the duplicate Science chapters;
4. sanitises all HTML with DOMPurify;
5. generates practice questions from the flashcards, flagged as auto-generated;
6. scopes each site's diagram CSS so its figures keep their look in light and dark mode;
7. cuts the original mini-lab and activity code out of the page scripts into `data/generated/ix-*.js`, which the reader loads only when needed.

---

## Project layout

```
server/
  index.js          Express app, security headers, first-start bootstrap
  config.js         environment variables
  db.js             SQLite schema + migrations (users, sessions, subjects, units, lessons, notes,
                    flashcards, questions, events, bookmarks, progress, quiz_attempts, media, import logs, FTS search)
  auth.js           scrypt password hashing, sessions, roles, CSRF guard, rate limiting
  content.js        writes imports to the DB, search index, catalog
  mail.js           SMTP (or log) for reset emails
  routes/api.js     auth, profile, catalog, lessons, search, bookmarks, progress, quizzes
  routes/admin.js   admin API (content, subjects, media, users, import)
  importer/         source-site adapters and helpers
public/             the web app (no build step): index.html, css/app.css, js/ (router, pages), fonts
sources/            the seven original note websites
scripts/            create-admin, import
test/               api.test.js (npm test), e2e.js and content-check.js (Playwright)
```

## Security and privacy
- Passwords are hashed with scrypt and a salt per user. They are never stored or logged in plain text.
- Sessions are random tokens. Only their SHA-256 hash is stored, in `httpOnly`, `SameSite=Lax` and `Secure` cookies. Changing or resetting a password logs out all other sessions.
- Every change request needs a custom header (CSRF protection). Login, sign-up and reset are rate-limited, and accounts pause for 15 minutes after 8 wrong passwords.
- The admin API checks the user's role on the server. The last active administrator can't be removed or demoted.
- All note HTML, from imports or admin edits, is sanitised. A strict Content-Security-Policy allows scripts only from the site itself. Uploaded SVGs are sanitised, and uploaded files are served with a sandbox policy.
- Only the data the site needs is collected: first name, email, password, grade and optional subjects. There are no ads, no third-party trackers and no external fonts or CDNs. Students can delete their own account and data. Scores and progress are visible only to the student, and to administrators as completion counts.
- Under-16s are asked to check with a parent or guardian before signing up. If your school needs verified parental consent, add that step to sign-up.

## Testing
```bash
npm test                    # API tests on a temporary database (auth, permissions, privacy, sanitising, quizzes, resets)
npm i -D playwright && npx playwright install chromium
BASE=http://localhost:3000 ADMIN=you@example.com:password npm run test:e2e      # full walkthrough + mobile/tablet layout checks
BASE=http://localhost:3000 ADMIN=you@example.com:password npm run test:content  # opens all 88 lessons, every tab and activity
```

## Known limitations
- **Subjects:** the sources contain only Science, ICT, Business & Accounting and History. There are no Mathematics or English notes yet; add them in the admin area.
- **Missing practice items:** five Accounting chapters have no quiz: G10 Ch 5, 6 and 7, and G11 Ch 4 and 7. Four of them also have no flashcards; G10 Ch 7 has one. Their sources are worked calculations with no definitions or questions to draw from. Their quick-check exercises are still in the notes, with revealable answers.
- **Generated questions:** 444 questions were generated automatically and need a teacher's review. They are clearly labelled, and students can leave them out.
- **Difficulty:** the sources don't set difficulty levels. The difficulty filter appears once an administrator sets them.
- **Download:** "Download" is the browser's *Print → Save as PDF* (a print stylesheet hides the menus). No server-side PDF is generated.
- **Read aloud:** this uses the voices installed in the student's browser, so quality varies by device. The notes are in English.
- **Earlier progress:** progress students saved on the old sites (in their browsers) can't be moved across.
- **Scale:** SQLite and in-memory rate limiting suit one server instance, which is plenty for a school-sized platform. To run several instances, move to PostgreSQL and a shared rate-limit store.
- **Copyright:** the notes summarise NIE textbooks, and the History photos came embedded in the source site with no licence information. Confirm you have the rights to publish them before making the site public.
