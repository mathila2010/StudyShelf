// Small UI toolkit: safe HTML templates, icons, toasts, dialogs.
class Raw { constructor(s) { this.s = s; } toString() { return this.s; } }
export const raw = s => new Raw(s == null ? '' : String(s));
export const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const render = v => v == null ? '' : typeof v === 'boolean' ? String(v) : v instanceof Raw ? v.s : Array.isArray(v) ? v.map(render).join('') : esc(v);
/** Tagged template: interpolations are escaped unless wrapped in raw() or produced by html``. */
export function html(strings, ...vals) { return raw(strings.reduce((a, s, i) => a + s + (i < vals.length ? render(vals[i]) : ''), '')); }
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const setHTML = (el, h) => { el.innerHTML = h instanceof Raw ? h.s : render(h); return el; };
export const textOf = h => { const d = document.createElement('div'); d.innerHTML = h; return d.textContent.replace(/\s+/g, ' ').trim(); };

const P = {
  home: '<path d="M3 11l9-7 9 7"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  shelf: '<path d="M4 4h4v16H4zM10 4h4v16h-4z"/><path d="M16.5 4.6l3.6-1 3.9 15.5-3.6.9z" transform="translate(-2 0.5)"/>',
  notes: '<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4M9 12h7M9 16h7M9 8h3"/>',
  bookmark: '<path d="M6 3h12v18l-6-4-6 4z"/>',
  bookmarkFill: '<path d="M6 3h12v18l-6-4-6 4z" fill="currentColor"/>',
  star: '<path d="M12 3l2.8 5.9 6.2.8-4.6 4.3 1.2 6.2L12 17.2 6.4 20.2l1.2-6.2L3 9.7l6.2-.8z"/>',
  starFill: '<path d="M12 3l2.8 5.9 6.2.8-4.6 4.3 1.2 6.2L12 17.2 6.4 20.2l1.2-6.2L3 9.7l6.2-.8z" fill="currentColor"/>',
  chart: '<path d="M4 20V4M4 20h16"/><path d="M8 16v-5M12 16V8M16 16v-8"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  flask: '<path d="M9 3h6M10 3v6l-5.5 9.5A2 2 0 0 0 6.2 21h11.6a2 2 0 0 0 1.7-2.5L14 9V3"/><path d="M7.5 15h9"/>',
  chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/><rect x="9.5" y="9.5" width="5" height="5"/>',
  ledger: '<path d="M5 3h12a2 2 0 0 1 2 2v16H7a2 2 0 0 1-2-2z"/><path d="M9 3v18M12 8h4M12 12h4"/>',
  column: '<path d="M4 21h16M5 18h14M6 18V9M10 18V9M14 18V9M18 18V9M3 9h18L12 3z"/>',
  book: '<path d="M4 4h6a3 3 0 0 1 3 3v14a2.5 2.5 0 0 0-2.5-2.5H4zM20 4h-6a3 3 0 0 0-3 3"/><path d="M20 4v14.5h-6.5A2.5 2.5 0 0 0 11 21"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
  calc: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h2M14 12h2M8 16h2M14 16h2"/>',
  play: '<path d="M7 4l13 8-13 8z" fill="currentColor"/>',
  pause: '<path d="M7 4h3v16H7zM14 4h3v16h-3z" fill="currentColor"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="1" fill="currentColor"/>',
  speaker: '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a7.5 7.5 0 0 1 0 11"/>',
  print: '<path d="M7 8V3h10v5M7 17H4V9h16v8h-3"/><path d="M7 14h10v7H7z"/>',
  check: '<path d="M5 12l5 5L20 7"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  left: '<path d="M15 5l-7 7 7 7"/>',
  right: '<path d="M9 5l7 7-7 7"/>',
  cards: '<rect x="3" y="7" width="13" height="13" rx="2"/><path d="M8 4h11a2 2 0 0 1 2 2v11"/>',
  quiz: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14M12 17.5v.5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5M4 16v4h16v-4"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14"/>',
  edit: '<path d="M4 20l4-1L19 8l-3-3L5 16z"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  logout: '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
  flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  timeline: '<path d="M12 3v18"/><circle cx="12" cy="7" r="2"/><circle cx="12" cy="17" r="2"/><path d="M14 7h6M4 17h6"/>',
  download: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
  spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M6 18l2.5-2.5M15.5 8.5L18 6"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>'
};
export const SUBJECT_ICONS = ['flask', 'chip', 'ledger', 'column', 'book', 'globe', 'calc'];
export function icon(name, attrs = '') {
  return raw(`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" ${attrs}>${P[name] || P.book}</svg>`);
}
export const LOGO = raw(`<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="3" y="4" width="26" height="24" rx="4" fill="currentColor"/><path d="M9 4v24" stroke="#D2373C" stroke-width="2"/><rect x="12" y="11" width="13" height="5" rx="1.5" fill="#FFE45C"/><path d="M12 21h10" stroke="var(--sh-paper)" stroke-width="2" stroke-linecap="round"/></svg>`);

// ---------- toasts ----------
let toastHost;
export function toast(msg, kind = '') {
  if (!toastHost) { toastHost = document.createElement('div'); toastHost.className = 'toast-host'; toastHost.setAttribute('role', 'status'); toastHost.setAttribute('aria-live', 'polite'); document.body.appendChild(toastHost); }
  const t = document.createElement('div'); t.className = 'toast ' + kind; t.textContent = msg; toastHost.appendChild(t);
  setTimeout(() => t.remove(), kind === 'error' ? 5000 : 2600);
}

// ---------- dialogs ----------
/** Confirmation dialog. With `typeToConfirm`, the user must type that word. Resolves to the typed value / true, or false. */
export function confirmDialog({ title, body = '', confirm = 'Confirm', danger = false, typeToConfirm = null }) {
  return new Promise(resolve => {
    const d = document.createElement('dialog'); d.className = 'modal';
    setHTML(d, html`<form method="dialog"><div class="m-body"><h2>${title}</h2><div class="muted">${raw(body)}</div>
      ${typeToConfirm ? html`<div class="field" style="margin-top:14px"><label for="cf-in">Type <b>${typeToConfirm}</b> to confirm</label><input id="cf-in" class="input" autocomplete="off"></div>` : ''}</div>
      <div class="m-foot"><button class="btn secondary" value="cancel">Cancel</button><button class="btn ${danger ? 'danger' : ''}" value="ok" ${typeToConfirm ? 'disabled' : ''}>${confirm}</button></div></form>`);
    document.body.appendChild(d);
    const ok = d.querySelector('button[value="ok"]'), inp = d.querySelector('#cf-in');
    if (inp) inp.addEventListener('input', () => { ok.disabled = inp.value.trim().toLowerCase() !== typeToConfirm.toLowerCase(); });
    d.addEventListener('close', () => { const v = d.returnValue === 'ok' ? (inp ? inp.value.trim() : true) : false; d.remove(); resolve(v); });
    d.showModal(); (inp || ok).focus();
  });
}
export function infoDialog(title, bodyHtml) {
  const d = document.createElement('dialog'); d.className = 'modal';
  setHTML(d, html`<form method="dialog"><div class="m-body"><h2>${title}</h2>${raw(bodyHtml)}</div><div class="m-foot"><button class="btn">Done</button></div></form>`);
  document.body.appendChild(d); d.addEventListener('close', () => d.remove()); d.showModal();
}
export function lightbox(node, caption) {
  const d = document.createElement('dialog'); d.className = 'modal lightbox'; d.setAttribute('aria-label', 'Enlarged figure');
  const clone = node.cloneNode(true); clone.removeAttribute('loading'); clone.style.cursor = 'default';
  setHTML(d, html`<button class="iconbtn lb-close" aria-label="Close">${icon('x')}</button><div class="lb-body"></div>${caption ? html`<p class="lb-cap">${caption}</p>` : ''}`);
  d.querySelector('.lb-body').appendChild(clone);
  if (clone.tagName.toLowerCase() === 'svg') { clone.style.width = 'min(1100px, 92vw)'; clone.style.height = 'auto'; }
  document.body.appendChild(d);
  d.querySelector('.lb-close').onclick = () => d.close();
  d.addEventListener('click', e => { if (e.target === d) d.close(); });
  d.addEventListener('close', () => d.remove()); d.showModal();
}

export const fmtDate = t => t ? new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : '—';
export const fmtAgo = t => {
  if (!t) return '';
  const s = (Date.now() - t) / 1000;
  if (s < 90) return 'just now'; if (s < 3600) return `${Math.round(s / 60)} min ago`; if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  if (s < 86400 * 7) return `${Math.round(s / 86400)} days ago`; return fmtDate(t);
};
export const plural = (n, one, many) => `${n} ${n === 1 ? one : (many || one + 's')}`;
export const loading = (label = 'Loading…') => html`<div class="loading" role="status"><span class="spinner" aria-hidden="true"></span>${label}</div>`;
export const errorBox = msg => html`<div class="error-box" role="alert">${msg}</div>`;
export function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
