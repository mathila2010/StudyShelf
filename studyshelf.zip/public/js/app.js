// App shell and router.
import { html, raw, icon, setHTML, $, $$, LOGO, toast, errorBox } from './ui.js';
import { state, loadCatalog, loadMe, onChange } from './store.js';
import { ApiError } from './api.js';

const appName = document.getElementById('app').dataset.appName || 'StudyShelf';
window.SH = { toast }; // used by imported interactive activities

// Lazy page modules
const page = (mod, fn) => async ctx => (await import(mod))[fn](ctx);
const ROUTES = [
  ['/', page('./pages/home.js', 'home')],
  ['/subjects', page('./pages/subjects.js', 'shelf')],
  ['/subjects/:slug', page('./pages/subjects.js', 'subject')],
  ['/subjects/:slug/timeline', page('./pages/subjects.js', 'timeline')],
  ['/notes', page('./pages/notes.js', 'notes')],
  ['/lessons/:key', page('./pages/lesson.js', 'lesson')],
  ['/lessons/:key/quiz', page('./pages/practice.js', 'lessonQuiz')],
  ['/lessons/:key/flashcards', page('./pages/practice.js', 'flashcards')],
  ['/practice', page('./pages/practice.js', 'practice')],
  ['/bookmarks', page('./pages/me.js', 'bookmarks'), { auth: true }],
  ['/progress', page('./pages/me.js', 'progress'), { auth: true }],
  ['/profile', page('./pages/me.js', 'profile'), { auth: true }],
  ['/login', page('./pages/auth.js', 'login')],
  ['/signup', page('./pages/auth.js', 'signup')],
  ['/forgot-password', page('./pages/auth.js', 'forgot')],
  ['/reset-password', page('./pages/auth.js', 'reset')],
  ['/admin', page('./pages/admin.js', 'dashboard'), { admin: true }],
  ['/admin/content', page('./pages/admin.js', 'content'), { admin: true }],
  ['/admin/lessons/new', page('./pages/admin.js', 'newLesson'), { admin: true }],
  ['/admin/lessons/:key', page('./pages/admin.js', 'editLesson'), { admin: true }],
  ['/admin/subjects', page('./pages/admin.js', 'subjects'), { admin: true }],
  ['/admin/media', page('./pages/admin.js', 'media'), { admin: true }],
  ['/admin/users', page('./pages/admin.js', 'users'), { admin: true }],
  ['/admin/import', page('./pages/admin.js', 'importPage'), { admin: true }]
].map(([pattern, run, opts = {}]) => {
  const keys = []; const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  return { pattern, re, keys, run, ...opts };
});

const NAV = [
  ['/', 'home', 'Home'], ['/subjects', 'shelf', 'Subjects'], ['/notes', 'notes', 'All notes'],
  ['/bookmarks', 'bookmark', 'My bookmarks'], ['/progress', 'chart', 'My progress'], ['/profile', 'user', 'Profile']
];

function shell() {
  const app = document.getElementById('app');
  setHTML(app, html`
  <header class="topbar">
    <a class="brand" href="/" aria-label="${appName} home">${LOGO}<span>${appName}</span></a>
    <form class="top-search" role="search" id="topSearch">
      ${icon('search')}
      <label class="sr-only" for="q">Search all notes</label>
      <input id="q" name="q" type="search" placeholder="Search all notes" autocomplete="off" enterkeyhint="search">
    </form>
    <div class="top-actions">
      <button class="iconbtn" id="themeBtn" type="button" aria-label="Switch to dark mode">${icon('moon')}</button>
      <span id="acct"></span>
    </div>
  </header>
  <div class="shell">
    <nav class="sidenav" id="sidenav" aria-label="Main"></nav>
    <main class="main" id="main" tabindex="-1"><div class="page" id="view"></div></main>
  </div>
  <nav class="bottomnav" id="bottomnav" aria-label="Main"></nav>`);
  $('#topSearch').addEventListener('submit', e => {
    e.preventDefault(); const q = $('#q').value.trim();
    navigate('/notes' + (q ? '?q=' + encodeURIComponent(q) : ''));
  });
  const tb = $('#themeBtn');
  const syncTheme = () => { const dark = document.documentElement.dataset.theme === 'dark'; setHTML(tb, icon(dark ? 'sun' : 'moon')); tb.setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode'); };
  tb.onclick = () => { const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = t; try { localStorage.setItem('ss-theme', t); } catch (e) {} syncTheme(); };
  syncTheme();
  renderNav();
  onChange(renderNav);
}

function renderNav() {
  const u = state.user; const path = location.pathname;
  const cur = href => href === '/' ? path === '/' : path === href || path.startsWith(href + '/');
  const subjects = state.catalog ? state.catalog.subjects : [];
  setHTML($('#sidenav'), html`
    ${NAV.map(([href, ic, label]) => html`<a class="navlink" href="${href}" ${cur(href) ? raw('aria-current="page"') : ''}>${icon(ic)}<span>${label}</span></a>`)}
    <a class="navlink" href="/practice" ${cur('/practice') ? raw('aria-current="page"') : ''}>${icon('quiz')}<span>Practice tests</span></a>
    <div class="nav-sep"></div>
    <div class="nav-label">Subjects</div>
    ${subjects.map(s => html`<a class="nav-subject" href="/subjects/${s.slug}" style="--c:${s.color}" ${path.startsWith('/subjects/' + s.slug) ? raw('aria-current="page"') : ''}><i></i>${s.name}</a>`)}
    <div class="spacer"></div>
    ${u && u.role === 'admin' ? html`<div class="nav-sep"></div><a class="navlink" href="/admin" ${cur('/admin') ? raw('aria-current="page"') : ''}>${icon('shield')}<span>Admin</span></a>` : ''}
    ${u ? html`<button class="navlink" type="button" id="logoutBtn" style="border:0;background:none;cursor:pointer;width:100%;text-align:left">${icon('logout')}<span>Log out</span></button>`
        : html`<a class="navlink" href="/login">${icon('user')}<span>Log in</span></a>`}`);
  setHTML($('#bottomnav'), html`${[['/', 'home', 'Home'], ['/subjects', 'shelf', 'Subjects'], ['/notes', 'notes', 'Notes'], ['/bookmarks', 'bookmark', 'Saved'], [u ? '/profile' : '/login', 'user', u ? 'Me' : 'Log in']]
    .map(([href, ic, label]) => html`<a href="${href}" ${cur(href) || (label === 'Me' && (cur('/progress') || cur('/admin'))) ? raw('aria-current="page"') : ''}>${icon(ic)}${label}</a>`)}`);
  setHTML($('#acct'), u ? html`<a class="avatar" href="/profile" title="Your profile" aria-label="Your profile">${(u.name || '?').trim()[0].toUpperCase()}</a>`
    : html`<a class="btn small" href="/signup">Sign up</a>`);
  const lo = $('#logoutBtn'); if (lo) lo.onclick = logout;
}

export async function logout() {
  const { api } = await import('./api.js');
  try { await api('/auth/logout', { method: 'POST' }); } catch (e) {}
  state.user = null; state.summary = null; renderNav(); toast('You’re logged out.'); navigate('/');
}

// ---------- router ----------
let cleanup = null; let navToken = 0;
export function navigate(to, { replace = false } = {}) {
  if (replace) history.replaceState({}, '', to); else history.pushState({}, '', to);
  route();
}
async function route() {
  const token = ++navToken;
  if (typeof cleanup === 'function') { try { cleanup(); } catch (e) {} }
  cleanup = null;
  const url = new URL(location.href);
  const view = $('#view');
  const match = ROUTES.map(r => ({ r, m: r.re.exec(url.pathname) })).find(x => x.m);
  renderNav();
  if (!match) { setHTML(view, html`<div class="empty"><h1>Page not found</h1><p>This address doesn’t match any page.</p><a class="btn" href="/">Go to Home</a></div>`); document.title = `Not found · ${appName}`; return; }
  const params = Object.fromEntries(match.r.keys.map((k, i) => [k, decodeURIComponent(match.m[i + 1])]));
  if ((match.r.auth || match.r.admin) && !state.user) { navigate('/login?next=' + encodeURIComponent(url.pathname + url.search), { replace: true }); return; }
  if (match.r.admin && state.user.role !== 'admin') { setHTML(view, html`<div class="empty"><h1>Administrators only</h1><p>Your account can’t open the admin area.</p><a class="btn" href="/">Go to Home</a></div>`); return; }
  const ctx = {
    params, query: url.searchParams, view, appName,
    title: t => { document.title = t ? `${t} · ${appName}` : appName; },
    stale: () => token !== navToken,
    onLeave: fn => { cleanup = fn; }
  };
  try { await match.r.run(ctx); }
  catch (e) {
    if (token !== navToken) return;
    console.error(e);
    setHTML(view, html`<div class="page-head"><h1>That didn’t load</h1></div>${errorBox(e instanceof ApiError ? e.message : 'Something went wrong while opening this page. Reload and try again.')}<button class="btn" onclick="location.reload()">Reload</button>`);
    const b = view.querySelector('button'); if (b) { b.removeAttribute('onclick'); b.onclick = () => location.reload(); }
  }
  if (token !== navToken) return;
  if (!url.hash) window.scrollTo(0, 0);
  const h1 = view.querySelector('h1'); const main = $('#main');
  if (window.__navigated) { (h1 || main).setAttribute('tabindex', '-1'); (h1 || main).focus({ preventScroll: true }); }
  window.__navigated = true;
}

document.addEventListener('click', e => {
  const a = e.target.closest('a[href]');
  if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
  if (a.target || a.hasAttribute('download') || a.dataset.external !== undefined) return;
  const url = new URL(a.href, location.href);
  if (url.origin !== location.origin || /^\/(media|generated|api)\//.test(url.pathname)) return;
  if (url.pathname === location.pathname && url.search === location.search && url.hash) return; // in-page anchor
  e.preventDefault(); navigate(url.pathname + url.search + url.hash);
});
window.addEventListener('popstate', route);

(async function boot() {
  try { await Promise.all([loadCatalog(), loadMe()]); }
  catch (e) {
    setHTML(document.getElementById('app'), html`<div class="boot">${errorBox(e.message || 'The library could not load.')}<button class="btn" id="rl">Try again</button></div>`);
    $('#rl').onclick = () => location.reload(); return;
  }
  shell(); route();
})();
