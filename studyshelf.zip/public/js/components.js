// Shared building blocks for lesson lists.
import { html, raw, icon, esc, plural } from './ui.js';
import { subjectById, unitById, progressOf, state } from './store.js';

export const subjectPill = s => s ? html`<span class="pill subject" style="--c:${s.color}">${s.name}</span>` : '';
export const gradePill = g => html`<span class="pill">Grade ${g}</span>`;

export function kindsLabel(l) {
  const k = l.kinds || [];
  if (k.includes('short') && k.includes('detailed')) return 'Short + detailed notes';
  if (k.includes('short')) return 'Short notes';
  if (k.includes('detailed')) return 'Detailed notes';
  return 'Notes';
}
export function lessonTags(l) {
  return html`<span class="pill">${kindsLabel(l)}</span>
    ${l.activities ? html`<span class="pill">${icon('spark')}Activity</span>` : ''}
    ${l.questions ? html`<span class="pill">${icon('quiz')}${l.questions} questions</span>` : ''}
    ${l.cards ? html`<span class="pill">${icon('cards')}${l.cards} cards</span>` : ''}
    ${l.difficulty ? html`<span class="pill">${l.difficulty[0].toUpperCase() + l.difficulty.slice(1)}</span>` : ''}`;
}

export function thumb(l, s) {
  const img = l.image && l.image.url;
  return html`<span class="thumb" style="--c:${s ? s.color : '#555'}" aria-hidden="true">${img ? html`<img src="${img}" alt="" loading="lazy">` : html`${l.number || icon((s && s.icon) || 'book')}<small>G${l.grade}</small>`}</span>`;
}

/** Contents-page row: chapter number, title, summary, tags, status. */
export function contentsRow(l) {
  const p = progressOf(l.id) || {};
  const locked = !state.user && !l.guest;
  const st = p.completed_at ? 'done' : p.views ? 'seen' : '';
  return html`<li><a class="crow" href="/lessons/${l.key}">
    <span class="num" aria-hidden="true">${l.number || '·'}</span>
    <span><span class="t">${l.title}</span><span class="s">${l.hook || l.summary}</span><span class="tags">${lessonTags(l)}${locked ? html`<span class="pill lock">${icon('lock')}Log in to read</span>` : l.guest && !state.user ? html`<span class="pill ok">Free to read</span>` : ''}</span></span>
    <span class="state ${st}" title="${st === 'done' ? 'Completed' : st === 'seen' ? 'Started' : 'Not started'}">${st === 'done' ? icon('check') : ''}<span class="sr-only">${st === 'done' ? 'Completed' : st === 'seen' ? 'Started' : 'Not started'}</span></span>
  </a></li>`;
}

export function lessonTile(l, why) {
  const s = subjectById(l.subjectId);
  return html`<a class="ltile" href="/lessons/${l.key}" style="--c:${s.color}">
    <span class="small muted">${s.name}, Grade ${l.grade}${l.number ? `, Ch ${l.number}` : ''}</span>
    <b>${l.title}</b>
    ${why ? html`<span class="why">${why}</span>` : ''}
    <span class="meta"><span>${kindsLabel(l)}</span>${(progressOf(l.id) || {}).completed_at ? html`<span style="color:var(--sh-ok);font-weight:700">Done</span>` : ''}</span>
  </a>`;
}

export function resultRow(r) {
  const s = state.catalog.subjects.find(x => x.slug === r.subject) || { color: r.color };
  return html`<a class="result" href="/lessons/${r.key}">
    ${thumb({ number: r.number, grade: r.grade, image: r.image }, s)}
    <div><h3>${r.title}</h3>
      <div class="meta">${subjectPill(s)}${html`<span class="pill">Grade ${r.grade}</span>`}${r.unit ? html`<span class="pill">${r.unit}</span>` : ''}${!state.user && !r.guest ? html`<span class="pill lock">${icon('lock')}Log in</span>` : ''}</div>
      <p class="snip">${raw(r.snippet)}</p></div></a>`;
}

export function subjectMeters(grade) {
  return html`<div class="meters">${state.catalog.subjects.map(s => {
    const list = state.catalog.lessons.filter(l => l.subjectId === s.id && (!grade || l.grade === grade));
    if (!list.length) return '';
    const done = list.filter(l => (progressOf(l.id) || {}).completed_at).length;
    const pct = Math.round(done * 100 / list.length);
    return html`<a class="meter-row" href="/subjects/${s.slug}${grade ? `?grade=${grade}` : ''}" style="--c:${s.color}"><b>${s.name}</b><span>${done} of ${list.length} done</span>
      <span class="meter" role="progressbar" aria-label="${s.name} progress" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct}%"></i></span></a>`;
  })}</div>`;
}

export const unitTitle = id => (unitById(id) || {}).title || 'Other lessons';
export { esc, plural };
