// Log in, sign up, forgot and reset password.
import { html, raw, setHTML, $, $$, toast, errorBox } from '../ui.js';
import { api } from '../api.js';
import { state, loadMe } from '../store.js';
import { navigate } from '../app.js';

const nextUrl = ctx => { const n = ctx.query.get('next') || '/'; return n.startsWith('/') && !n.startsWith('//') ? n : '/'; };
const card = (inner) => html`<div class="auth-wrap"><div class="auth-card">${inner}</div></div>`;
function busy(btn, on, label) { btn.disabled = on; if (on) { btn.dataset.l = btn.textContent; btn.textContent = label; } else if (btn.dataset.l) btn.textContent = btn.dataset.l; }
function fieldErrors(form, msg) {
  setHTML($('.form-msg', form), errorBox(msg));
  const m = msg.toLowerCase();
  $$('input', form).forEach(i => i.removeAttribute('aria-invalid'));
  const target = /email/.test(m) ? form.email : /password/.test(m) ? form.password : /name/.test(m) ? form.name : null;
  if (target) { target.setAttribute('aria-invalid', 'true'); target.focus(); }
}

export function login(ctx) {
  if (state.user) return navigate(nextUrl(ctx), { replace: true });
  ctx.title('Log in');
  setHTML(ctx.view, card(html`<h1>Log in</h1><p class="muted">Welcome back. Pick up where you left off.</p>
    <form class="form" id="f" novalidate>
      <div class="field"><label for="email">Email address</label><input class="input" id="email" name="email" type="email" autocomplete="email" required></div>
      <div class="field"><label for="password">Password</label><input class="input" id="password" name="password" type="password" autocomplete="current-password" required></div>
      <div class="form-msg" aria-live="assertive"></div>
      <button class="btn" type="submit">Log in</button>
      <a href="/forgot-password">Forgot your password?</a>
    </form>
    <p class="auth-foot">New here? <a href="/signup${ctx.query.get('next') ? '?next=' + encodeURIComponent(nextUrl(ctx)) : ''}">Create a free account</a></p>`));
  const f = $('#f', ctx.view); f.email.focus();
  f.addEventListener('submit', async e => {
    e.preventDefault(); const b = f.querySelector('button[type=submit]'); busy(b, true, 'Logging in…');
    try { await api('/auth/login', { method: 'POST', body: { email: f.email.value, password: f.password.value } }); await loadMe(); toast(`Welcome back, ${state.user.name.split(' ')[0]}!`); navigate(nextUrl(ctx)); }
    catch (err) { fieldErrors(f, err.message); busy(b, false); }
  });
}

export function signup(ctx) {
  if (state.user) return navigate('/', { replace: true });
  ctx.title('Create an account');
  const c = state.catalog;
  setHTML(ctx.view, card(html`<h1>Create your account</h1><p class="muted">Free, and it only takes a minute.</p>
    <form class="form" id="f" novalidate>
      <div class="field"><label for="name">First name</label><input class="input" id="name" name="name" autocomplete="given-name" maxlength="60" required><span class="hint">Shown only to you, on your dashboard.</span></div>
      <div class="field"><label for="email">Email address</label><input class="input" id="email" name="email" type="email" autocomplete="email" required><span class="hint">Used to log in and to reset your password.</span></div>
      <div class="field"><label for="password">Password</label><input class="input" id="password" name="password" type="password" autocomplete="new-password" minlength="8" required><span class="hint">At least 8 characters, with a letter and a number.</span></div>
      <div class="field"><span class="label" id="g-l">Your grade</span><div class="choice-row" role="radiogroup" aria-labelledby="g-l">${c.grades.map((g, i) => html`<label class="choice"><input type="radio" name="grade" value="${g}" ${i === 0 ? raw('checked') : ''}><span>Grade ${g}</span></label>`)}</div></div>
      <div class="field"><span class="label" id="s-l">Your subjects <span class="muted small">(optional)</span></span><div class="choice-row" role="group" aria-labelledby="s-l">${c.subjects.map(s => html`<label class="choice"><input type="checkbox" name="subjects" value="${s.slug}"><span>${s.name}</span></label>`)}</div></div>
      <p class="small muted" style="margin:0">We only ask for what the site needs. Your scores and progress are private to you. If you’re under 16, check with a parent or guardian before signing up.</p>
      <div class="form-msg" aria-live="assertive"></div>
      <button class="btn" type="submit">Create account</button>
    </form>
    <p class="auth-foot">Already have an account? <a href="/login">Log in</a></p>`));
  const f = $('#f', ctx.view); f.name.focus();
  f.addEventListener('submit', async e => {
    e.preventDefault(); const b = f.querySelector('button[type=submit]'); busy(b, true, 'Creating account…');
    try {
      await api('/auth/signup', { method: 'POST', body: { name: f.name.value, email: f.email.value, password: f.password.value, grade: +(f.querySelector('[name=grade]:checked') || {}).value, subjects: $$('[name=subjects]:checked', f).map(x => x.value) } });
      await loadMe(); toast('Account created. Welcome!'); navigate(nextUrl(ctx));
    } catch (err) { fieldErrors(f, err.message); busy(b, false); }
  });
}

export function forgot(ctx) {
  ctx.title('Reset your password');
  setHTML(ctx.view, card(html`<h1>Forgot your password?</h1><p class="muted">Enter your email and we’ll send you a link to choose a new one.</p>
    <form class="form" id="f" novalidate>
      <div class="field"><label for="email">Email address</label><input class="input" id="email" name="email" type="email" autocomplete="email" required></div>
      <div class="form-msg" aria-live="polite"></div>
      <button class="btn" type="submit">Send reset link</button>
    </form>
    ${!state.mailConfigured ? html`<p class="notice small">Email isn’t set up on this site yet. If the link doesn’t arrive, ask your teacher or the site administrator to send you one.</p>` : ''}
    <p class="auth-foot"><a href="/login">Back to log in</a></p>`));
  const f = $('#f', ctx.view); f.email.focus();
  f.addEventListener('submit', async e => {
    e.preventDefault(); const b = f.querySelector('button[type=submit]'); busy(b, true, 'Sending…');
    try { const r = await api('/auth/forgot', { method: 'POST', body: { email: f.email.value } }); setHTML($('.form-msg', f), html`<div class="ok-box">${r.message}</div>`); }
    catch (err) { fieldErrors(f, err.message); }
    busy(b, false);
  });
}

export function reset(ctx) {
  ctx.title('Choose a new password');
  const token = ctx.query.get('token') || '';
  setHTML(ctx.view, card(html`<h1>Choose a new password</h1>
    ${!token ? html`<div class="error-box">This reset link is incomplete. Open the link from your email again, or <a href="/forgot-password">ask for a new one</a>.</div>` : ''}
    <form class="form" id="f" novalidate ${!token ? raw('hidden') : ''}>
      <div class="field"><label for="password">New password</label><input class="input" id="password" name="password" type="password" autocomplete="new-password" minlength="8" required><span class="hint">At least 8 characters, with a letter and a number.</span></div>
      <div class="field"><label for="password2">Type it again</label><input class="input" id="password2" name="password2" type="password" autocomplete="new-password" required></div>
      <div class="form-msg" aria-live="assertive"></div>
      <button class="btn" type="submit">Save new password</button>
    </form>`));
  const f = $('#f', ctx.view);
  f.addEventListener('submit', async e => {
    e.preventDefault();
    if (f.password.value !== f.password2.value) { f.password2.setAttribute('aria-invalid', 'true'); setHTML($('.form-msg', f), errorBox('The two passwords don’t match.')); return; }
    const b = f.querySelector('button[type=submit]'); busy(b, true, 'Saving…');
    try { await api('/auth/reset', { method: 'POST', body: { token, password: f.password.value } }); await loadMe(); toast('Password changed. You’re logged in.'); navigate('/', { replace: true }); }
    catch (err) { fieldErrors(f, err.message); busy(b, false); }
  });
}
