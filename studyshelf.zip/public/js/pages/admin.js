// Administrator dashboard.
import { html, raw, icon, setHTML, $, $$, toast, loading, plural, fmtDate, fmtAgo, confirmDialog, infoDialog, errorBox, esc, debounce, SUBJECT_ICONS } from '../ui.js';
import { api } from '../api.js';
import { state, loadCatalog } from '../store.js';
import { navigate } from '../app.js';
import { renderLesson } from './lesson.js';

const TABS = [['/admin', 'Overview'], ['/admin/content', 'Notes'], ['/admin/subjects', 'Subjects & units'], ['/admin/media', 'Files'], ['/admin/users', 'Users'], ['/admin/import', 'Import']];
const adminNav = () => html`<nav class="admin-nav" aria-label="Admin sections">${TABS.map(([h, t]) => html`<a href="${h}" ${(h === '/admin' ? location.pathname === h : location.pathname.startsWith(h)) || (h === '/admin/content' && location.pathname.startsWith('/admin/lessons')) ? raw('aria-current="page"') : ''}>${t}</a>`)}</nav>`;
const head = (title, sub, actions = '') => html`<header class="page-head" style="display:flex;justify-content:space-between;gap:16px;align-items:end;flex-wrap:wrap"><div><h1>${title}</h1>${sub ? html`<p>${sub}</p>` : ''}</div><div class="btn-row">${actions}</div></header>${adminNav()}`;
const refreshCatalog = () => loadCatalog(true).catch(() => {});

// ---------- overview ----------
export async function dashboard(ctx) {
  ctx.title('Admin');
  setHTML(ctx.view, html`${head('Admin', 'Manage notes, subjects, files and accounts.')}${loading()}`);
  const s = await api('/admin/stats'); if (ctx.stale()) return;
  const spark = (arr, label) => { const max = Math.max(1, ...arr); return html`<div><b>${label}</b> <span class="muted small">${arr.reduce((a, b) => a + b, 0)} in 14 days</span><div class="spark" role="img" aria-label="${label} per day for the last 14 days: ${arr.join(', ')}">${arr.map(v => html`<i style="height:${Math.max(3, v * 100 / max)}%" title="${v}"></i>`)}</div><div class="spark-labels"><span>${s.activity.days[0].slice(5)}</span><span>today</span></div></div>`; };
  setHTML(ctx.view, html`${head('Admin', 'Manage notes, subjects, files and accounts.', html`<a class="btn" href="/admin/lessons/new">${icon('plus')}New lesson</a>`)}
  ${!s.mailConfigured ? html`<div class="notice"><b>Email isn’t set up.</b> Students can’t receive password-reset emails. Add SMTP settings to the server’s environment (see README), or send reset links yourself from <a href="/admin/users">Users</a>.</div>` : ''}
  ${s.import && s.import.open ? html`<div class="notice"><b>${plural(s.import.open, 'import issue')} to review.</b> <a href="/admin/import">Open the import report</a></div>` : ''}
  <div class="stat-grid">
    <div class="stat"><b>${s.users.students || 0}</b><span>students (${s.users.new7 || 0} new this week)</span></div>
    <div class="stat"><b>${s.users.active7 || 0}</b><span>logged in this week</span></div>
    <div class="stat"><b>${s.content.lessons}</b><span>lessons (${s.content.unpublished} unpublished)</span></div>
    <div class="stat"><b>${s.content.questions}</b><span>quiz questions</span></div>
    <div class="stat"><b>${s.content.unreviewed}</b><span>auto-generated questions not reviewed</span></div>
    <div class="stat"><b>${s.content.flashcards}</b><span>flashcards</span></div>
  </div>
  <div class="dash-grid section">
    <section class="panel"><h2>Activity</h2><div class="form">${spark(s.activity.views, 'Notes opened')}${spark(s.activity.logins, 'Log-ins')}${spark(s.activity.quizzes, 'Quizzes taken')}${spark(s.activity.signups, 'Sign-ups')}</div></section>
    <section class="panel"><h2>Most-read notes</h2>${s.topLessons.length ? html`<div class="tablewrap"><table class="data"><thead><tr><th>Note</th><th>Views</th><th>Completed</th></tr></thead><tbody>${s.topLessons.map(l => html`<tr><td><a href="/lessons/${l.key}">${l.title}</a><div class="small muted">${l.subject}, Grade ${l.grade}</div></td><td class="num">${l.views}</td><td class="num">${l.completions}</td></tr>`)}</tbody></table></div>` : html`<p class="muted">No reading activity yet.</p>`}
      <h2 class="section" style="margin-top:24px">Last import</h2>${s.import ? html`<p>${fmtAgo(s.import.started_at)}: ${s.import.summary.lessons || 0} lessons, ${s.import.summary.errors || 0} errors, ${s.import.summary.warnings || 0} warnings, ${s.import.summary.duplicates || 0} duplicates merged. <a href="/admin/import">Details</a></p>` : html`<p class="muted">No imports yet.</p>`}</section>
  </div>`);
}

// ---------- lessons list ----------
export async function content(ctx) {
  ctx.title('Admin: notes');
  setHTML(ctx.view, html`${head('Notes', 'Every lesson in the library, including unpublished drafts.')}${loading()}`);
  const [{ lessons }, { subjects }] = await Promise.all([api('/admin/lessons'), api('/admin/subjects')]); if (ctx.stale()) return;
  const grades = [...new Set(lessons.map(l => l.grade))].sort();
  setHTML(ctx.view, html`${head('Notes', 'Every lesson in the library, including unpublished drafts.', html`<a class="btn" href="/admin/lessons/new">${icon('plus')}New lesson</a>`)}
  <form class="filters" id="af"><div class="field search-field"><label for="a-q">Search titles</label><input class="input" id="a-q" name="q" type="search"></div>
    <div class="field"><label for="a-s">Subject</label><select class="input" id="a-s" name="s"><option value="">All</option>${subjects.map(s => html`<option value="${s.id}">${s.name}</option>`)}</select></div>
    <div class="field"><label for="a-g">Grade</label><select class="input" id="a-g" name="g"><option value="">All</option>${grades.map(g => html`<option>${g}</option>`)}</select></div>
    <div class="field"><label for="a-st">Status</label><select class="input" id="a-st" name="st"><option value="">Any</option><option value="pub">Published</option><option value="draft">Unpublished</option><option value="edited">Edited by an admin</option><option value="unrev">Has unreviewed questions</option><option value="guest">Free for guests</option></select></div></form>
  <p class="result-count" id="cnt"></p><div class="tablewrap"><table class="data"><thead><tr><th>Lesson</th><th>Subject</th><th>Grade, ch.</th><th>Notes</th><th>Quiz</th><th>Status</th><th></th></tr></thead><tbody id="rows"></tbody></table></div>`);
  const f = $('#af', ctx.view);
  const draw = () => {
    const q = f.q.value.trim().toLowerCase();
    const list = lessons.filter(l => (!q || l.title.toLowerCase().includes(q)) && (!f.s.value || l.subject_id === +f.s.value) && (!f.g.value || l.grade === +f.g.value) &&
      (!f.st.value || (f.st.value === 'pub' ? l.published : f.st.value === 'draft' ? !l.published : f.st.value === 'edited' ? l.locked : f.st.value === 'guest' ? l.guest : l.unreviewed > 0)));
    $('#cnt', ctx.view).textContent = plural(list.length, 'lesson');
    setHTML($('#rows', ctx.view), list.length ? html`${list.map(l => html`<tr>
      <td><a href="/admin/lessons/${l.key}"><b>${l.title}</b></a>${l.unit ? html`<div class="small muted">${l.unit}</div>` : ''}</td><td>${l.subject}</td><td>G${l.grade}, ${l.number}</td>
      <td class="small">${(l.kinds || '').split(',').join(', ')}</td><td class="small">${l.questions}${l.unreviewed ? html` <span class="pill gen">${l.unreviewed} to review</span>` : ''}</td>
      <td>${l.published ? html`<span class="pill ok">Published</span>` : html`<span class="pill">Draft</span>`} ${l.guest ? html`<span class="pill">Guest</span>` : ''} ${l.locked ? html`<span class="pill" title="Edited here, so re-imports won't overwrite it">Edited</span>` : ''}</td>
      <td><div class="btn-row" style="flex-wrap:nowrap"><a class="btn small secondary" href="/admin/lessons/${l.key}">${icon('edit')}Edit</a>${l.published ? html`<a class="btn small ghost" href="/lessons/${l.key}" title="Open as students see it">${icon('eye')}<span class="sr-only">View ${l.title}</span></a>` : ''}</div></td></tr>`)}`
      : html`<tr><td colspan="7"><div class="empty">No lessons match.</div></td></tr>`);
  };
  f.addEventListener('input', draw); f.addEventListener('submit', e => e.preventDefault()); draw();
}

// ---------- new lesson ----------
export async function newLesson(ctx) {
  ctx.title('Admin: new lesson');
  const { subjects, units } = await api('/admin/subjects'); if (ctx.stale()) return;
  setHTML(ctx.view, html`${head('New lesson', 'Start a lesson, then write its notes, flashcards and questions. It stays unpublished until you publish it.')}
  <form class="panel form" id="nf" style="max-width:720px" novalidate>
    <div class="field"><label for="n-s">Subject</label><select class="input" id="n-s" name="subjectId">${subjects.map(s => html`<option value="${s.id}">${s.name}</option>`)}</select><span class="hint">Need a new subject? <a href="/admin/subjects">Add it in Subjects & units</a>.</span></div>
    <div class="editor-grid"><div class="field"><label for="n-g">Grade</label><input class="input" id="n-g" name="grade" type="number" min="1" max="13" value="10"></div>
      <div class="field"><label for="n-n">Chapter number</label><input class="input" id="n-n" name="number" type="number" min="0" max="999" value="1"></div></div>
    <div class="field"><label for="n-u">Unit</label><select class="input" id="n-u" name="unitId"></select></div>
    <div class="field" id="n-ut-wrap" hidden><label for="n-ut">New unit name</label><input class="input" id="n-ut" name="unitTitle"></div>
    <div class="field"><label for="n-t">Title</label><input class="input" id="n-t" name="title" maxlength="140" required></div>
    <div class="field"><label for="n-sum">Short description</label><textarea class="input" id="n-sum" name="summary" maxlength="1000" style="min-height:80px"></textarea><span class="hint">Shown on lesson cards and in search results.</span></div>
    <div id="n-msg"></div><div><button class="btn" type="submit">Create lesson</button></div></form>`);
  const f = $('#nf', ctx.view);
  const fillUnits = () => {
    const us = units.filter(u => u.subject_id === +f.subjectId.value && u.grade === +f.grade.value);
    setHTML(f.unitId, html`${us.map(u => html`<option value="${u.id}">${u.title}</option>`)}<option value="">No unit</option><option value="new">New unit…</option>`);
    $('#n-ut-wrap', ctx.view).hidden = f.unitId.value !== 'new';
  };
  fillUnits();
  f.addEventListener('change', e => { if (e.target.name !== 'unitId') fillUnits(); $('#n-ut-wrap', ctx.view).hidden = f.unitId.value !== 'new'; });
  f.addEventListener('submit', async e => {
    e.preventDefault();
    try {
      const body = { subjectId: +f.subjectId.value, grade: +f.grade.value, number: +f.number.value, title: f.title.value, summary: f.summary.value };
      if (f.unitId.value === 'new') body.unitTitle = f.unitTitle.value; else if (f.unitId.value) body.unitId = +f.unitId.value;
      const r = await api('/admin/lessons', { method: 'POST', body });
      toast('Lesson created as a draft'); refreshCatalog(); navigate(`/admin/lessons/${r.key}`);
    } catch (err) { setHTML($('#n-msg', ctx.view), errorBox(err.message)); }
  });
}

// ---------- lesson editor ----------
const SNIPPETS = {
  section: '<section>\n  <h2>Section title</h2>\n  <p>Text…</p>\n</section>\n',
  def: '<aside class="callout callout-def"><p class="callout-title">Definition</p><div class="callout-body"><p><b>Term</b> — meaning.</p></div></aside>\n',
  example: '<aside class="callout callout-example"><p class="callout-title">Worked example</p><div class="callout-body"><p>…</p></div></aside>\n',
  exam: '<aside class="callout callout-exam"><p class="callout-title">Exam tip</p><div class="callout-body"><p>…</p></div></aside>\n',
  fact: '<aside class="callout callout-fact"><p class="callout-title">Did you know?</p><div class="callout-body"><p>…</p></div></aside>\n',
  formula: '<p class="formula">a = (v − u) ÷ t</p>\n',
  table: '<table>\n  <thead><tr><th>Heading</th><th>Heading</th></tr></thead>\n  <tbody><tr><td>…</td><td>…</td></tr></tbody>\n</table>\n',
  points: '<ul class="key-points">\n  <li>Key point with a <mark>highlighted fact</mark>.</li>\n</ul>\n',
  answer: '<details><summary>Show answer</summary><p>…</p></details>\n'
};

export async function editLesson(ctx) {
  ctx.title('Admin: edit lesson');
  setHTML(ctx.view, loading());
  const [{ lesson: L }, sj] = await Promise.all([api(`/admin/lessons/${encodeURIComponent(ctx.params.key)}`), api('/admin/subjects')]); if (ctx.stale()) return;
  ctx.title(`Edit: ${L.title}`);
  const tabs = [['details', 'Details'], ['notes', 'Notes'], ['cards', `Flashcards (${L.flashcards.length})`], ['questions', `Questions (${L.questions.length})`], ['preview', 'Preview']];
  let cur = ctx.query.get('tab') || 'details';
  let dirty = false;
  const markDirty = () => { dirty = true; };
  window.onbeforeunload = () => dirty ? true : undefined;
  ctx.onLeave(() => { window.onbeforeunload = null; });

  setHTML(ctx.view, html`${head(L.title, null, html`${L.published ? html`<a class="btn secondary" href="/lessons/${L.key}">${icon('eye')}View live</a>` : ''}`)}
    <p class="muted small" style="margin-top:-12px">${L.subject.name}, Grade ${L.grade}${L.unit ? `, ${L.unit.title}` : ''}. Sources: ${L.sources.join(', ') || 'manual'}. ${L.published ? 'Published.' : 'Not published.'}
    ${L.locked ? html` <span class="pill" title="Re-importing the source sites won't overwrite this lesson">Edited here</span>` : ''}</p>
    <div class="tabs" role="tablist" aria-label="Editor sections">${tabs.map(([k, t]) => html`<button role="tab" type="button" data-k="${k}" aria-selected="${k === cur}">${t}</button>`)}</div>
    <div id="ed"></div>`);
  const ed = $('#ed', ctx.view);
  $$('[role=tab]', ctx.view).forEach(b => b.onclick = async () => {
    if (dirty && !(await confirmDialog({ title: 'Leave without saving?', body: 'You have changes on this tab that aren’t saved.', confirm: 'Leave without saving', danger: true }))) return;
    dirty = false; cur = b.dataset.k; $$('[role=tab]', ctx.view).forEach(x => x.setAttribute('aria-selected', x === b));
    history.replaceState({}, '', `${location.pathname}?tab=${cur}`); draw();
  });
  const reload = async () => { const r = await api(`/admin/lessons/${encodeURIComponent(L.key)}`); Object.assign(L, r.lesson); refreshCatalog(); };
  const draw = () => ({ details, notes, cards, questions, preview })[cur]();

  // Details
  function details() {
    const units = sj.units.filter(u => u.subject_id === L.subject.id && u.grade === L.grade);
    setHTML(ed, html`<div class="dash-grid"><form class="panel form" id="df" novalidate>
      <div class="field"><label for="d-t">Title</label><input class="input" id="d-t" name="title" value="${L.title}" maxlength="140"></div>
      <div class="field"><label for="d-h">Hook line</label><input class="input" id="d-h" name="hook" value="${L.hook || ''}" maxlength="300"><span class="hint">One friendly sentence shown under the title.</span></div>
      <div class="field"><label for="d-s">Short description</label><textarea class="input" id="d-s" name="summary" maxlength="1000" style="min-height:90px">${L.summary}</textarea></div>
      <div class="editor-grid">
        <div class="field"><label for="d-sub">Subject</label><select class="input" id="d-sub" name="subjectId">${sj.subjects.map(s => html`<option value="${s.id}" ${s.id === L.subject.id ? raw('selected') : ''}>${s.name}</option>`)}</select></div>
        <div class="field"><label for="d-g">Grade</label><input class="input" id="d-g" name="grade" type="number" min="1" max="13" value="${L.grade}"></div>
        <div class="field"><label for="d-n">Chapter number</label><input class="input" id="d-n" name="number" type="number" min="0" value="${L.number}"></div>
        <div class="field"><label for="d-u">Unit</label><select class="input" id="d-u" name="unitId"><option value="">No unit</option>${units.map(u => html`<option value="${u.id}" ${L.unit && L.unit.id === u.id ? raw('selected') : ''}>${u.title}</option>`)}</select></div>
        <div class="field"><label for="d-d">Difficulty</label><select class="input" id="d-d" name="difficulty"><option value="">Not set</option>${['foundation', 'core', 'extension'].map(d => html`<option value="${d}" ${L.difficulty === d ? raw('selected') : ''}>${d[0].toUpperCase() + d.slice(1)}</option>`)}</select></div>
        <div class="field"><label for="d-img">Cover image address</label><input class="input" id="d-img" name="image" value="${L.image ? L.image.url : ''}" placeholder="/media/uploads/…"><span class="hint">Copy an address from <a href="/admin/media">Files</a>.</span></div>
      </div>
      <label class="check"><input type="checkbox" name="guest" ${L.guest ? raw('checked') : ''}><span>Free for guests (readable without an account)</span></label>
      <div id="d-msg"></div>
      <div class="btn-row"><button class="btn" type="submit">Save details</button></div></form>
      <aside class="form">
        <section class="panel"><h2>Publishing</h2><p class="muted small">${L.published ? 'Students can see this lesson.' : 'Only administrators can see this lesson.'}</p>
          <button class="btn ${L.published ? 'secondary' : ''}" id="pubBtn" type="button">${L.published ? 'Unpublish' : 'Publish'}</button></section>
        ${L.locked && L.sources.some(s => s !== 'manual') ? html`<section class="panel"><h2>Re-import</h2><p class="muted small">This lesson has been edited here, so importing the source sites again skips it. Allow the import to replace it with the source version?</p>
          <button class="btn secondary" id="unlockBtn" type="button">Allow re-import to replace it</button></section>` : ''}
        <section class="panel"><h2>Delete lesson</h2><p class="muted small">Removes the lesson with its notes, flashcards and questions, and students’ bookmarks of it.</p><button class="btn danger small" id="delBtn" type="button">${icon('trash')}Delete lesson</button></section>
      </aside></div>`);
    const f = $('#df', ed); f.addEventListener('input', markDirty);
    f.addEventListener('submit', async e => {
      e.preventDefault();
      try {
        await api(`/admin/lessons/${L.id}`, { method: 'PATCH', body: { title: f.title.value, hook: f.hook.value, summary: f.summary.value, subjectId: +f.subjectId.value, grade: +f.grade.value, number: +f.number.value,
          unitId: f.unitId.value ? +f.unitId.value : null, difficulty: f.difficulty.value, guest: f.guest.checked, image: f.image.value.trim() ? { url: f.image.value.trim(), alt: L.title, caption: '' } : null } });
        dirty = false; await reload(); toast('Details saved'); details();
      } catch (err) { setHTML($('#d-msg', ed), errorBox(err.message)); }
    });
    $('#pubBtn', ed).onclick = async () => {
      const on = !L.published;
      if (!(await confirmDialog({ title: on ? 'Publish this lesson?' : 'Unpublish this lesson?', body: on ? 'Students will be able to find and read it straight away.' : 'Students won’t see it any more. Their bookmarks and progress are kept.', confirm: on ? 'Publish' : 'Unpublish' }))) return;
      try { await api(`/admin/lessons/${L.id}`, { method: 'PATCH', body: { published: on } }); await reload(); toast(on ? 'Published' : 'Unpublished'); editLesson(ctx); }
      catch (err) { toast(err.message, 'error'); }
    };
    const ub = $('#unlockBtn', ed); if (ub) ub.onclick = async () => { try { await api(`/admin/lessons/${L.id}`, { method: 'PATCH', body: { locked: false } }); toast('The next import will replace this lesson.'); await reload(); details(); } catch (err) { toast(err.message, 'error'); } };
    $('#delBtn', ed).onclick = async () => {
      const v = await confirmDialog({ title: `Delete “${L.title}”?`, body: 'This can’t be undone.', confirm: 'Delete lesson', danger: true, typeToConfirm: 'delete' }); if (!v) return;
      try { await api(`/admin/lessons/${L.id}`, { method: 'DELETE', body: { confirm: v } }); dirty = false; toast('Lesson deleted'); refreshCatalog(); navigate('/admin/content'); }
      catch (err) { toast(err.message, 'error'); }
    };
  }

  // Notes (HTML editor + live preview)
  function notes() {
    const work = L.notes.map(n => ({ ...n }));
    let sel = 0;
    function drawNotes() {
      const n = work[sel];
      setHTML(ed, html`<div class="btn-row" style="margin-bottom:12px">${work.map((x, i) => html`<button class="btn small ${i === sel ? '' : 'secondary'}" type="button" data-i="${i}">${x.title}</button>`)}
        <button class="btn small ghost" type="button" id="addTab">${icon('plus')}Add tab</button></div>
        <div class="editor-grid">
          <div class="form">
            <div class="editor-grid"><div class="field"><label for="nt-t">Tab name</label><input class="input" id="nt-t" value="${n.title}" maxlength="40"></div>
              <div class="field"><label for="nt-k">Type</label><select class="input" id="nt-k">${[['short', 'Short notes'], ['detailed', 'Detailed notes'], ['notes', 'Notes']].map(([v, t]) => html`<option value="${v}" ${n.kind === v ? raw('selected') : ''}>${t}</option>`)}</select></div></div>
            <div class="field"><span class="label">Insert</span><div class="btn-row">${Object.keys(SNIPPETS).map(k => html`<button class="btn small secondary" type="button" data-snip="${k}">${{ section: 'Section', def: 'Definition', example: 'Example', exam: 'Exam tip', fact: 'Fact', formula: 'Formula', table: 'Table', points: 'Key points', answer: 'Hidden answer' }[k]}</button>`)}
              <button class="btn small secondary" type="button" id="insImg">${icon('upload')}Image</button></div></div>
            <div class="field"><label for="nt-h">HTML</label><textarea class="input code-area" id="nt-h" spellcheck="false">${n.html}</textarea>
              <span class="hint">Each &lt;h2&gt; becomes an entry in the note’s contents. Scripts and event attributes are removed when you save.</span></div>
            <div id="nt-msg"></div>
            <div class="btn-row"><button class="btn" id="saveNotes" type="button">Save notes</button>${work.length > 1 ? html`<button class="btn ghost small" id="rmTab" type="button">${icon('trash')}Remove this tab</button>` : ''}</div>
          </div>
          <div><div class="label" style="font-weight:700;margin-bottom:6px">Live preview</div><div class="preview-frame"><article class="prose ${n.scope || ''}" id="nt-prev"></article></div></div>
        </div>`);
      const ta = $('#nt-h', ed), prev = $('#nt-prev', ed);
      const upd = debounce(() => { setHTML(prev, raw(ta.value.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/\son\w+\s*=/gi, ' data-x='))); import('./lesson.js').then(m => m.mountActivities(prev)); }, 250);
      upd();
      ta.addEventListener('input', () => { work[sel].html = ta.value; markDirty(); upd(); });
      $('#nt-t', ed).addEventListener('input', e => { work[sel].title = e.target.value; markDirty(); });
      $('#nt-k', ed).addEventListener('change', e => { work[sel].kind = e.target.value; markDirty(); });
      $$('[data-i]', ed).forEach(b => b.onclick = () => { sel = +b.dataset.i; drawNotes(); });
      $$('[data-snip]', ed).forEach(b => b.onclick = () => insert(SNIPPETS[b.dataset.snip]));
      function insert(text) { const s = ta.selectionStart, e = ta.selectionEnd; ta.setRangeText(text, s, e, 'end'); ta.focus(); ta.dispatchEvent(new Event('input')); }
      $('#insImg', ed).onclick = async () => {
        const { media } = await api('/admin/media'); const imgs = media.filter(m => m.type.startsWith('image/'));
        const d = document.createElement('dialog'); d.className = 'modal'; d.style.maxWidth = '820px';
        setHTML(d, html`<form method="dialog"><div class="m-body"><h2>Insert an image</h2>${imgs.length ? html`<div class="media-grid" style="max-height:55vh;overflow:auto">${imgs.slice(0, 120).map(m => html`<button class="media-item" style="cursor:pointer;text-align:left" value="${m.id}"><div class="mthumb"><img src="${m.url}" alt="" loading="lazy"></div><div class="mbody"><span>${m.name}</span></div></button>`)}</div>` : html`<p>No images yet. <a href="/admin/media">Upload one in Files</a>.</p>`}</div><div class="m-foot"><button class="btn secondary" value="">Cancel</button></div></form>`);
        document.body.appendChild(d); d.showModal();
        d.addEventListener('close', () => { const m = imgs.find(x => String(x.id) === d.returnValue); d.remove(); if (m) insert(`<figure><img src="${m.url}" alt="Describe the image"><figcaption>Caption</figcaption></figure>\n`); });
      };
      $('#addTab', ed).onclick = () => { work.push({ kind: 'notes', title: 'New tab', html: SNIPPETS.section }); sel = work.length - 1; markDirty(); drawNotes(); };
      const rm = $('#rmTab', ed); if (rm) rm.onclick = async () => { if (await confirmDialog({ title: `Remove “${work[sel].title}”?`, body: 'The tab is deleted when you save.', confirm: 'Remove tab', danger: true })) { work.splice(sel, 1); sel = 0; markDirty(); drawNotes(); } };
      $('#saveNotes', ed).onclick = async () => {
        try {
          const r = await api(`/admin/lessons/${L.id}/notes`, { method: 'PUT', body: { notes: work.map(x => ({ id: x.id, kind: x.kind, title: x.title, html: x.html, scope: x.scope })) } });
          dirty = false; await reload(); toast(r.removed ? 'Saved. Some unsafe code was removed.' : 'Notes saved'); notes();
        } catch (err) { setHTML($('#nt-msg', ed), errorBox(err.message)); }
      };
    }
    drawNotes();
  }

  // Flashcards
  function cards() {
    const work = L.flashcards.map(c => ({ ...c }));
    const originTxt = { imported: 'From the source notes', extracted: 'Picked out automatically', generated: 'Auto-generated', manual: 'Written here' };
    function drawCards() {
      setHTML(ed, html`<p class="muted">Cards marked “Picked out automatically” were taken from definitions in the notes by the importer. Tick <b>Checked</b> once you’ve read them.</p>
        <div class="items">${work.map((c, i) => html`<div class="item-editor" data-i="${i}"><div class="row">
          <div class="field"><label for="cf-${i}">Front (${i + 1})</label><textarea class="input" id="cf-${i}" data-f="front" style="min-height:70px">${c.front}</textarea></div>
          <div class="field"><label for="cb-${i}">Back</label><textarea class="input" id="cb-${i}" data-f="back" style="min-height:70px">${c.back}</textarea></div></div>
          <div class="btn-row"><span class="pill ${c.origin === 'extracted' || c.origin === 'generated' ? 'gen' : ''}">${originTxt[c.origin] || c.origin}</span>
            <label class="check small"><input type="checkbox" data-f="reviewed" ${c.reviewed ? raw('checked') : ''}><span>Checked</span></label><span class="grow" style="flex:1"></span>
            <button class="btn small ghost" type="button" data-rm="${i}">${icon('trash')}Remove</button></div></div>`)}</div>
        <div class="btn-row section" style="margin-top:16px"><button class="btn secondary" type="button" id="addC">${icon('plus')}Add card</button><button class="btn" type="button" id="saveC">Save flashcards</button></div><div id="c-msg"></div>`);
      ed.oninput = e => { const it = e.target.closest('[data-i]'); if (!it || !e.target.dataset.f) return; const c = work[+it.dataset.i]; c[e.target.dataset.f] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; markDirty(); };
      ed.onchange = ed.oninput;
      $$('[data-rm]', ed).forEach(b => b.onclick = () => { work.splice(+b.dataset.rm, 1); markDirty(); drawCards(); });
      $('#addC', ed).onclick = () => { work.push({ front: '', back: '', origin: 'manual', reviewed: 1 }); markDirty(); drawCards(); $(`#cf-${work.length - 1}`, ed).focus(); };
      $('#saveC', ed).onclick = async () => {
        try { await api(`/admin/lessons/${L.id}/flashcards`, { method: 'PUT', body: { flashcards: work } }); dirty = false; await reload(); toast('Flashcards saved'); cards(); }
        catch (err) { setHTML($('#c-msg', ed), errorBox(err.message)); }
      };
    }
    drawCards();
  }

  // Questions
  function questions() {
    const work = L.questions.map(q => ({ ...q, options: [...q.options] }));
    let onlyUnrev = false;
    const originTxt = { imported: 'From the source notes', generated: 'Auto-generated', manual: 'Written here' };
    function drawQs() {
      setHTML(ed, html`<div class="notice small">Auto-generated questions are shown to students with an “Auto-generated, not yet reviewed” label until you tick <b>Teacher-reviewed</b>. Reviewed questions are kept when the sources are imported again.</div>
        <label class="check" style="margin:10px 0"><input type="checkbox" id="onlyU" ${onlyUnrev ? raw('checked') : ''}><span>Show only questions that need reviewing (${work.filter(q => q.origin === 'generated' && !q.reviewed).length})</span></label>
        <div class="items">${work.map((q, i) => (onlyUnrev && !(q.origin === 'generated' && !q.reviewed)) ? '' : html`<div class="item-editor" data-i="${i}">
          <div class="row"><div class="field"><label for="qt-${i}">Type</label><select class="input" id="qt-${i}" data-f="type"><option value="mcq" ${q.type === 'mcq' ? raw('selected') : ''}>Multiple choice</option><option value="tf" ${q.type === 'tf' ? raw('selected') : ''}>True or false</option></select></div>
            <div class="field"><label for="qa-${i}">Correct answer</label><select class="input" id="qa-${i}" data-f="answer">${(q.type === 'tf' ? ['True', 'False'] : q.options).map((o, j) => html`<option value="${j}" ${q.answer === j ? raw('selected') : ''}>${String.fromCharCode(65 + j)}: ${o.replace(/<[^>]+>/g, '').slice(0, 60)}</option>`)}</select></div></div>
          <div class="field"><label for="qp-${i}">Question ${i + 1}</label><textarea class="input" id="qp-${i}" data-f="prompt" style="min-height:64px">${q.prompt}</textarea></div>
          ${q.type === 'mcq' ? html`<div class="field"><label for="qo-${i}">Options, one per line (2 to 6)</label><textarea class="input" id="qo-${i}" data-f="options" style="min-height:96px">${q.options.join('\n')}</textarea></div>` : ''}
          <div class="field"><label for="qe-${i}">Explanation shown after answering</label><textarea class="input" id="qe-${i}" data-f="explanation" style="min-height:56px">${q.explanation}</textarea></div>
          <div class="btn-row"><span class="pill ${q.origin === 'generated' ? 'gen' : ''}">${originTxt[q.origin] || q.origin}</span><label class="check small"><input type="checkbox" data-f="reviewed" ${q.reviewed ? raw('checked') : ''}><span>Teacher-reviewed</span></label>
            <span style="flex:1"></span><button class="btn small ghost" type="button" data-rm="${i}">${icon('trash')}Remove</button></div></div>`)}</div>
        <div class="btn-row" style="margin-top:16px"><button class="btn secondary" type="button" id="addQ">${icon('plus')}Add question</button><button class="btn" type="button" id="saveQ">Save questions</button></div><div id="q-msg"></div>`);
      $('#onlyU', ed).onchange = e => { onlyUnrev = e.target.checked; drawQs(); };
      ed.oninput = e => {
        const it = e.target.closest('[data-i]'); const f = e.target.dataset.f; if (!it || !f) return;
        const q = work[+it.dataset.i];
        if (f === 'options') q.options = e.target.value.split('\n').map(s => s.trim()).filter(Boolean);
        else if (f === 'answer') q.answer = +e.target.value;
        else if (f === 'reviewed') q.reviewed = e.target.checked;
        else if (f === 'type') { q.type = e.target.value; if (q.type === 'tf') { q.options = ['True', 'False']; q.answer = Math.min(q.answer, 1); } markDirty(); drawQs(); return; }
        else q[f] = e.target.value;
        markDirty();
      };
      ed.onchange = e => { if (['type', 'answer', 'reviewed'].includes(e.target.dataset.f)) ed.oninput(e); if (e.target.dataset.f === 'options') drawQs(); };
      $$('[data-rm]', ed).forEach(b => b.onclick = () => { work.splice(+b.dataset.rm, 1); markDirty(); drawQs(); });
      $('#addQ', ed).onclick = () => { work.push({ type: 'mcq', prompt: '', options: ['', '', '', ''], answer: 0, explanation: '', origin: 'manual', reviewed: 1 }); onlyUnrev = false; markDirty(); drawQs(); $(`#qp-${work.length - 1}`, ed).focus(); };
      $('#saveQ', ed).onclick = async () => {
        try { await api(`/admin/lessons/${L.id}/questions`, { method: 'PUT', body: { questions: work } }); dirty = false; await reload(); toast('Questions saved'); questions(); }
        catch (err) { setHTML($('#q-msg', ed), errorBox(err.message)); }
      };
    }
    drawQs();
  }

  function preview() {
    ed.onchange = ed.oninput = null;
    renderLesson({ query: new URLSearchParams(), appName: ctx.appName }, L, null, { preview: true, host: ed,
      banner: html`<div class="badge-preview"><span>Preview: ${L.published ? 'this is what students see' : 'not published, students can’t see this yet'}</span></div>` });
  }
  draw();
}

// ---------- subjects & units ----------
export async function subjects(ctx) {
  ctx.title('Admin: subjects');
  const data = await api('/admin/subjects'); if (ctx.stale()) return;
  setHTML(ctx.view, html`${head('Subjects & units', 'Subjects appear on the shelf; units group lessons inside each grade.')}
  <div class="items">${data.subjects.map(s => html`<form class="panel form subj" data-id="${s.id}" novalidate>
    <div style="display:flex;gap:14px;align-items:center"><span class="thumb" style="--c:${s.color};width:48px;height:48px">${icon(s.icon)}</span><div><h2 style="margin:0">${s.name}</h2><span class="muted small">/subjects/${s.slug}, ${plural(s.lessons, 'lesson')}${s.published ? '' : ', hidden'}</span></div></div>
    <div class="editor-grid"><div class="field"><label>Name<input class="input" name="name" value="${s.name}"></label></div>
      <div class="field"><label>Colour<input class="input" name="color" type="color" value="${s.color}" style="padding:4px;height:44px"></label></div>
      <div class="field"><label>Icon<select class="input" name="icon">${SUBJECT_ICONS.map(i => html`<option ${i === s.icon ? raw('selected') : ''}>${i}</option>`)}</select></label></div>
      <div class="field"><label>Order on the shelf<input class="input" name="position" type="number" min="0" value="${s.position}"></label></div></div>
    <div class="field"><label>Description<textarea class="input" name="description" style="min-height:70px">${s.description}</textarea></label></div>
    <label class="check"><input type="checkbox" name="published" ${s.published ? raw('checked') : ''}><span>Show this subject to students</span></label>
    <details><summary><b>Units (${data.units.filter(u => u.subject_id === s.id).length})</b></summary>
      <div class="tablewrap" style="margin-top:10px"><table class="data"><thead><tr><th>Grade</th><th>Unit</th><th>Order</th><th>Lessons</th><th></th></tr></thead><tbody>
      ${data.units.filter(u => u.subject_id === s.id).map(u => html`<tr data-unit="${u.id}"><td>${u.grade}</td><td><input class="input" value="${u.title}" data-ut aria-label="Unit name"></td><td><input class="input" type="number" min="0" value="${u.position}" data-up style="width:80px" aria-label="Order"></td><td class="num">${u.lessons}</td>
        <td><div class="btn-row" style="flex-wrap:nowrap"><button class="btn small secondary" type="button" data-usave>Save</button><button class="btn small ghost" type="button" data-udel aria-label="Delete unit ${u.title}">${icon('trash')}</button></div></td></tr>`)}
      </tbody></table></div>
      <div class="btn-row" style="margin-top:10px"><input class="input" placeholder="New unit name" data-nut style="max-width:260px" aria-label="New unit name"><input class="input" type="number" min="1" max="13" value="10" data-nug style="max-width:90px" aria-label="Grade"><button class="btn small secondary" type="button" data-uadd>${icon('plus')}Add unit</button></div>
    </details>
    <div class="msg"></div>
    <div class="btn-row"><button class="btn" type="submit">Save subject</button><button class="btn ghost small" type="button" data-sdel>${icon('trash')}Delete subject</button></div></form>`)}</div>
  <form class="panel form section" id="newS" novalidate><h2>Add a subject</h2>
    <div class="editor-grid"><div class="field"><label for="ns-n">Name</label><input class="input" id="ns-n" name="name" placeholder="e.g. Mathematics"></div>
      <div class="field"><label for="ns-c">Colour</label><input class="input" id="ns-c" name="color" type="color" value="#2f5bd3" style="padding:4px;height:44px"></div>
      <div class="field"><label for="ns-i">Icon</label><select class="input" id="ns-i" name="icon">${SUBJECT_ICONS.map(i => html`<option>${i}</option>`)}</select></div></div>
    <div class="field"><label for="ns-d">Description</label><textarea class="input" id="ns-d" name="description" style="min-height:70px"></textarea></div>
    <div class="msg"></div><div><button class="btn" type="submit">${icon('plus')}Add subject</button></div></form>`);
  const again = () => { refreshCatalog(); subjects(ctx); };
  $$('form.subj', ctx.view).forEach(f => {
    const id = +f.dataset.id; const s = data.subjects.find(x => x.id === id);
    f.addEventListener('submit', async e => { e.preventDefault(); try { await api(`/admin/subjects/${id}`, { method: 'PATCH', body: { name: f.name.value, color: f.color.value, icon: f.icon.value, position: +f.position.value, description: f.description.value, published: f.published.checked } }); toast('Subject saved'); again(); } catch (err) { setHTML($('.msg', f), errorBox(err.message)); } });
    $('[data-sdel]', f).onclick = async () => {
      const v = await confirmDialog({ title: `Delete ${s.name}?`, body: `This also deletes its <b>${plural(s.lessons, 'lesson')}</b>, with their notes and questions, and students’ progress on them. It can’t be undone.`, confirm: 'Delete subject', danger: true, typeToConfirm: s.slug });
      if (!v) return; try { await api(`/admin/subjects/${id}`, { method: 'DELETE', body: { confirm: v } }); toast('Subject deleted'); again(); } catch (err) { toast(err.message, 'error'); }
    };
    $$('tr[data-unit]', f).forEach(tr => {
      const uid = +tr.dataset.unit;
      $('[data-usave]', tr).onclick = async () => { try { await api(`/admin/units/${uid}`, { method: 'PATCH', body: { title: $('[data-ut]', tr).value, position: +$('[data-up]', tr).value } }); toast('Unit saved'); refreshCatalog(); } catch (err) { toast(err.message, 'error'); } };
      $('[data-udel]', tr).onclick = async () => { if (!(await confirmDialog({ title: 'Delete this unit?', body: 'Its lessons are kept and moved to “no unit”.', confirm: 'Delete unit', danger: true }))) return; try { await api(`/admin/units/${uid}`, { method: 'DELETE' }); toast('Unit deleted'); again(); } catch (err) { toast(err.message, 'error'); } };
    });
    $('[data-uadd]', f).onclick = async () => { try { await api('/admin/units', { method: 'POST', body: { subjectId: id, grade: +$('[data-nug]', f).value, title: $('[data-nut]', f).value } }); toast('Unit added'); again(); } catch (err) { setHTML($('.msg', f), errorBox(err.message)); } };
  });
  $('#newS', ctx.view).addEventListener('submit', async e => { e.preventDefault(); const f = e.target; try { await api('/admin/subjects', { method: 'POST', body: { name: f.name.value, color: f.color.value, icon: f.icon.value, description: f.description.value } }); toast('Subject added'); again(); } catch (err) { setHTML($('.msg', f), errorBox(err.message)); } });
}

// ---------- media ----------
export async function media(ctx) {
  ctx.title('Admin: files');
  const { media } = await api('/admin/media'); if (ctx.stale()) return;
  const uploads = media.filter(m => m.origin === 'upload'), imported = media.filter(m => m.origin !== 'upload');
  const item = m => html`<div class="media-item"><div class="mthumb">${m.type.startsWith('image/') ? html`<img src="${m.url}" alt="" loading="lazy">` : html`${icon('notes', 'width="36" height="36"')}`}</div>
    <div class="mbody"><span title="${m.name}">${m.name}</span><span class="muted">${(m.bytes / 1024).toFixed(0)} KB, ${fmtDate(m.created_at)}</span>
    <div class="btn-row"><button class="btn small secondary" type="button" data-copy="${m.url}">Copy address</button><button class="btn small ghost" type="button" data-del="${m.id}" aria-label="Delete ${m.name}">${icon('trash')}</button></div></div></div>`;
  setHTML(ctx.view, html`${head('Files', 'Images, diagrams and documents for your notes. Copy a file’s address to use it in a note or as a cover image.')}
    <div class="dropzone" id="dz"><p><b>Drop files here</b> or</p><label class="btn secondary">${icon('upload')}Choose files<input type="file" id="fi" multiple accept="image/*,.pdf,.docx,.pptx" hidden></label>
      <p class="small muted" style="margin-top:10px">JPG, PNG, WebP, GIF, SVG, PDF, Word or PowerPoint, up to 15 MB each.</p><div id="up-msg"></div></div>
    <section class="section"><div class="section-head"><h2>Uploaded (${uploads.length})</h2></div>${uploads.length ? html`<div class="media-grid">${uploads.map(item)}</div>` : html`<div class="empty small">Nothing uploaded yet.</div>`}</section>
    <section class="section"><div class="section-head"><h2>Imported from the source sites (${imported.length})</h2></div>${imported.length ? html`<div class="media-grid">${imported.map(item)}</div>` : html`<div class="empty small">None.</div>`}</section>`);
  const dz = $('#dz', ctx.view);
  const send = async files => {
    if (!files.length) return; const fd = new FormData(); [...files].forEach(f => fd.append('files', f));
    setHTML($('#up-msg', ctx.view), loading('Uploading…'));
    try { const r = await api('/admin/media', { method: 'POST', form: fd }); toast(`${plural(r.media.length, 'file')} uploaded`); media(ctx); }
    catch (err) { setHTML($('#up-msg', ctx.view), errorBox(err.message)); }
  };
  $('#fi', ctx.view).onchange = e => send(e.target.files);
  ['dragenter', 'dragover'].forEach(t => dz.addEventListener(t, e => { e.preventDefault(); dz.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(t => dz.addEventListener(t, e => { e.preventDefault(); dz.classList.remove('over'); }));
  dz.addEventListener('drop', e => send(e.dataTransfer.files));
  ctx.view.addEventListener('click', async e => {
    const c = e.target.closest('[data-copy]'); if (c) { try { await navigator.clipboard.writeText(c.dataset.copy); toast('Address copied'); } catch (_) { infoDialog('File address', `<p><code>${esc(c.dataset.copy)}</code></p>`); } return; }
    const d = e.target.closest('[data-del]'); if (!d) return;
    const m = media.find(x => x.id === +d.dataset.del);
    if (!(await confirmDialog({ title: `Delete ${esc(m.name)}?`, body: 'Notes that use this file will show a broken image.', confirm: 'Delete file', danger: true }))) return;
    try { await api(`/admin/media/${m.id}`, { method: 'DELETE', body: {} }); toast('File deleted'); media(ctx); }
    catch (err) {
      if (err.status === 409) { const v = await confirmDialog({ title: 'This file is in use', body: esc(err.message), confirm: 'Delete anyway', danger: true, typeToConfirm: 'delete' }); if (v) { await api(`/admin/media/${m.id}`, { method: 'DELETE', body: { confirm: v } }); toast('File deleted'); media(ctx); } }
      else toast(err.message, 'error');
    }
  });
}

// ---------- users ----------
export async function users(ctx) {
  ctx.title('Admin: users');
  setHTML(ctx.view, html`${head('Users', 'Student and administrator accounts. Students’ scores are never shown publicly.')}
    <form class="filters" id="uf" role="search"><div class="field search-field"><label for="u-q">Search by name or email</label><input class="input" id="u-q" type="search"></div></form><div id="ut">${loading()}</div>`);
  const load = async () => {
    const { users } = await api('/admin/users?q=' + encodeURIComponent($('#u-q', ctx.view).value)); if (ctx.stale()) return;
    setHTML($('#ut', ctx.view), html`<p class="result-count">${plural(users.length, 'account')}</p><div class="tablewrap"><table class="data"><thead><tr><th>Name</th><th>Role</th><th>Grade</th><th>Joined</th><th>Last log-in</th><th>Lessons done</th><th>Actions</th></tr></thead><tbody>
      ${users.map(u => html`<tr data-id="${u.id}"><td><b>${u.name}</b><div class="small muted">${u.email}</div>${u.disabled ? html`<span class="pill">Turned off</span>` : ''}</td>
        <td>${u.role === 'admin' ? html`<span class="pill ok">Admin</span>` : 'Student'}</td><td>${u.grade || '—'}</td><td>${fmtDate(u.created_at)}</td><td>${u.last_login_at ? fmtAgo(u.last_login_at) : 'Never'}</td><td class="num">${u.completed}</td>
        <td><div class="btn-row" style="flex-wrap:nowrap">
          <button class="btn small secondary" type="button" data-a="role">${u.role === 'admin' ? 'Make student' : 'Make admin'}</button>
          <button class="btn small secondary" type="button" data-a="disable">${u.disabled ? 'Turn on' : 'Turn off'}</button>
          <button class="btn small secondary" type="button" data-a="reset">Reset password</button>
          <button class="btn small ghost" type="button" data-a="delete" aria-label="Delete ${u.name}">${icon('trash')}</button></div></td></tr>`)}</tbody></table></div>`);
    $$('tr[data-id]', ctx.view).forEach(tr => {
      const u = users.find(x => x.id === +tr.dataset.id);
      tr.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => {
        const a = b.dataset.a;
        try {
          if (a === 'role') {
            const to = u.role === 'admin' ? 'student' : 'admin';
            if (!(await confirmDialog({ title: to === 'admin' ? `Make ${esc(u.name)} an administrator?` : `Remove ${esc(u.name)}’s admin access?`, body: to === 'admin' ? 'Administrators can edit all notes and manage every account.' : 'They will keep their student account.', confirm: to === 'admin' ? 'Make admin' : 'Make student' }))) return;
            await api(`/admin/users/${u.id}`, { method: 'PATCH', body: { role: to } }); toast('Role updated');
          } else if (a === 'disable') {
            if (!(await confirmDialog({ title: u.disabled ? `Turn ${esc(u.name)}’s account back on?` : `Turn off ${esc(u.name)}’s account?`, body: u.disabled ? 'They’ll be able to log in again.' : 'They’ll be logged out and can’t log in until you turn the account back on. Their progress is kept.', confirm: u.disabled ? 'Turn on' : 'Turn off', danger: !u.disabled }))) return;
            await api(`/admin/users/${u.id}`, { method: 'PATCH', body: { disabled: !u.disabled } }); toast(u.disabled ? 'Account turned on' : 'Account turned off');
          } else if (a === 'reset') {
            if (!(await confirmDialog({ title: `Reset ${esc(u.name)}’s password?`, body: 'They’ll get a one-hour link to choose a new password.', confirm: 'Create reset link' }))) return;
            const r = await api(`/admin/users/${u.id}/reset`, { method: 'POST' });
            if (r.link) infoDialog('Reset link', `<p>${esc(r.message)}</p><p><input class="input" readonly value="${esc(r.link)}"></p>`); else toast(r.message);
            return;
          } else if (a === 'delete') {
            const v = await confirmDialog({ title: `Delete ${esc(u.name)}’s account?`, body: 'Their bookmarks, progress and quiz scores are deleted too. This can’t be undone.', confirm: 'Delete account', danger: true, typeToConfirm: 'delete' }); if (!v) return;
            await api(`/admin/users/${u.id}`, { method: 'DELETE', body: { confirm: v } }); toast('Account deleted');
          }
          load();
        } catch (err) { toast(err.message, 'error'); }
      });
    });
  };
  $('#u-q', ctx.view).addEventListener('input', debounce(load, 300)); $('#uf', ctx.view).addEventListener('submit', e => { e.preventDefault(); load(); });
  load();
}

// ---------- import ----------
export async function importPage(ctx) {
  ctx.title('Admin: import');
  setHTML(ctx.view, html`${head('Import', 'Bring notes in from the original note websites.')}${loading()}`);
  const runParam = ctx.query.get('run');
  const d = await api('/admin/import' + (runParam ? `?run=${runParam}` : '')); if (ctx.stale()) return;
  const run = d.runs.find(r => r.id === d.runId);
  const levels = ['error', 'warn', 'duplicate', 'info'];
  const lvlName = { error: 'Errors', warn: 'Warnings', duplicate: 'Duplicates merged', info: 'Info' };
  setHTML(ctx.view, html`${head('Import', 'Bring notes in from the original note websites.', html`<button class="btn" id="runBtn">${icon('refresh')}Run import now</button>`)}
  <div class="dash-grid">
    <section class="panel"><h2>Source websites (${d.sources.length})</h2>
      <p class="muted small">Each file is one of the original note sites, saved as a single HTML page. The importer recognises the ICT, Science (pocket and descriptive), Business &amp; Accounting and History formats. Lessons edited here are never overwritten.</p>
      <div class="tablewrap"><table class="data"><thead><tr><th>File</th><th>Size</th><th>Updated</th><th></th></tr></thead><tbody>${d.sources.map(s => html`<tr><td>${s.file}</td><td class="num">${(s.bytes / 1024 / 1024).toFixed(1)} MB</td><td>${fmtDate(s.modified)}</td><td><button class="btn small ghost" data-src="${s.file}" aria-label="Remove ${s.file}">${icon('trash')}</button></td></tr>`)}</tbody></table></div>
      <div class="btn-row" style="margin-top:12px"><label class="btn secondary small">${icon('upload')}Add or replace a source file<input type="file" id="srcIn" accept=".html,.htm" multiple hidden></label></div><div id="src-msg"></div></section>
    <section class="panel"><h2>Import history</h2>${d.runs.length ? html`<div class="tablewrap"><table class="data"><thead><tr><th>When</th><th>Result</th><th>Lessons</th><th></th></tr></thead><tbody>${d.runs.map(r => html`<tr ${r.id === d.runId ? raw('style="background:var(--sh-warn-bg)"') : ''}><td>${fmtAgo(r.started_at)}</td>
        <td>${r.status === 'ok' ? html`<span class="pill ok">OK</span>` : r.status === 'running' ? 'Running' : html`<span class="lvl error">${r.status === 'failed' ? 'Failed' : 'Errors'}</span>`}</td><td class="num">${r.summary.lessons ?? '—'}</td><td><a href="/admin/import?run=${r.id}">Report</a></td></tr>`)}</tbody></table></div>` : html`<p class="muted">No imports yet.</p>`}</section>
  </div>
  ${run ? html`<section class="section"><div class="section-head"><h2>Report for the import ${fmtAgo(run.started_at)}</h2></div>
    <div class="stat-grid">${[['lessons', 'lessons found'], ['created', 'new'], ['updated', 'updated'], ['skipped', 'kept (edited here)'], ['duplicates', 'duplicates merged'], ['warnings', 'warnings'], ['errors', 'errors']].map(([k, t]) => html`<div class="stat"><b>${run.summary[k] ?? 0}</b><span>${t}</span></div>`)}</div>
    <div class="tabs" role="tablist" aria-label="Filter by level" style="margin-top:20px"><button role="tab" aria-selected="true" data-l="">All (${d.logs.length})</button>${levels.map(l => html`<button role="tab" aria-selected="false" data-l="${l}">${lvlName[l]} (${d.logs.filter(x => x.level === l).length})</button>`)}</div>
    <label class="check small" style="margin-bottom:10px"><input type="checkbox" id="hideRes"><span>Hide items marked as reviewed</span></label>
    <div class="tablewrap"><table class="data"><thead><tr><th>Level</th><th>Message</th><th>Source</th><th>Reviewed</th></tr></thead><tbody>
      ${d.logs.map(l => html`<tr data-lvl="${l.level}" data-res="${l.resolved ? 1 : 0}"><td><span class="lvl ${l.level}">${l.level === 'warn' ? 'warning' : l.level}</span></td><td>${l.message}${l.ref ? html` <a class="small" href="/admin/lessons/${l.ref}">Open lesson</a>` : ''}</td><td class="small muted">${l.source || ''}</td>
        <td>${l.level !== 'info' ? html`<input type="checkbox" data-log="${l.id}" ${l.resolved ? raw('checked') : ''} aria-label="Mark as reviewed">` : ''}</td></tr>`)}</tbody></table></div></section>` : ''}`);

  $('#runBtn', ctx.view).onclick = async () => {
    if (!(await confirmDialog({ title: 'Run the import now?', body: 'Every source file is read again. Lessons that came from the sources are refreshed; lessons edited here and teacher-reviewed questions are kept. Students’ bookmarks and progress are not affected.', confirm: 'Run import' }))) return;
    const b = $('#runBtn', ctx.view); b.disabled = true; b.textContent = 'Importing… (about 20 seconds)';
    try { const r = await api('/admin/import/run', { method: 'POST' }); toast(`Import finished: ${r.summary.lessons} lessons`); refreshCatalog(); navigate(`/admin/import?run=${r.runId}`, { replace: true }); }
    catch (err) { toast(err.message, 'error'); b.disabled = false; b.textContent = 'Run import now'; }
  };
  $('#srcIn', ctx.view).onchange = async e => {
    const fd = new FormData(); [...e.target.files].forEach(f => fd.append('files', f));
    try { const r = await api('/admin/import/sources', { method: 'POST', form: fd }); toast(r.message); importPage(ctx); } catch (err) { setHTML($('#src-msg', ctx.view), errorBox(err.message)); }
  };
  $$('[data-src]', ctx.view).forEach(b => b.onclick = async () => {
    const v = await confirmDialog({ title: `Remove ${esc(b.dataset.src)}?`, body: 'Lessons already imported from it stay in the library.', confirm: 'Remove file', danger: true, typeToConfirm: 'delete' }); if (!v) return;
    try { await api(`/admin/import/sources/${encodeURIComponent(b.dataset.src)}`, { method: 'DELETE', body: { confirm: v } }); toast('Source removed'); importPage(ctx); } catch (err) { toast(err.message, 'error'); }
  });
  const filt = () => { const l = ($('.tabs [aria-selected=true]', ctx.view) || {}).dataset; const hide = $('#hideRes', ctx.view) && $('#hideRes', ctx.view).checked; $$('tr[data-lvl]', ctx.view).forEach(tr => tr.hidden = (l && l.l && tr.dataset.lvl !== l.l) || (hide && tr.dataset.res === '1')); };
  $$('.tabs [role=tab]', ctx.view).forEach(b => b.onclick = () => { $$('.tabs [role=tab]', ctx.view).forEach(x => x.setAttribute('aria-selected', x === b)); filt(); });
  const hr = $('#hideRes', ctx.view); if (hr) hr.onchange = filt;
  $$('[data-log]', ctx.view).forEach(c => c.onchange = async () => { try { await api(`/admin/import/logs/${c.dataset.log}`, { method: 'PATCH', body: { resolved: c.checked } }); c.closest('tr').dataset.res = c.checked ? 1 : 0; } catch (err) { toast(err.message, 'error'); } });
}
