// "All notes": the library with search and filters (grade, subject, unit, content type, difficulty, recency).
import { html, raw, setHTML, $, $$, loading, plural, debounce, errorBox } from '../ui.js';
import { state, subjectById, unitById } from '../store.js';
import { contentsRow, resultRow } from '../components.js';
import { api } from '../api.js';

const TYPES = [['', 'Any'], ['short', 'Has short notes'], ['detailed', 'Has detailed notes'], ['activity', 'Has an activity'], ['quiz', 'Has a quiz'], ['cards', 'Has flashcards'], ['illustrated', 'Has diagrams or photos']];

export async function notes(ctx) {
  ctx.title('All notes');
  const c = state.catalog; const q0 = ctx.query;
  const f = { q: q0.get('q') || '', grade: q0.get('grade') || '', subject: q0.get('subject') || '', unit: q0.get('unit') || '', type: q0.get('type') || '', difficulty: q0.get('difficulty') || '', sort: q0.get('sort') || '' };
  const hasDifficulty = c.lessons.some(l => l.difficulty);

  setHTML(ctx.view, html`
  <header class="page-head"><h1>All notes</h1><p>Search every subject at once, or narrow the list with the filters.</p></header>
  <form class="filters" id="flt" role="search">
    <div class="field search-field"><label for="f-q">Search</label><input class="input" id="f-q" name="q" type="search" value="${f.q}" placeholder="Topic, term or chapter"></div>
    <div class="field"><label for="f-grade">Grade</label><select class="input" id="f-grade" name="grade"><option value="">All grades</option>${c.grades.map(g => html`<option value="${g}" ${String(g) === f.grade ? raw('selected') : ''}>Grade ${g}</option>`)}</select></div>
    <div class="field"><label for="f-subject">Subject</label><select class="input" id="f-subject" name="subject"><option value="">All subjects</option>${c.subjects.map(s => html`<option value="${s.slug}" ${s.slug === f.subject ? raw('selected') : ''}>${s.name}</option>`)}</select></div>
    <div class="field"><label for="f-unit">Unit</label><select class="input" id="f-unit" name="unit"></select></div>
    <div class="field"><label for="f-type">Content</label><select class="input" id="f-type" name="type">${TYPES.map(([v, t]) => html`<option value="${v}" ${v === f.type ? raw('selected') : ''}>${t}</option>`)}</select></div>
    ${hasDifficulty ? html`<div class="field"><label for="f-diff">Difficulty</label><select class="input" id="f-diff" name="difficulty"><option value="">Any</option>${['foundation', 'core', 'extension'].map(d => html`<option value="${d}" ${d === f.difficulty ? raw('selected') : ''}>${d[0].toUpperCase() + d.slice(1)}</option>`)}</select></div>` : ''}
    <div class="field"><label for="f-sort">Order</label><select class="input" id="f-sort" name="sort"><option value="">${f.q ? 'Best match' : 'Chapter order'}</option><option value="recent" ${f.sort === 'recent' ? raw('selected') : ''}>Recently added</option></select></div>
    <button class="btn secondary" type="button" id="f-clear">Clear filters</button>
  </form>
  <div id="res" aria-live="polite"></div>`);

  const form = $('#flt', ctx.view);
  const fillUnits = () => {
    const sub = c.subjects.find(s => s.slug === form.subject.value); const g = +form.grade.value;
    const units = c.units.filter(u => (!sub || u.subjectId === sub.id) && (!g || u.grade === g) && c.lessons.some(l => l.unitId === u.id));
    setHTML(form.unit, html`<option value="">All units</option>${units.map(u => html`<option value="${u.id}" ${String(u.id) === f.unit ? raw('selected') : ''}>${sub ? '' : subjectById(u.subjectId).name + ': '}${u.title}${g ? '' : ` (G${u.grade})`}</option>`)}`);
  };
  fillUnits();

  const run = async () => {
    const vals = Object.fromEntries(new FormData(form));
    Object.assign(f, vals);
    const qs = new URLSearchParams(Object.entries(vals).filter(([, v]) => v)).toString();
    history.replaceState({}, '', '/notes' + (qs ? '?' + qs : ''));
    const out = $('#res', ctx.view);
    const typeOk = l => !vals.type || (vals.type === 'activity' ? l.activities : vals.type === 'quiz' ? l.questions > 0 : vals.type === 'cards' ? l.cards > 0 : vals.type === 'illustrated' ? l.illustrated : l.kinds.includes(vals.type));
    const diffOk = l => !vals.difficulty || l.difficulty === vals.difficulty;
    if (vals.q && vals.q.trim()) {
      setHTML(out, loading('Searching…'));
      try {
        const p = new URLSearchParams({ q: vals.q }); ['grade', 'subject', 'unit', 'sort'].forEach(k => vals[k] && p.set(k, vals[k]));
        const r = await api('/search?' + p);
        if (ctx.stale()) return;
        const results = r.results.filter(x => { const l = c.lessons.find(y => y.key === x.key); return l && typeOk(l) && diffOk(l); });
        setHTML(out, results.length ? html`<p class="result-count">${plural(results.length, 'result')} for “${vals.q}”</p><div class="results">${results.map(resultRow)}</div>`
          : html`<div class="empty"><h3>No notes match “${vals.q}”</h3><p>Check the spelling, use a shorter word, or clear the filters.</p></div>`);
      } catch (e) { setHTML(out, errorBox(e.message)); }
      return;
    }
    let list = c.lessons.filter(l => (!vals.grade || l.grade === +vals.grade) && (!vals.subject || subjectById(l.subjectId).slug === vals.subject) && (!vals.unit || l.unitId === +vals.unit) && typeOk(l) && diffOk(l));
    list = vals.sort === 'recent' ? [...list].sort((a, b) => b.createdAt - a.createdAt || b.id - a.id)
      : [...list].sort((a, b) => a.grade - b.grade || subjectById(a.subjectId).name.localeCompare(subjectById(b.subjectId).name) || a.number - b.number);
    if (!list.length) { setHTML(out, html`<div class="empty"><h3>No notes match these filters</h3><p>Try a different grade or subject.</p></div>`); return; }
    // group by subject + grade, like a library shelf
    const groups = [];
    for (const l of list) { const k = vals.sort === 'recent' ? 'recent' : `${l.subjectId}-${l.grade}`; let gr = groups.find(g => g.k === k); if (!gr) groups.push(gr = { k, l: [] }); gr.l.push(l); }
    setHTML(out, html`<p class="result-count">${plural(list.length, 'lesson')}</p>${groups.map(g => html`<section class="unit">
      ${g.k !== 'recent' ? html`<h2 class="unit-title">${subjectById(g.l[0].subjectId).name}, Grade ${g.l[0].grade}<small>${plural(g.l.length, 'lesson')}</small></h2>` : ''}
      <ol class="contents">${g.l.map(contentsRow)}</ol></section>`)}`);
  };
  const deb = debounce(run, 280);
  form.addEventListener('input', e => { if (e.target.name === 'subject' || e.target.name === 'grade') { f.unit = ''; fillUnits(); } e.target.name === 'q' ? deb() : run(); });
  form.addEventListener('submit', e => { e.preventDefault(); run(); });
  $('#f-clear', ctx.view).onclick = () => { form.reset(); [...form.elements].forEach(el => { if (el.tagName === 'SELECT') el.value = ''; if (el.name === 'q') el.value = ''; }); f.unit = ''; fillUnits(); run(); };
  const top = document.getElementById('q'); if (top) top.value = f.q;
  run();
}
