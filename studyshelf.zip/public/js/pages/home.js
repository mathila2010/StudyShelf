import { html, raw, icon, setHTML, $, plural } from '../ui.js';
import { state, lessonById, subjectById, recommendations, progressOf, lessonsFor } from '../store.js';
import { lessonTile, subjectMeters, subjectPill } from '../components.js';
import { shelfHtml } from './subjects.js';
import { navigate } from '../app.js';

export async function home(ctx) {
  if (!state.user) return welcome(ctx);
  ctx.title('Home');
  const u = state.user; const c = state.catalog; const sum = state.summary;
  const progress = [...sum.progress.values()];
  const recent = progress.filter(p => p.last_viewed_at && lessonById(p.id)).sort((a, b) => b.last_viewed_at - a.last_viewed_at);
  const cont = recent.find(p => !p.completed_at);
  const contL = cont && lessonById(cont.id);
  const recs = recommendations(6).filter(r => !contL || r.lesson.id !== contL.id);
  const marks = sum.bookmarks.map(b => ({ ...b, l: lessonById(b.id) })).filter(b => b.l);
  const added = [...c.lessons].filter(l => !u.grade || l.grade === u.grade).sort((a, b) => b.createdAt - a.createdAt || b.id - a.id).slice(0, 6);
  const mySubjects = (u.subjects.length ? u.subjects : c.subjects.map(s => s.slug)).map(sl => c.subjects.find(s => s.slug === sl)).filter(Boolean);
  const gradeLessons = lessonsFor({ grade: u.grade });
  const doneCount = gradeLessons.filter(l => (progressOf(l.id) || {}).completed_at).length;
  const hour = new Date().getHours();
  const hello = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  setHTML(ctx.view, html`
  <header class="page-head greet">
    <h1>${hello}, <span class="name">${u.name.split(' ')[0]}</span></h1>
    <div class="greet-meta">
      <span class="pill">Grade ${u.grade || '—'}</span>
      ${mySubjects.map(subjectPill)}
      <a href="/profile" class="small">Change grade or subjects</a>
    </div>
  </header>

  <form class="top-search" role="search" id="dashSearch" style="max-width:640px;margin:0 0 8px">
    ${icon('search')}<label class="sr-only" for="dq">Search your notes</label>
    <input id="dq" type="search" placeholder="What do you want to revise? Try “photosynthesis”" autocomplete="off">
  </form>

  <div class="dash-grid">
    <div>
      <section class="section" aria-labelledby="cl-h">
        <div class="section-head"><h2 id="cl-h">Continue learning</h2></div>
        ${contL ? continueCard(contL, cont) : recs[0] ? continueCard(recs[0].lesson, null, recs[0].why)
          : html`<div class="empty"><h3>Nothing started yet</h3><p>Pick a subject and open your first lesson.</p><a class="btn" href="/subjects">Browse subjects</a></div>`}
      </section>

      <section class="section" aria-labelledby="rec-h">
        <div class="section-head"><h2 id="rec-h">Recommended next</h2><a href="/practice">Take a practice test</a></div>
        ${recs.length ? html`<div class="lesson-tiles">${recs.slice(contL ? 0 : 1, 7).map(r => lessonTile(r.lesson, r.why))}</div>`
          : html`<div class="empty"><p>You’ve finished everything in your subjects. Try a practice test to keep it fresh.</p><a class="btn" href="/practice">Start a practice test</a></div>`}
      </section>

      <section class="section" aria-labelledby="rv-h">
        <div class="section-head"><h2 id="rv-h">Recently viewed</h2></div>
        ${recent.length ? html`<div class="lesson-tiles">${recent.slice(0, 6).map(p => lessonTile(lessonById(p.id)))}</div>`
          : html`<p class="muted">Lessons you open will show up here.</p>`}
      </section>

      <section class="section" aria-labelledby="new-h">
        <div class="section-head"><h2 id="new-h">Recently added${u.grade ? ` for Grade ${u.grade}` : ''}</h2><a href="/notes?sort=recent">See all</a></div>
        <div class="lesson-tiles">${added.map(l => lessonTile(l))}</div>
      </section>
    </div>

    <aside>
      <section class="section panel" aria-labelledby="pg-h" style="margin-top:40px">
        <div class="section-head"><h2 id="pg-h">Your progress</h2><a href="/progress">Details</a></div>
        <p class="muted small" style="margin-top:-6px">${doneCount} of ${plural(gradeLessons.length, 'lesson')} done in Grade ${u.grade}</p>
        ${subjectMeters(u.grade)}
      </section>
      <section class="section" aria-labelledby="bm-h">
        <div class="section-head"><h2 id="bm-h">Bookmarks and favourites</h2><a href="/bookmarks">All</a></div>
        ${marks.length ? html`<div class="results">${marks.slice(0, 6).map(b => { const s = subjectById(b.l.subjectId); return html`<a class="end-card" href="/lessons/${b.l.key}">
            <span class="small muted" style="display:flex;gap:6px;align-items:center">${icon(b.kind === 'favorite' ? 'starFill' : 'bookmarkFill', 'width="16" height="16"')}${s.name}, Grade ${b.l.grade}</span><b>${b.l.title}</b></a>`; })}</div>`
          : html`<div class="empty small">Tap <b>Bookmark</b> or <b>Favourite</b> on any lesson to keep it here.</div>`}
      </section>
    </aside>
  </div>`);
  $('#dashSearch').addEventListener('submit', e => { e.preventDefault(); const q = $('#dq').value.trim(); navigate('/notes' + (q ? '?q=' + encodeURIComponent(q) : '')); });
}

function continueCard(l, p, why) {
  const s = subjectById(l.subjectId);
  return html`<a class="continue" href="/lessons/${l.key}" style="--c:${s.color}"><i></i>
    <div><span class="small muted">${s.name}, Grade ${l.grade}${l.number ? `, Chapter ${l.number}` : ''}</span><h3>${l.title}</h3>
    <p>${p ? `Last opened ${new Date(p.last_viewed_at).toLocaleDateString(undefined, { day: 'numeric', month: 'short' })}` : why || l.hook || ''}</p></div>
    <span class="btn">${p ? 'Continue' : 'Start'}</span></a>`;
}

function welcome(ctx) {
  ctx.title('');
  const c = state.catalog;
  const free = c.lessons.filter(l => l.guest);
  const sample = c.lessons.find(l => l.key === 'science-g10-c03') || free[0] || c.lessons[0];
  setHTML(ctx.view, html`
  <section class="welcome">
    <div>
      <h1>Every O/L subject’s notes, in one place.</h1>
      <p class="lead">Short notes, detailed notes, diagrams, flashcards and quizzes for Grade 10 and 11 ${c.subjects.map(s => s.name).join(', ').replace(/, ([^,]*)$/, ' and $1')}. Save your place and see what to revise next.</p>
      <div class="btn-row"><a class="btn" href="/signup">Create a free account</a><a class="btn secondary" href="/subjects">Look around first</a></div>
      <p class="small muted" style="margin-top:14px">Already have an account? <a href="/login">Log in</a></p>
    </div>
    <div class="page-sample" aria-label="Example note">
      <span class="tag">${c.lessons.length} lessons</span>
      <h3>${sample.title}</h3>
      <p>${sample.hook || sample.summary}</p>
      <p><mark>Key facts are highlighted</mark> so revision is quick.</p>
    </div>
  </section>
  <section class="section"><div class="section-head"><h2>Subjects</h2></div>${shelfHtml()}</section>
  <section class="section"><div class="section-head"><h2>Free to read without an account</h2></div>
    <div class="lesson-tiles">${free.map(l => lessonTile(l))}</div></section>`);
}
