// The note reader.
import { html, raw, icon, setHTML, $, $$, toast, loading, lightbox, plural, errorBox, textOf } from '../ui.js';
import { api, ApiError } from '../api.js';
import { state, lessonByKey, neighbours, lessonsFor, loadSummary, progressOf } from '../store.js';
import { lessonTile, subjectPill } from '../components.js';

// ---------- interactive activity packs (original code from the source sites) ----------
const packLoads = {};
function loadPack(name) {
  if (window.SH_IX && window.SH_IX[name]) return Promise.resolve(window.SH_IX[name]);
  return packLoads[name] = packLoads[name] || new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = `/generated/ix-${encodeURIComponent(name)}.js`; s.async = true;
    s.onload = () => (window.SH_IX && window.SH_IX[name]) ? res(window.SH_IX[name]) : rej(new Error('missing pack'));
    s.onerror = () => { delete packLoads[name]; rej(new Error('load failed')); };
    document.head.appendChild(s);
  });
}
export async function mountActivities(root) {
  for (const el of $$('.sh-ix', root)) {
    if (el.dataset.mounted) continue; el.dataset.mounted = '1';
    try { const pack = await loadPack(el.dataset.pack); el.innerHTML = ''; pack.mount(el.dataset.name, el); }
    catch (e) { console.warn(e); el.innerHTML = '<p class="ix-fail">This activity couldn’t load. The rest of the note is unaffected.</p>'; }
  }
}
export function enableFigureZoom(root) {
  root.addEventListener('click', e => {
    const t = e.target.closest('figure img, figure svg');
    if (!t || e.target.closest('.sh-ix, a, button')) return;
    const fig = t.closest('figure'); const cap = fig && fig.querySelector('figcaption');
    lightbox(t, cap ? cap.textContent.trim() : t.getAttribute('alt') || t.getAttribute('aria-label') || '');
  });
}

// ---------- text to speech ----------
function makeReader(prose, bar) {
  const synth = window.speechSynthesis;
  if (!synth || !window.SpeechSynthesisUtterance) return null;
  let queue = [], i = 0, playing = false, paused = false, current = null;
  const blocks = () => $$('h2, h3, h4, p, li, dt, dd, figcaption, .formula, .callout-title, th, td', prose).filter(el =>
    !el.closest('.sh-ix, svg, details:not([open]) > :not(summary)') && !el.querySelector('p, li') && el.textContent.trim());
  const voices = () => synth.getVoices().filter(v => /^en/i.test(v.lang));
  const chunks = el => (el.textContent.replace(/\s+/g, ' ').trim().match(/[^.!?]+[.!?]*\s*/g) || []).reduce((a, s) => {
    if (a.length && (a[a.length - 1] + s).length < 220) a[a.length - 1] += s; else a.push(s); return a; }, []);
  function mark(el) { if (current) current.classList.remove('tts-current'); current = el; if (el) { el.classList.add('tts-current'); el.scrollIntoView({ block: 'center', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }); } }
  function speakNext() {
    if (!playing) return;
    if (i >= queue.length) { stop(); toast('Finished reading.'); return; }
    const { el, text } = queue[i];
    mark(el);
    const u = new SpeechSynthesisUtterance(text);
    const vSel = $('#tts-voice', bar), rSel = $('#tts-rate', bar);
    const v = voices().find(x => x.name === (vSel && vSel.value)); if (v) u.voice = v;
    u.rate = +(rSel ? rSel.value : 1); u.lang = v ? v.lang : 'en-GB';
    u.onend = () => { i++; speakNext(); };
    u.onerror = e => { if (e.error !== 'interrupted' && e.error !== 'canceled') { i++; speakNext(); } };
    synth.speak(u);
  }
  function start(fromEl) {
    synth.cancel();
    queue = blocks().flatMap(el => chunks(el).map(text => ({ el, text })));
    i = fromEl ? Math.max(0, queue.findIndex(q => q.el === fromEl || fromEl.contains(q.el))) : 0;
    playing = true; paused = false; sync(); speakNext();
  }
  function stop() { playing = false; paused = false; synth.cancel(); mark(null); sync(); }
  function toggle() {
    if (!playing) return start();
    if (paused) { synth.resume(); paused = false; } else { synth.pause(); paused = true; }
    sync();
  }
  function sync() {
    const b = $('#tts-play', bar); if (!b) return;
    setHTML(b, html`${icon(playing && !paused ? 'pause' : 'play')}${playing && !paused ? 'Pause' : paused ? 'Resume' : 'Read aloud'}`);
    $('#tts-stop', bar).disabled = !playing;
  }
  function fillVoices() {
    const sel = $('#tts-voice', bar); if (!sel) return;
    const vs = voices(); const keep = sel.value;
    sel.innerHTML = vs.length ? vs.map(v => `<option>${v.name.replace(/[<>&]/g, '')}</option>`).join('') : '<option value="">Default voice</option>';
    if (keep) sel.value = keep;
  }
  setHTML(bar, html`<button class="btn small" id="tts-play" type="button"></button><button class="btn small secondary" id="tts-stop" type="button" disabled>${icon('stop')}Stop</button>
    <label class="small">Speed <select id="tts-rate"><option value="0.8">Slow</option><option value="1" selected>Normal</option><option value="1.2">Fast</option></select></label>
    <label class="small">Voice <select id="tts-voice"></select></label><span class="small muted">Tip: double-click a paragraph to start reading from there.</span>`);
  fillVoices(); synth.onvoiceschanged = fillVoices;
  $('#tts-play', bar).onclick = toggle; $('#tts-stop', bar).onclick = stop;
  $('#tts-rate', bar).onchange = () => { if (playing) start(current); };
  prose.addEventListener('dblclick', e => { const el = e.target.closest('p, li, h2, h3, dd, td'); if (el && !bar.hidden) start(el); });
  sync();
  return { stop, start };
}

export async function lesson(ctx) {
  const key = ctx.params.key;
  setHTML(ctx.view, loading('Opening note…'));
  let data;
  try { data = await api(`/lessons/${encodeURIComponent(key)}`); }
  catch (e) {
    if (ctx.stale()) return;
    if (e instanceof ApiError && e.status === 401 && e.data.preview) return lockedView(ctx, e.data.preview);
    throw e;
  }
  if (ctx.stale()) return;
  renderLesson(ctx, data.lesson, data.me);
}

function lockedView(ctx, p) {
  ctx.title(p.title);
  const free = state.catalog.lessons.filter(l => l.guest && l.subjectId === p.subject.id);
  setHTML(ctx.view, html`<div class="locked-note">
    <nav class="crumbs" aria-label="Breadcrumb"><a href="/subjects/${p.subject.slug}">${p.subject.name}</a><span aria-hidden="true">/</span><span>Grade ${p.grade}</span></nav>
    <h1>${p.title}</h1><p class="muted">${p.summary}</p>
    <div class="panel"><h2>Log in to read this note</h2><p>Accounts are free. You’ll also be able to bookmark notes, take quizzes and track your progress.</p>
      <div class="btn-row"><a class="btn" href="/signup?next=${encodeURIComponent(location.pathname)}">Create a free account</a><a class="btn secondary" href="/login?next=${encodeURIComponent(location.pathname)}">Log in</a></div></div>
    ${free.length ? html`<section class="section"><h2>Free ${p.subject.name} notes</h2><div class="lesson-tiles">${free.map(l => lessonTile(l))}</div></section>` : ''}</div>`);
}

/** Render a lesson. Also used by the admin preview (opts.preview). */
export function renderLesson(ctx, L, me, opts = {}) {
  ctx.title && ctx.title(L.title);
  const cat = lessonByKey(L.key);
  const nb = cat ? neighbours(cat) : { prev: null, next: null };
  const related = cat ? lessonsFor({ subjectId: cat.subjectId, grade: cat.grade }).filter(l => l.unitId === cat.unitId && l.id !== cat.id).slice(0, 4) : [];
  const wantTab = ctx.query && ctx.query.get('tab');
  let tab = Math.max(0, L.notes.findIndex(n => n.kind === wantTab || String(n.id) === wantTab));
  if (!wantTab && me && me.lastTab) tab = Math.max(0, L.notes.findIndex(n => n.kind === me.lastTab));
  const s = L.subject;
  const host = opts.host || ctx.view;
  let reader = null, observer = null;

  setHTML(host, html`
  ${opts.banner || ''}
  <nav class="crumbs" aria-label="Breadcrumb"><a href="/subjects/${s.slug}">${s.name}</a><span aria-hidden="true">/</span><a href="/subjects/${s.slug}?grade=${L.grade}">Grade ${L.grade}</a>${L.unit ? html`<span aria-hidden="true">/</span><span>${L.unit.title}</span>` : ''}</nav>
  <div class="reader">
    <div>
      <header class="lesson-head">
        <div class="meta">${subjectPill(s)}<span class="pill">Grade ${L.grade}</span>${L.number ? html`<span class="pill">Chapter ${L.number}</span>` : ''}${L.era ? html`<span class="pill">${L.era}</span>` : ''}${L.difficulty ? html`<span class="pill">${L.difficulty}</span>` : ''}${me && me.completed ? html`<span class="pill ok">${icon('check')}Completed</span>` : ''}</div>
        <h1>${L.title}</h1>
        ${L.hook ? html`<p class="hook">${L.hook}</p>` : ''}
        ${L.summary && L.summary !== L.hook ? html`<p class="hook" style="font-size:1rem">${L.summary}</p>` : ''}
        ${L.image && L.image.url ? html`<figure class="hero-img" style="margin-bottom:0"><img src="${L.image.url}" alt="${L.image.alt || ''}"></figure><p class="hero-cap">${textOf(L.image.caption || '')}</p>` : ''}
      </header>
      <div class="toolbar" role="toolbar" aria-label="Note tools">
        <button class="btn small secondary" type="button" id="ttsBtn" aria-expanded="false">${icon('speaker')}Listen</button>
        ${me ? html`<button class="btn small secondary" type="button" id="bmBtn" aria-pressed="${me.bookmark}">${icon(me.bookmark ? 'bookmarkFill' : 'bookmark')}<span>${me.bookmark ? 'Bookmarked' : 'Bookmark'}</span></button>
          <button class="btn small secondary" type="button" id="favBtn" aria-pressed="${me.favorite}">${icon(me.favorite ? 'starFill' : 'star')}<span>${me.favorite ? 'Favourite' : 'Favourite'}</span></button>` : ''}
        <button class="btn small secondary" type="button" id="printBtn" title="Print, or choose “Save as PDF” to download">${icon('print')}Print or save PDF</button>
        <span class="grow"></span>
        ${me ? html`<button class="btn small ${me.completed ? 'secondary' : ''}" type="button" id="doneBtn">${icon('check')}${me.completed ? 'Completed' : 'Mark as completed'}</button>` : ''}
      </div>
      <div class="tts-bar" id="ttsBar" hidden></div>
      ${L.notes.length > 1 ? html`<div class="tabs note-tabs" role="tablist" aria-label="Note type">${L.notes.map((n, i) => html`<button role="tab" type="button" id="nt-${i}" aria-selected="${i === tab}" aria-controls="noteBody" data-i="${i}">${n.title}</button>`)}</div>` : ''}
      <div class="toc-mobile" id="tocMobile"></div>
      <article class="prose" id="noteBody" role="${L.notes.length > 1 ? 'tabpanel' : 'article'}" tabindex="-1"></article>
      <p class="print-only small">From ${ctx.appName || 'StudyShelf'}: ${s.name}, Grade ${L.grade}${L.number ? `, Chapter ${L.number}` : ''}. ${location.href}</p>

      <div class="lesson-end">
        ${L.events && L.events.length ? html`<section class="panel"><h2>Dates in this chapter</h2><ol class="timeline">${L.events.map(e => html`<li><span class="when">${e.label}</span><div class="what"><b>${e.title}</b>${e.detail ? html`<p>${e.detail}</p>` : ''}</div></li>`)}</ol></section>` : ''}
        <section aria-labelledby="pr-h"><h2 id="pr-h">Practise this lesson</h2>
          <div class="end-actions">
            ${L.questions.length ? html`<a class="end-card" href="/lessons/${L.key}/quiz"><b>${icon('quiz', 'width="20" height="20"')} Quiz</b><span>${plural(L.questions.length, 'question')} with instant feedback${me && me.bestQuiz != null ? `. Your best: ${me.bestQuiz}%` : ''}</span></a>` : ''}
            ${L.flashcards.length ? html`<a class="end-card" href="/lessons/${L.key}/flashcards"><b>${icon('cards', 'width="20" height="20"')} Flashcards</b><span>${plural(L.flashcards.length, 'card')} for key facts and terms</span></a>` : ''}
            ${me ? html`<button class="end-card" type="button" id="reviseBtn" aria-pressed="${me.revise}" style="text-align:left;cursor:pointer;font:inherit"><b>${icon('flag', 'width="20" height="20"')} ${me.revise ? 'On your revision list' : 'Revise later'}</b><span>${me.revise ? 'Tap to take it off the list' : 'Add to your recommended list'}</span></button>`
              : html`<a class="end-card" href="/signup"><b>Save your progress</b><span>Create a free account to bookmark notes and track quizzes</span></a>`}
          </div>
        </section>
        ${related.length ? html`<section><h2>Related notes</h2><div class="lesson-tiles">${related.map(l => lessonTile(l))}</div></section>` : ''}
        <nav class="pager" aria-label="Lesson navigation">
          ${nb.prev ? html`<a href="/lessons/${nb.prev.key}"><small>Previous lesson</small><b>${nb.prev.title}</b></a>` : html`<span></span>`}
          ${nb.next ? html`<a class="next" href="/lessons/${nb.next.key}"><small>Next lesson</small><b>${nb.next.title}</b></a>` : ''}
        </nav>
      </div>
    </div>
    <aside class="toc" id="toc" aria-label="On this page"></aside>
  </div>`);

  const body = $('#noteBody', host);
  enableFigureZoom(body);

  function showTab(i, focus) {
    tab = i; const n = L.notes[i];
    if (reader) reader.stop();
    body.className = `prose ${n.scope || ''}`;
    body.setAttribute('aria-labelledby', L.notes.length > 1 ? `nt-${i}` : '');
    setHTML(body, raw(n.html));
    $$('.note-tabs [role=tab]', host).forEach((b, j) => { b.setAttribute('aria-selected', j === i); b.tabIndex = j === i ? 0 : -1; });
    const toc = n.toc && n.toc.length ? n.toc : $$('h2', body).map((h, j) => { if (!h.id) h.id = `sec-${j + 1}`; return { id: h.id, title: h.textContent.trim() }; });
    setHTML($('#toc', host), toc.length > 1 ? html`<h2>On this page</h2><ol>${toc.map(t => html`<li><a href="#${t.id}" data-id="${t.id}">${t.title}</a></li>`)}</ol>
      ${L.questions.length ? html`<div class="side-block"><a class="btn small secondary" href="/lessons/${L.key}/quiz">${icon('quiz')}Take the quiz</a></div>` : ''}` : '');
    setHTML($('#tocMobile', host), toc.length > 1 ? html`<details><summary>In this note (${toc.length} parts)</summary><ol>${toc.map(t => html`<li><a href="#${t.id}">${t.title}</a></li>`)}</ol></details>` : '');
    mountActivities(body);
    if (observer) observer.disconnect();
    const links = $$('#toc a', host);
    observer = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) links.forEach(a => a.setAttribute('aria-current', a.dataset.id === en.target.id)); }), { rootMargin: '-25% 0px -65% 0px' });
    toc.forEach(t => { const el = document.getElementById(t.id); if (el) observer.observe(el); });
    if (ctx.query && !opts.preview) { const u = new URL(location.href); if (L.notes.length > 1) u.searchParams.set('tab', n.kind); history.replaceState({}, '', u.pathname + u.search); }
    if (focus) body.focus({ preventScroll: true });
    if (me && !opts.preview) api(`/progress/${L.id}/view`, { method: 'POST', body: { tab: n.kind } }).catch(() => {});
  }
  showTab(tab);
  if (location.hash) { const el = document.getElementById(location.hash.slice(1)); if (el) setTimeout(() => el.scrollIntoView(), 50); }

  // tabs: click + arrow keys
  const tl = $('.note-tabs', host);
  if (tl) {
    tl.addEventListener('click', e => { const b = e.target.closest('[role=tab]'); if (b) showTab(+b.dataset.i, false); });
    tl.addEventListener('keydown', e => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
      e.preventDefault(); const n = L.notes.length;
      const i = e.key === 'Home' ? 0 : e.key === 'End' ? n - 1 : (tab + (e.key === 'ArrowRight' ? 1 : -1) + n) % n;
      showTab(i); $(`#nt-${i}`, host).focus();
    });
  }
  // listen
  const ttsBtn = $('#ttsBtn', host), bar = $('#ttsBar', host);
  if (!window.speechSynthesis) { ttsBtn.disabled = true; ttsBtn.title = 'Your browser does not support reading aloud.'; }
  ttsBtn.onclick = () => {
    if (!reader) reader = makeReader(body, bar);
    if (!reader) { toast('Your browser can’t read notes aloud. Try Chrome, Edge or Safari.', 'error'); return; }
    bar.hidden = !bar.hidden; ttsBtn.setAttribute('aria-expanded', !bar.hidden);
    if (bar.hidden) reader.stop(); else $('#tts-play', bar).focus();
  };
  $('#printBtn', host).onclick = () => window.print();

  if (me && !opts.preview) {
    const toggle = (btn, kind, onLabel, offLabel, ic) => btn.onclick = async () => {
      const on = btn.getAttribute('aria-pressed') !== 'true';
      btn.disabled = true;
      try {
        await api(`/bookmarks/${L.id}/${kind}`, { method: on ? 'PUT' : 'DELETE' });
        btn.setAttribute('aria-pressed', on); setHTML(btn, html`${icon(on ? ic + 'Fill' : ic)}<span>${on ? onLabel : offLabel}</span>`);
        toast(on ? `Added to your ${kind === 'favorite' ? 'favourites' : 'bookmarks'}` : `Removed from your ${kind === 'favorite' ? 'favourites' : 'bookmarks'}`);
        loadSummary();
      } catch (e) { toast(e.message, 'error'); } finally { btn.disabled = false; }
    };
    toggle($('#bmBtn', host), 'bookmark', 'Bookmarked', 'Bookmark', 'bookmark');
    toggle($('#favBtn', host), 'favorite', 'Favourite', 'Favourite', 'star');
    $('#doneBtn', host).onclick = async e => {
      const btn = e.currentTarget; const on = !me.completed; btn.disabled = true;
      try {
        await api(`/progress/${L.id}`, { method: 'POST', body: { completed: on } }); me.completed = on;
        btn.className = `btn small ${on ? 'secondary' : ''}`; setHTML(btn, html`${icon('check')}${on ? 'Completed' : 'Mark as completed'}`);
        toast(on ? 'Marked as completed. Nice work!' : 'Marked as not completed');
        loadSummary();
      } catch (err) { toast(err.message, 'error'); } finally { btn.disabled = false; }
    };
    const rv = $('#reviseBtn', host);
    rv.onclick = async () => {
      const on = !me.revise;
      try {
        await api(`/progress/${L.id}`, { method: 'POST', body: { revise: on } }); me.revise = on; rv.setAttribute('aria-pressed', on);
        setHTML(rv, html`<b>${icon('flag', 'width="20" height="20"')} ${on ? 'On your revision list' : 'Revise later'}</b><span>${on ? 'Tap to take it off the list' : 'Add to your recommended list'}</span>`);
        toast(on ? 'Added to your revision list' : 'Removed from your revision list'); loadSummary();
      } catch (err) { toast(err.message, 'error'); }
    };
  }
  const leave = () => { if (reader) reader.stop(); if (observer) observer.disconnect(); };
  ctx.onLeave && ctx.onLeave(leave);
  return leave;
}
