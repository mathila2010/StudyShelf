// Student pages: bookmarks, progress, profile.
import { html, raw, icon, setHTML, $, $$, toast, plural, fmtDate, fmtAgo, confirmDialog, errorBox } from '../ui.js';
import { api } from '../api.js';
import { state, loadSummary, lessonById, subjectById, setUser, progressOf } from '../store.js';
import { contentsRow, subjectMeters } from '../components.js';
import { navigate } from '../app.js';

export async function bookmarks(ctx) {
  ctx.title('My bookmarks');
  await loadSummary(); if (ctx.stale()) return;
  const bm = state.summary.bookmarks.map(b => ({ ...b, l: lessonById(b.id) })).filter(b => b.l);
  const kinds = [['bookmark', 'Bookmarks', 'bookmark'], ['favorite', 'Favourites', 'star']];
  const revise = [...state.summary.progress.values()].filter(p => p.revise).map(p => lessonById(p.id)).filter(Boolean);
  setHTML(ctx.view, html`<header class="page-head"><h1>My bookmarks</h1><p>Notes you’ve saved, your favourites, and lessons you marked to revise.</p></header>
    ${kinds.map(([k, title, ic]) => { const list = bm.filter(b => b.kind === k); return html`<section class="unit"><h2 class="unit-title">${title}<small>${plural(list.length, 'note')}</small></h2>
      ${list.length ? html`<ol class="contents">${list.map(b => contentsRow(b.l))}</ol>` : html`<div class="empty small">Use the ${icon(ic, 'width="16" height="16" style="vertical-align:-3px"')} <b>${k === 'favorite' ? 'Favourite' : 'Bookmark'}</b> button on any note to save it here.</div>`}</section>`; })}
    <section class="unit"><h2 class="unit-title">To revise<small>${plural(revise.length, 'note')}</small></h2>
      ${revise.length ? html`<ol class="contents">${revise.map(contentsRow)}</ol>` : html`<div class="empty small">Tap <b>Revise later</b> at the end of a note to add it here.</div>`}</section>`);
}

export async function progress(ctx) {
  ctx.title('My progress');
  await loadSummary(); if (ctx.stale()) return;
  const u = state.user; const c = state.catalog; const sum = state.summary;
  const prog = [...sum.progress.values()];
  const completed = prog.filter(p => p.completed_at).sort((a, b) => b.completed_at - a.completed_at);
  const quizzes = sum.quizzes;
  const avg = quizzes.length ? Math.round(quizzes.reduce((a, q) => a + q.score / Math.max(q.total, 1), 0) * 100 / quizzes.length) : null;
  const week = Date.now() - 7 * 864e5;
  setHTML(ctx.view, html`<header class="page-head"><h1>My progress</h1><p>Only you can see this page. Your scores are never shown to other students.</p></header>
  <div class="stat-grid">
    <div class="stat"><b>${completed.length}</b><span>lessons completed</span></div>
    <div class="stat"><b>${prog.filter(p => p.views).length}</b><span>lessons opened</span></div>
    <div class="stat"><b>${quizzes.length}</b><span>quizzes taken</span></div>
    <div class="stat"><b>${avg == null ? '—' : avg + '%'}</b><span>average quiz score</span></div>
    <div class="stat"><b>${prog.filter(p => p.last_viewed_at > week).length}</b><span>lessons studied this week</span></div>
  </div>
  <div class="dash-grid section">
    <section class="panel"><h2>By subject</h2>
      <div class="tabs" role="tablist" aria-label="Grade">${c.grades.map(g => html`<button role="tab" type="button" aria-selected="${g === (u.grade || c.grades[0])}" data-g="${g}">Grade ${g}</button>`)}</div>
      <div id="meters">${subjectMeters(u.grade || c.grades[0])}</div></section>
    <section class="panel"><h2>Recent quiz results</h2>
      ${quizzes.length ? html`<div class="tablewrap"><table class="data"><thead><tr><th>Quiz</th><th>Score</th><th>When</th></tr></thead><tbody>
        ${quizzes.slice(0, 15).map(q => { const l = lessonById(q.lesson_id); const pct = Math.round(q.score * 100 / Math.max(q.total, 1)); return html`<tr>
          <td>${l ? html`<a href="/lessons/${l.key}">${l.title}</a>` : q.kind === 'practice' ? `Practice test${q.subject ? ': ' + (c.subjects.find(s => s.slug === q.subject) || {}).name : ''}` : 'Quiz'}</td>
          <td class="num"><b style="color:${pct >= 60 ? 'var(--sh-ok)' : 'var(--sh-bad)'}">${q.score}/${q.total}</b></td><td>${fmtAgo(q.created_at)}</td></tr>`; })}</tbody></table></div>`
        : html`<div class="empty small">No quizzes yet. <a href="/practice">Take a practice test</a>.</div>`}</section>
  </div>
  <section class="section"><div class="section-head"><h2>Completed lessons</h2></div>
    ${completed.length ? html`<ol class="contents">${completed.map(p => lessonById(p.id)).filter(Boolean).map(contentsRow)}</ol>` : html`<div class="empty small">When you finish a note, press <b>Mark as completed</b> to see it here.</div>`}</section>`);
  $$('.tabs [role=tab]', ctx.view).forEach(b => b.onclick = () => {
    $$('.tabs [role=tab]', ctx.view).forEach(x => x.setAttribute('aria-selected', x === b));
    setHTML($('#meters', ctx.view), subjectMeters(+b.dataset.g));
  });
}

export function profile(ctx) {
  ctx.title('Profile');
  const u = state.user; const c = state.catalog;
  setHTML(ctx.view, html`<header class="page-head"><h1>Profile</h1><p>Signed in as ${u.email}${u.role === 'admin' ? ' (administrator)' : ''}.</p></header>
  <div class="dash-grid">
    <div>
      <form class="panel form" id="pf" novalidate>
        <h2>Your details</h2>
        <div class="field"><label for="p-name">Name</label><input class="input" id="p-name" name="name" value="${u.name}" maxlength="60" autocomplete="given-name" required><span class="hint">Your first name is enough.</span></div>
        <div class="field"><span class="label">Grade</span><div class="choice-row">${c.grades.map(g => html`<label class="choice"><input type="radio" name="grade" value="${g}" ${u.grade === g ? raw('checked') : ''}><span>Grade ${g}</span></label>`)}</div></div>
        <div class="field"><span class="label">My subjects</span><span class="hint">These shape your dashboard and recommendations. Leave all unticked to follow every subject.</span>
          <div class="choice-row">${c.subjects.map(s => html`<label class="choice"><input type="checkbox" name="subjects" value="${s.slug}" ${u.subjects.includes(s.slug) ? raw('checked') : ''}><span>${s.name}</span></label>`)}</div></div>
        <div id="pf-msg"></div>
        <div><button class="btn" type="submit">Save changes</button></div>
      </form>
      <form class="panel form section" id="pw" novalidate>
        <h2>Change password</h2>
        <div class="field"><label for="pw-cur">Current password</label><input class="input" id="pw-cur" name="current" type="password" autocomplete="current-password" required></div>
        <div class="field"><label for="pw-new">New password</label><input class="input" id="pw-new" name="password" type="password" autocomplete="new-password" minlength="8" required><span class="hint">At least 8 characters, with a letter and a number.</span></div>
        <div id="pw-msg"></div>
        <div><button class="btn" type="submit">Change password</button></div>
      </form>
    </div>
    <aside>
      <section class="panel"><h2>Your learning data</h2><p class="small muted">We keep your name, email, grade, subjects, the notes you open, bookmarks and quiz scores, so the site can show your progress. No one else can see your scores. We don’t show ads or share your data.</p>
        <div class="btn-row"><a class="btn secondary small" href="/progress">See my progress</a></div></section>
      <section class="panel section"><h2>Log out</h2><p class="small muted">Use this on shared computers at school or a library.</p><button class="btn secondary" id="lo">${icon('logout')}Log out</button></section>
      <section class="panel section"><h2>Delete account</h2><p class="small muted">Removes your account, bookmarks, progress and quiz scores for good.</p><button class="btn danger small" id="del">${icon('trash')}Delete my account</button></section>
    </aside>
  </div>`);
  $('#pf', ctx.view).addEventListener('submit', async e => {
    e.preventDefault(); const f = e.target; const msg = $('#pf-msg', ctx.view); setHTML(msg, '');
    try {
      const r = await api('/me', { method: 'PATCH', body: { name: f.name.value, grade: +(f.querySelector('[name=grade]:checked') || {}).value, subjects: $$('[name=subjects]:checked', f).map(x => x.value) } });
      setUser(r.user); toast('Profile saved');
    } catch (err) { setHTML(msg, errorBox(err.message)); }
  });
  $('#pw', ctx.view).addEventListener('submit', async e => {
    e.preventDefault(); const f = e.target; const msg = $('#pw-msg', ctx.view); setHTML(msg, '');
    try { await api('/me/password', { method: 'POST', body: { current: f.current.value, password: f.password.value } }); f.reset(); toast('Password changed'); }
    catch (err) { setHTML(msg, errorBox(err.message)); }
  });
  $('#lo', ctx.view).onclick = async () => { const { logout } = await import('../app.js'); logout(); };
  $('#del', ctx.view).onclick = async () => {
    const d = document.createElement('dialog'); d.className = 'modal';
    setHTML(d, html`<form method="dialog" id="delf"><div class="m-body"><h2>Delete your account?</h2><p class="muted">This can’t be undone. Enter your password to confirm.</p>
      <div class="field"><label for="del-pw">Password</label><input class="input" id="del-pw" type="password" autocomplete="current-password"></div><div id="del-msg"></div></div>
      <div class="m-foot"><button class="btn secondary" value="cancel" formnovalidate>Cancel</button><button class="btn danger" value="ok" id="del-ok">Delete account</button></div></form>`);
    document.body.appendChild(d); d.showModal();
    $('#del-ok', d).onclick = async ev => {
      ev.preventDefault();
      try { await api('/me', { method: 'DELETE', body: { password: $('#del-pw', d).value } }); d.close(); d.remove(); state.user = null; state.summary = null; toast('Your account was deleted.'); navigate('/'); }
      catch (err) { setHTML($('#del-msg', d), errorBox(err.message)); }
    };
    d.addEventListener('close', () => d.remove());
  };
}
