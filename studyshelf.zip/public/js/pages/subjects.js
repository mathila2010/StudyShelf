import { html, raw, icon, setHTML, $$, plural, loading } from '../ui.js';
import { state, subjectBySlug, lessonsFor, progressOf, unitById } from '../store.js';
import { contentsRow } from '../components.js';
import { api } from '../api.js';

export function shelfHtml() {
  const c = state.catalog;
  return html`<div class="shelf">${c.subjects.map(s => {
    const list = c.lessons.filter(l => l.subjectId === s.id);
    const grades = [...new Set(list.map(l => l.grade))].sort();
    const done = state.user ? list.filter(l => (progressOf(l.id) || {}).completed_at).length : 0;
    return html`<a class="cover" href="/subjects/${s.slug}" style="--c:${s.color}">
      <span class="ico">${icon(s.icon)}</span>
      <h2>${s.name}</h2><p>${s.description}</p>
      <span class="label">Grade ${grades.join(' & ')}, ${plural(list.length, 'lesson')}${state.user && done ? `, ${done} done` : ''}</span></a>`;
  })}</div>`;
}

export function shelf(ctx) {
  ctx.title('Subjects');
  setHTML(ctx.view, html`<header class="page-head"><h1>Subjects</h1><p>Choose a subject to see its units and lessons for each grade.</p></header>${shelfHtml()}`);
}

export function subject(ctx) {
  const s = subjectBySlug(ctx.params.slug);
  if (!s) { setHTML(ctx.view, html`<div class="empty"><h1>Subject not found</h1><a class="btn" href="/subjects">See all subjects</a></div>`); return; }
  ctx.title(s.name);
  const all = lessonsFor({ subjectId: s.id });
  const grades = [...new Set(all.map(l => l.grade))].sort();
  const wanted = +ctx.query.get('grade');
  const grade = grades.includes(wanted) ? wanted : (state.user && grades.includes(state.user.grade) ? state.user.grade : grades[0]);
  const list = all.filter(l => l.grade === grade);
  const units = [...new Set(list.map(l => l.unitId))].map(id => ({ id, title: (unitById(id) || {}).title || 'Lessons', pos: (unitById(id) || {}).position || 99 })).sort((a, b) => a.pos - b.pos);
  const hasTimeline = s.slug === 'history';
  const done = list.filter(l => (progressOf(l.id) || {}).completed_at).length;

  setHTML(ctx.view, html`
  <nav class="crumbs" aria-label="Breadcrumb"><a href="/subjects">Subjects</a><span aria-hidden="true">/</span><span>${s.name}</span></nav>
  <header class="subject-head" style="--c:${s.color}"><span class="ico">${icon(s.icon)}</span><div><h1>${s.name}</h1><p>${s.description}</p></div></header>
  <div class="btn-row">
    <a class="btn secondary" href="/practice?subject=${s.slug}&grade=${grade}">${icon('quiz')}Practice test</a>
    ${hasTimeline ? html`<a class="btn secondary" href="/subjects/${s.slug}/timeline">${icon('timeline')}Timeline</a>` : ''}
    ${state.user ? html`<span class="muted small">${done} of ${plural(list.length, 'lesson')} done in Grade ${grade}</span>` : ''}
  </div>
  <div class="tabs" role="tablist" aria-label="Grade">
    ${grades.map(g => html`<a role="tab" href="/subjects/${s.slug}?grade=${g}" aria-selected="${g === grade}">Grade ${g}</a>`)}
  </div>
  ${!state.user ? html`<p class="notice">Lessons marked <b>Free to read</b> are open to everyone. <a href="/signup">Create a free account</a> to read the rest and save your progress.</p>` : ''}
  ${units.map(u => {
    const ls = list.filter(l => l.unitId === u.id);
    return html`<section class="unit" aria-labelledby="u-${u.id}"><h2 class="unit-title" id="u-${u.id}">${u.title}<small>${plural(ls.length, 'lesson')}</small></h2>
      <ol class="contents">${ls.map(contentsRow)}</ol></section>`;
  })}
  ${!list.length ? html`<div class="empty">No lessons published for this grade yet.</div>` : ''}`);
}

export async function timeline(ctx) {
  const s = subjectBySlug(ctx.params.slug);
  setHTML(ctx.view, loading());
  const data = await api(`/subjects/${ctx.params.slug}/timeline`);
  if (ctx.stale()) return;
  ctx.title(`${data.subject.name} timeline`);
  const grades = [...new Set(data.events.map(e => e.grade))].sort();
  setHTML(ctx.view, html`
  <nav class="crumbs" aria-label="Breadcrumb"><a href="/subjects">Subjects</a><span aria-hidden="true">/</span><a href="/subjects/${ctx.params.slug}">${data.subject.name}</a><span aria-hidden="true">/</span><span>Timeline</span></nav>
  <header class="page-head"><h1>${data.subject.name} timeline</h1><p>Key dates from every chapter, in order. Select an event’s chapter to read more.</p></header>
  <div class="tabs" role="tablist" aria-label="Filter by grade">
    <button role="tab" aria-selected="true" data-g="">All grades</button>${grades.map(g => html`<button role="tab" aria-selected="false" data-g="${g}">Grade ${g}</button>`)}
  </div>
  ${data.events.length ? html`<ol class="timeline">${data.events.map(e => html`<li data-grade="${e.grade}"><span class="when">${e.label}</span>
      <div class="what"><b>${e.title}</b>${e.detail ? html`<p>${e.detail}</p>` : ''}<p><a href="/lessons/${e.key}">Grade ${e.grade}, Ch ${e.number}: ${e.lesson}</a></p></div></li>`)}</ol>`
    : html`<div class="empty">No dated events for this subject yet.</div>`}`);
  $$('.tabs button', ctx.view).forEach(b => b.onclick = () => {
    $$('.tabs button', ctx.view).forEach(x => x.setAttribute('aria-selected', x === b));
    $$('.timeline li', ctx.view).forEach(li => li.hidden = !!b.dataset.g && li.dataset.grade !== b.dataset.g);
  });
}
