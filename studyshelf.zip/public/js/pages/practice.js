// Quizzes, flashcards and revision tests.
import { html, raw, icon, setHTML, $, $$, toast, loading, plural, errorBox } from '../ui.js';
import { api, ApiError } from '../api.js';
import { state, loadSummary, subjectBySlug } from '../store.js';

const originLabel = q => q.reviewed ? html`<span class="pill ok">Teacher-reviewed</span>`
  : q.origin === 'generated' ? html`<span class="pill gen" title="Made automatically from the flashcards and definitions in the notes. A teacher has not checked it yet.">Auto-generated, not yet reviewed</span>`
  : q.origin === 'manual' ? html`<span class="pill">Written by a teacher</span>` : html`<span class="pill">From the original notes</span>`;

/**
 * Run a quiz in `host`. Questions: {id,type,prompt,options,answer,explanation,origin,reviewed,lesson?,key?}
 */
export function runQuiz(host, questions, { kind = 'lesson', timed = 0, onRestart, title = 'Quiz' } = {}) {
  let i = 0; const answers = {}; let timer = null; let left = 0;
  const L = 'ABCDEF';
  function show() {
    clearInterval(timer);
    if (i >= questions.length) return finish();
    const q = questions[i];
    setHTML(host, html`<div class="qcard" aria-live="polite">
      <div class="qtop"><span>Question ${i + 1} of ${questions.length}${q.lesson ? html` · <a href="/lessons/${q.key}">${q.lesson}</a>` : ''}</span><span style="display:flex;gap:6px;align-items:center">${originLabel(q)}${timed ? html`<span class="pill" id="qt">${icon('clock')}<span>${timed}s</span></span>` : ''}</span></div>
      <div class="qbar" aria-hidden="true"><i style="width:${i * 100 / questions.length}%"></i></div>
      <div class="qprompt">${q.type === 'tf' ? html`<span class="small muted" style="display:block;font-family:var(--sh-font);font-weight:700">True or false?</span>` : ''}${raw(q.prompt)}</div>
      <div class="qopts" role="group" aria-label="Answer options">${q.options.map((o, j) => html`<button class="qopt" type="button" data-j="${j}"><span class="letter">${q.type === 'tf' ? (j ? 'F' : 'T') : L[j]}</span><span>${raw(o)}</span></button>`)}</div>
      <div id="fb"></div>
      <div class="qnav"><button class="btn ghost small" type="button" id="qquit">End quiz</button><button class="btn" type="button" id="qnext" hidden>${i === questions.length - 1 ? 'See my score' : 'Next question'}</button></div>
    </div>`);
    $$('.qopt', host).forEach(b => b.onclick = () => choose(+b.dataset.j));
    $('#qnext', host).onclick = () => { i++; show(); };
    $('#qquit', host).onclick = () => finish();
    host.addEventListener('keydown', keys);
    $('.qopt', host).focus({ preventScroll: true });
    if (timed) {
      left = timed;
      timer = setInterval(() => { left--; const t = $('#qt span', host); if (t) t.textContent = left + 's'; if (left <= 0) { clearInterval(timer); choose(-1); } }, 1000);
    }
  }
  function keys(e) {
    if (e.target.closest('input,textarea')) return;
    const n = 'abcdef'.indexOf(e.key.toLowerCase()); const q = questions[i];
    if (!q) return;
    if (answers[q.id] === undefined) {
      if (q.type === 'tf' && (e.key === 't' || e.key === 'f')) choose(e.key === 't' ? 0 : 1);
      else if (n >= 0 && n < q.options.length && q.type !== 'tf') choose(n);
    }
  }
  function choose(j) {
    clearInterval(timer);
    const q = questions[i]; if (answers[q.id] !== undefined) return;
    answers[q.id] = j;
    $$('.qopt', host).forEach((b, k) => { b.disabled = true; if (k === q.answer) b.classList.add('right'); else if (k === j) b.classList.add('wrong'); });
    const ok = j === q.answer;
    setHTML($('#fb', host), html`<div class="qfeedback" role="status"><b style="color:${ok ? 'var(--sh-ok)' : 'var(--sh-bad)'}">${ok ? 'Correct.' : j < 0 ? 'Time’s up.' : 'Not quite.'}</b>${q.explanation ? raw(q.explanation) : html`The answer is ${raw(q.options[q.answer])}.`}</div>`);
    const nx = $('#qnext', host); nx.hidden = false; nx.focus();
  }
  async function finish() {
    clearInterval(timer); host.removeEventListener('keydown', keys);
    const asked = questions.filter(q => answers[q.id] !== undefined);
    const score = asked.filter(q => answers[q.id] === q.answer).length;
    if (!asked.length) { onRestart ? onRestart() : null; return; }
    let saved = '';
    if (state.user) {
      try { await api('/quiz/attempt', { method: 'POST', body: { kind, answers: Object.fromEntries(asked.map(q => [q.id, answers[q.id] < 0 ? -1 : answers[q.id]])) } }); saved = 'Saved to your progress.'; loadSummary(); }
      catch (e) { saved = 'Your score couldn’t be saved: ' + e.message; }
    } else saved = 'Log in to save scores to your progress.';
    const pct = Math.round(score * 100 / asked.length);
    setHTML(host, html`<div class="qcard">
      <p class="muted" style="margin:0">${title}</p>
      <div class="score-big">${score}/${asked.length}</div>
      <p><b>${pct >= 80 ? 'Excellent work.' : pct >= 60 ? 'Good. Review the ones you missed.' : 'Keep going: reread the notes, then try again.'}</b> <span class="muted small">${saved}</span></p>
      <div class="btn-row"><button class="btn" type="button" id="again">${icon('refresh')}Try again</button>${state.user ? html`<a class="btn secondary" href="/progress">See my progress</a>` : html`<a class="btn secondary" href="/signup">Create a free account</a>`}</div>
      <h2 style="margin-top:22px;font-size:1.1rem">Your answers</h2>
      <div class="review-list">${asked.map(q => { const ok = answers[q.id] === q.answer; return html`<div class="review-item ${ok ? 'r' : 'w'}">
        <div>${raw(q.prompt)}</div><div class="small" style="margin-top:6px">${ok ? html`<b style="color:var(--sh-ok)">Correct:</b> ` : html`<b style="color:var(--sh-bad)">${answers[q.id] < 0 ? 'No answer.' : 'You chose ' + ''}</b>${answers[q.id] >= 0 ? raw(q.options[answers[q.id]]) : ''}. <b>Answer:</b> `}${raw(q.options[q.answer])}</div></div>`; })}</div>
    </div>`);
    $('#again', host).onclick = () => onRestart ? onRestart() : (i = 0, Object.keys(answers).forEach(k => delete answers[k]), show());
    $('#again', host).focus();
  }
  show();
  return () => clearInterval(timer);
}

const shuffle = a => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; };

async function getLesson(ctx) {
  try { return (await api(`/lessons/${encodeURIComponent(ctx.params.key)}`)).lesson; }
  catch (e) {
    if (e instanceof ApiError && e.status === 401) {
      setHTML(ctx.view, html`<div class="locked-note"><h1>Log in to practise this lesson</h1><p class="muted">${e.data.preview ? e.data.preview.title : ''}</p><div class="btn-row"><a class="btn" href="/signup">Create a free account</a><a class="btn secondary" href="/login?next=${encodeURIComponent(location.pathname)}">Log in</a></div></div>`);
      return null;
    }
    throw e;
  }
}

export async function lessonQuiz(ctx) {
  setHTML(ctx.view, loading());
  const L = await getLesson(ctx); if (!L || ctx.stale()) return;
  ctx.title(`Quiz: ${L.title}`);
  const nGen = L.questions.filter(q => q.origin === 'generated' && !q.reviewed).length;
  setHTML(ctx.view, html`
  <nav class="crumbs" aria-label="Breadcrumb"><a href="/subjects/${L.subject.slug}">${L.subject.name}</a><span aria-hidden="true">/</span><a href="/lessons/${L.key}">${L.title}</a><span aria-hidden="true">/</span><span>Quiz</span></nav>
  <header class="page-head"><h1>Quiz: ${L.title}</h1><p>${plural(L.questions.length, 'question')}. Choose an answer to see straight away if it’s right${nGen ? ', with an explanation.' : '.'}</p></header>
  ${nGen ? html`<div class="notice small"><b>${nGen} of these questions were made automatically</b> from the flashcards and definitions in the notes, and are labelled. A teacher hasn’t checked them yet.
    <label class="check" style="margin-top:8px"><input type="checkbox" id="onlyOrig"><span>Only use questions from the original notes (${L.questions.length - nGen})</span></label></div>` : ''}
  <div class="quiz" id="qhost"></div>`);
  if (!L.questions.length) { setHTML($('#qhost', ctx.view), html`<div class="empty"><h3>No quiz for this lesson yet</h3><p>Try the flashcards or a practice test instead.</p><a class="btn" href="/practice">Practice tests</a></div>`); return; }
  let stop;
  const start = () => {
    if (stop) stop();
    const only = $('#onlyOrig', ctx.view) && $('#onlyOrig', ctx.view).checked;
    const qs = L.questions.filter(q => !only || q.origin !== 'generated' || q.reviewed);
    stop = runQuiz($('#qhost', ctx.view), shuffle(qs), { kind: 'lesson', title: `Quiz: ${L.title}`, onRestart: start });
  };
  const oo = $('#onlyOrig', ctx.view); if (oo) oo.onchange = start;
  start(); ctx.onLeave(() => stop && stop());
}

export async function flashcards(ctx) {
  setHTML(ctx.view, loading());
  const L = await getLesson(ctx); if (!L || ctx.stale()) return;
  ctx.title(`Flashcards: ${L.title}`);
  let deck = [...L.flashcards], i = 0; const again = new Set(), known = new Set();
  setHTML(ctx.view, html`
  <nav class="crumbs" aria-label="Breadcrumb"><a href="/subjects/${L.subject.slug}">${L.subject.name}</a><span aria-hidden="true">/</span><a href="/lessons/${L.key}">${L.title}</a><span aria-hidden="true">/</span><span>Flashcards</span></nav>
  <header class="page-head"><h1>Flashcards: ${L.title}</h1><p>Tap the card or press Space to flip it. Sort each card into “Got it” or “Again”.</p></header>
  <div id="fch"></div>`);
  const host = $('#fch', ctx.view);
  if (!deck.length) { setHTML(host, html`<div class="empty"><h3>No flashcards for this lesson yet</h3><a class="btn" href="/lessons/${L.key}">Back to the note</a></div>`); return; }
  function show() {
    if (i >= deck.length) {
      setHTML(host, html`<div class="qcard" style="max-width:620px"><div class="score-big">${known.size}/${deck.length}</div><p>cards you knew. ${again.size ? `${plural(again.size, 'card')} to practise again.` : 'You got every card!'}</p>
        <div class="btn-row">${again.size ? html`<button class="btn" id="redo">Practise the ${again.size} again</button>` : ''}<button class="btn secondary" id="restart">Start over</button><a class="btn ghost" href="/lessons/${L.key}">Back to the note</a></div></div>`);
      const r = $('#redo', host); if (r) r.onclick = () => { deck = deck.filter(c => again.has(c.id)); again.clear(); known.clear(); i = 0; show(); };
      $('#restart', host).onclick = () => { deck = [...L.flashcards]; again.clear(); known.clear(); i = 0; show(); };
      return;
    }
    const c = deck[i];
    setHTML(host, html`<div class="fc-stage">
      <p class="small muted" style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><span>Card ${i + 1} of ${deck.length}</span>${c.origin === 'extracted' ? html`<span class="pill gen" title="Picked out automatically from the definitions in the notes">Picked out from the notes automatically</span>` : ''}</p>
      <button class="flash" type="button" aria-pressed="false" aria-label="Flashcard. Press to flip."><span class="face front"><small>Term or question</small><strong>${raw(c.front)}</strong><small>Tap to see the answer</small></span><span class="face back"><small>Answer</small><span>${raw(c.back)}</span></span></button></div>
      <div class="fc-controls"><button class="btn secondary" id="prevc" ${i === 0 ? raw('disabled') : ''}>${icon('left')}Back</button>
        <div class="btn-row"><button class="btn secondary" id="againc">Again</button><button class="btn hl" id="gotc">${icon('check')}Got it</button></div>
        <button class="btn ghost small" id="shuf">Shuffle</button></div>`);
    const f = $('.flash', host);
    f.onclick = () => f.setAttribute('aria-pressed', f.getAttribute('aria-pressed') !== 'true');
    $('#gotc', host).onclick = () => { known.add(c.id); again.delete(c.id); i++; show(); };
    $('#againc', host).onclick = () => { again.add(c.id); known.delete(c.id); i++; show(); };
    $('#prevc', host).onclick = () => { if (i > 0) { i--; show(); } };
    $('#shuf', host).onclick = () => { deck = shuffle(deck); i = 0; again.clear(); known.clear(); show(); toast('Cards shuffled'); };
    f.focus({ preventScroll: true });
  }
  const onKey = e => {
    if (e.target.closest('input,textarea,select')) return;
    const f = $('.flash', host); if (!f) return;
    if (e.key === ' ' && e.target !== f) { e.preventDefault(); f.click(); }
    else if (e.key === 'ArrowRight') $('#gotc', host).click();
    else if (e.key === 'ArrowLeft') $('#prevc', host).click();
  };
  document.addEventListener('keydown', onKey); ctx.onLeave(() => document.removeEventListener('keydown', onKey));
  show();
}

export async function practice(ctx) {
  ctx.title('Practice tests');
  const c = state.catalog; const u = state.user;
  const pre = { subject: ctx.query.get('subject') || '', grade: ctx.query.get('grade') || (u && u.grade ? String(u.grade) : '') };
  setHTML(ctx.view, html`
  <header class="page-head"><h1>Practice tests</h1><p>A short revision test mixed from many lessons. Pick what to cover, then answer one question at a time.</p></header>
  <div class="dash-grid">
    <form class="panel form" id="pf">
      <div class="field"><span class="label">Subject</span><div class="choice-row">
        <label class="choice"><input type="radio" name="subject" value="" ${!pre.subject ? raw('checked') : ''}><span>All subjects</span></label>
        ${c.subjects.map(s => html`<label class="choice"><input type="radio" name="subject" value="${s.slug}" ${pre.subject === s.slug ? raw('checked') : ''}><span>${s.name}</span></label>`)}</div></div>
      <div class="field"><span class="label">Grade</span><div class="choice-row">
        <label class="choice"><input type="radio" name="grade" value="" ${!pre.grade ? raw('checked') : ''}><span>Both</span></label>
        ${c.grades.map(g => html`<label class="choice"><input type="radio" name="grade" value="${g}" ${pre.grade === String(g) ? raw('checked') : ''}><span>Grade ${g}</span></label>`)}</div></div>
      <div class="field"><label for="p-l">Lessons</label><select class="input" id="p-l" name="lessons" multiple size="6"></select><span class="hint">Leave empty to use every lesson. Hold Ctrl (or ⌘) to pick several.</span></div>
      <div class="field"><span class="label">Question type</span><div class="choice-row">
        <label class="choice"><input type="radio" name="type" value="" checked><span>Mixed</span></label><label class="choice"><input type="radio" name="type" value="mcq"><span>Multiple choice</span></label><label class="choice"><input type="radio" name="type" value="tf"><span>True or false</span></label></div></div>
      <div class="field"><span class="label">Length</span><div class="choice-row">${[5, 10, 20].map(n => html`<label class="choice"><input type="radio" name="n" value="${n}" ${n === 10 ? raw('checked') : ''}><span>${n} questions</span></label>`)}</div></div>
      <label class="check"><input type="checkbox" name="reviewed" value="1"><span>Only questions from the original notes or reviewed by a teacher (no auto-generated ones)</span></label>
      <label class="check"><input type="checkbox" name="timed" value="1"><span>Timed: 30 seconds per question</span></label>
      ${!u ? html`<p class="notice small">Without an account, tests use the free lessons only and scores aren’t saved. <a href="/signup">Create a free account</a>.</p>` : ''}
      <div><button class="btn" type="submit">${icon('play')}Start test</button></div>
    </form>
    <div id="qhost" class="quiz"></div>
  </div>`);
  const form = $('#pf', ctx.view);
  const fillLessons = () => {
    const sub = subjectBySlug(form.subject.value); const g = +form.grade.value;
    const ls = c.lessons.filter(l => l.questions && (!sub || l.subjectId === sub.id) && (!g || l.grade === g) && (u || l.guest));
    setHTML($('#p-l', form), html`${ls.map(l => html`<option value="${l.id}">${sub ? '' : c.subjects.find(s => s.id === l.subjectId).name + ', '}G${l.grade} Ch ${l.number}: ${l.title}</option>`)}`);
  };
  fillLessons();
  form.addEventListener('change', e => { if (e.target.name === 'subject' || e.target.name === 'grade') fillLessons(); });
  let stop;
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const p = new URLSearchParams({ n: fd.get('n') });
    ['subject', 'grade', 'type'].forEach(k => fd.get(k) && p.set(k, fd.get(k)));
    const ls = [...$('#p-l', form).selectedOptions].map(o => o.value); if (ls.length) p.set('lessons', ls.join(','));
    if (fd.get('reviewed')) p.set('origin', 'reviewed');
    const host = $('#qhost', ctx.view);
    setHTML(host, loading('Building your test…'));
    try {
      const r = await api('/practice?' + p);
      if (!r.questions.length) { setHTML(host, html`<div class="empty"><h3>No questions match these choices</h3><p>Choose another subject or include auto-generated questions.</p></div>`); return; }
      if (stop) stop();
      const subj = subjectBySlug(fd.get('subject'));
      stop = runQuiz(host, r.questions, { kind: 'practice', timed: fd.get('timed') ? 30 : 0, title: `Practice test${subj ? ': ' + subj.name : ''}`, onRestart: () => form.requestSubmit() });
      if (matchMedia('(max-width: 1050px)').matches) host.scrollIntoView({ behavior: 'smooth' });
    } catch (err) { setHTML(host, errorBox(err.message)); }
  });
  ctx.onLeave(() => stop && stop());
}
