// Client-side state: the signed-in user, the catalog, and the student's own activity.
import { api } from './api.js';

export const state = { user: null, catalog: null, summary: null, mailConfigured: false };
const listeners = new Set();
export const onChange = fn => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => listeners.forEach(fn => fn(state));

let idx = null;
function index() {
  const c = state.catalog;
  idx = {
    lessonById: new Map(c.lessons.map(l => [l.id, l])),
    lessonByKey: new Map(c.lessons.map(l => [l.key, l])),
    subjectById: new Map(c.subjects.map(s => [s.id, s])),
    subjectBySlug: new Map(c.subjects.map(s => [s.slug, s])),
    unitById: new Map(c.units.map(u => [u.id, u]))
  };
}
export async function loadCatalog(force = false) {
  if (state.catalog && !force) return state.catalog;
  state.catalog = await api('/catalog'); index(); return state.catalog;
}
export async function loadMe() {
  const r = await api('/auth/me'); state.user = r.user; state.mailConfigured = r.mailConfigured;
  if (state.user) await loadSummary(); else state.summary = null;
  emit(); return state.user;
}
export async function loadSummary() {
  if (!state.user) { state.summary = null; return null; }
  const s = await api('/me/summary');
  state.summary = {
    progress: new Map(s.progress.map(p => [p.id, p])),
    bookmarks: s.bookmarks, quizzes: s.quizzes
  };
  emit(); return state.summary;
}
export function setUser(u) { state.user = u; emit(); }

export const lessonById = id => idx && idx.lessonById.get(id);
export const lessonByKey = k => idx && idx.lessonByKey.get(k);
export const subjectById = id => idx && idx.subjectById.get(id);
export const subjectBySlug = s => idx && idx.subjectBySlug.get(s);
export const unitById = id => idx && idx.unitById.get(id);
export const progressOf = id => (state.summary && state.summary.progress.get(id)) || null;
export const isMarked = (id, kind) => !!(state.summary && state.summary.bookmarks.some(b => b.id === id && b.kind === kind));
export function bestQuiz(id) {
  if (!state.summary) return null;
  const qs = state.summary.quizzes.filter(q => q.lesson_id === id && q.total > 0);
  return qs.length ? Math.max(...qs.map(q => Math.round(q.score * 100 / q.total))) : null;
}
export function lessonsFor({ subjectId, grade } = {}) {
  return state.catalog.lessons.filter(l => (!subjectId || l.subjectId === subjectId) && (!grade || l.grade === grade))
    .sort((a, b) => a.grade - b.grade || a.number - b.number);
}
/** Lessons in reading order within their subject+grade. */
export function neighbours(lesson) {
  const list = lessonsFor({ subjectId: lesson.subjectId, grade: lesson.grade });
  const i = list.findIndex(l => l.id === lesson.id);
  return { prev: list[i - 1] || null, next: list[i + 1] || null };
}

/**
 * Recommendations: the next unfinished lesson in each followed subject, lessons
 * flagged for revision, and lessons with a weak quiz score. Each item carries a reason.
 */
export function recommendations(limit = 6) {
  const u = state.user; if (!u || !state.catalog) return [];
  const out = []; const seen = new Set();
  const add = (l, why) => { if (l && !seen.has(l.id)) { seen.add(l.id); out.push({ lesson: l, why }); } };
  const subjects = u.subjects && u.subjects.length ? u.subjects.map(subjectBySlug).filter(Boolean) : state.catalog.subjects;
  for (const s of subjects) {
    const list = lessonsFor({ subjectId: s.id, grade: u.grade });
    const firstOpen = list.find(l => !(progressOf(l.id) || {}).completed_at);
    if (firstOpen) add(firstOpen, (progressOf(firstOpen.id) || {}).views ? 'Pick up where you stopped' : `Next in ${s.name}`);
  }
  for (const [id, p] of state.summary ? state.summary.progress : []) if (p.revise) add(lessonById(id), 'You marked this to revise');
  for (const q of state.summary ? state.summary.quizzes : []) if (q.lesson_id && q.total && q.score / q.total < 0.6) add(lessonById(q.lesson_id), `Quiz score ${Math.round(q.score * 100 / q.total)}% — worth another look`);
  return out.slice(0, limit);
}
