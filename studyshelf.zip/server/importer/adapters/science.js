'use strict';
// Adapters for the two Science sites. They cover the same textbook chapters,
// so both produce lessons keyed science-g{grade}-c{nn}; the importer merges
// them into one lesson with a "Short notes" and a "Detailed notes" tab.
const U = require('../util');

const STRAND = { bio: 'Biology', chem: 'Chemistry', phys: 'Physics' };
const keyOf = (g, n) => `science-g${g}-c${String(n).padStart(2, '0')}`;
const gradeOf = src => +((/Grade (1[01]) Science/.exec(src.html) || [])[1] || 0);

const descriptive = {
  id: 'science-descriptive',
  detect: src => /Science Descriptive Notes/.test(src.html) && src.document.querySelector('article.chap'),
  run(src, ctx) {
    const grade = gradeOf(src);
    const lessons = [];
    const allClasses = new Set();
    const KIND = { def: 'def', ex: 'example', fx: 'formula', tip: 'exam' };
    for (const art of src.document.querySelectorAll('article.chap')) {
      const n = +art.dataset.n, s = art.dataset.s;
      const key = keyOf(grade, n);
      const title = art.querySelector('.ch-head h2').textContent.trim();
      const intro = (art.querySelector('.ch-head .intro') || {}).innerHTML || '';
      const { doc, root, html } = U.frag([...art.querySelectorAll(':scope > section.sec')].map(x => x.outerHTML).join(''));
      U.commonClean(root, doc);
      const flashcards = [];
      root.querySelectorAll('div.def, div.ex, div.fx, div.tip').forEach(d => {
        const k = [...d.classList].find(c => KIND[c]);
        const lab = d.querySelector(':scope > .lab');
        const title = lab ? lab.textContent.trim() : { def: 'Definition', example: 'Worked example', formula: 'Formula', exam: 'Exam tip' }[KIND[k]];
        if (lab) lab.remove();
        if (k === 'def') {
          // "<b>Term</b> — definition" → flashcard
          const p = d.querySelector('p'); const b = p && p.querySelector('b');
          if (b && p.firstElementChild === b) {
            const back = p.innerHTML.slice(p.innerHTML.indexOf('</b>') + 4).replace(/^\s*[—–:-]\s*/, '').trim();
            if (back) flashcards.push({ front: b.innerHTML.trim(), back, origin: 'extracted' });
          }
        }
        U.toCallout(doc, d, KIND[k], title, d.innerHTML);
      });
      const toc = U.sectionize(root, key + '-d');
      const noteHtml = html();
      U.classesIn(noteHtml, allClasses);
      lessons.push({
        key, subject: 'science', grade, number: n, unit: STRAND[s] || 'General', title,
        summary: U.textOf(intro),
        notes: [{ kind: 'detailed', title: 'Detailed notes', html: noteHtml, toc, scope: `src-sci-g${grade}d` }],
        flashcards, questions: [], source: `science-g${grade}-descriptive`
      });
    }
    if (!lessons.length) ctx.log('error', 'Science descriptive: no chapters found');
    return { lessons, css: { [`src-sci-g${grade}d`]: U.scopeCss(src.css, `src-sci-g${grade}d`, allClasses) } };
  }
};

const pocket = {
  id: 'science-pocket',
  detect: src => /Science Pocket Notes/.test(src.html) && Array.isArray(src.get('CH')),
  run(src, ctx) {
    const grade = gradeOf(src);
    const CH = src.get('CH');
    const ptsWithFigs = src.get('ptsWithFigs');
    const pack = `sci-g${grade}`;
    const lessons = [];
    const allClasses = new Set();
    for (const c of CH) {
      const key = keyOf(grade, c.n);
      const parts = [];
      parts.push(`<section><h2>Key points</h2>${typeof ptsWithFigs === 'function' ? ptsWithFigs(c) : `<ul class="pts">${c.pts.map(p => `<li>${p}</li>`).join('')}</ul>`}</section>`);
      if (c.f && c.f.length) parts.push(`<section><h2>Formulas &amp; facts to remember</h2><div class="formula-list">${c.f.map(x => `<div class="formula">${x}</div>`).join('')}</div></section>`);
      if (c.trick || c.trap) parts.push(`<section><h2>Tricks &amp; traps</h2>${c.trick ? U.callout('trick', 'Memory trick', `<p>${c.trick}</p>`) : ''}${c.trap ? U.callout('warn', 'Exam trap', `<p>${c.trap}</p>`) : ''}</section>`);
      if (c.table && c.table.length > 1) parts.push(`<section><h2>At a glance</h2><table><thead><tr>${c.table[0].map(x => `<th>${x}</th>`).join('')}</tr></thead><tbody>${c.table.slice(1).map(r => `<tr>${r.map(x => `<td>${x}</td>`).join('')}</tr>`).join('')}</tbody></table></section>`);
      if (c.lab) parts.push(`<section><h2>Mini-lab</h2><div class="sh-ix" data-pack="${pack}" data-name="${U.esc(c.lab)}"></div></section>`);
      const { doc, root, html } = U.frag(parts.join(''));
      U.commonClean(root, doc);
      root.querySelectorAll('ul.pts').forEach(u => u.className = 'key-points');
      const toc = U.sectionize(root, key + '-p');
      root.querySelectorAll(':scope > section').forEach(sec => sec.setAttribute('data-s', c.s)); // subject accent used by figures and labs
      const noteHtml = html();
      U.classesIn(noteHtml, allClasses);
      lessons.push({
        key, subject: 'science', grade, number: c.n, unit: STRAND[c.s] || 'General', title: c.t,
        hook: c.hook,
        notes: [{ kind: 'short', title: 'Short notes', html: noteHtml, toc, scope: `src-sci-g${grade}p` }],
        flashcards: (c.cards || []).map(([a, b]) => ({ front: a, back: b, origin: 'imported' })),
        questions: (c.q || []).map(q => ({ type: 'mcq', origin: 'imported', prompt: q.q, options: q.o, answer: q.a, explanation: q.e || '' })),
        interactives: c.lab ? [{ pack, name: c.lab }] : [],
        source: `science-g${grade}-pocket`
      });
    }
    // Interactive pack: the original mini-lab code, sliced out of the page script.
    const script = src.scripts.find(s => /const LABS\s*=/.test(s));
    let packJs = null;
    if (script) {
      const st = U.topLevel(script);
      const wanted = new Set(['fmt', 'sci', 'slider', 'ro', 'bind', 'V', 'EL', 'ELN', 'KIND', 'LABS']);
      const code = st.filter(x => x.names.some(n => wanted.has(n))).map(x => x.code).join('\n');
      packJs = `/* Mini-labs imported from "Grade ${grade} Science Pocket Notes" (original code). */
(function(){
const $=s=>document.querySelector(s);
function toast(m){ if(window.SH&&SH.toast) SH.toast(m); }
function addXP(){}
${code}
(window.SH_IX=window.SH_IX||{})[${JSON.stringify(pack)}]={
  names:Object.keys(LABS),
  mount(name, el){ if(!LABS[name]) throw new Error('Unknown lab '+name); el.classList.add('lab'); LABS[name](el); }
};
})();`;
      U.classTokensInJs(code, allClasses);
      ['lab', 'ctrl', 'ro', 'row', 'btn'].forEach(c => allClasses.add(c));
    } else ctx.log('warn', `Science pocket g${grade}: mini-lab code not found; labs will show as unavailable`);
    const scope = `src-sci-g${grade}p`;
    return { lessons, packs: packJs ? { [pack]: packJs } : {}, css: { [scope]: U.scopeCss(src.css, scope, allClasses) } };
  }
};

module.exports = { descriptive, pocket };
