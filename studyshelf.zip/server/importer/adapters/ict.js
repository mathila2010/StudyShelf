'use strict';
// Adapter: "Grade 10 & 11 ICT Notes" — chapters are server-rendered <article> views.
const U = require('../util');

const UNITS = {
  10: [[1, 5, 'Computer Fundamentals'], [6, 9, 'Office Applications']],
  11: [[1, 2, 'Programming and System Development'], [3, 5, 'Internet, Multimedia and the Web'], [6, 6, 'ICT and Society']]
};
const unitFor = (g, n) => (UNITS[g].find(([a, b]) => n >= a && n <= b) || [0, 0, 'General'])[2];
const KIND = { 'co-example': 'example', 'co-fact': 'fact', 'co-tip': 'tip', 'co-warn': 'warn' };

module.exports = {
  id: 'ict',
  detect: src => /Grade 10 &(amp;)? 11 ICT Notes/.test(src.html) && src.document.querySelector('article.view.chapter'),
  run(src, ctx) {
    const lessons = [];
    const allClasses = new Set();
    for (const art of src.document.querySelectorAll('article.view.chapter')) {
      const m = /^g(1[01])-(\d+)$/.exec(art.dataset.view || '');
      if (!m) { ctx.log('warn', `ICT: skipped view "${art.dataset.view}"`); continue; }
      const grade = +m[1], n = +m[2];
      const h1 = art.querySelector('.ch-head h1');
      h1.querySelectorAll('.ch-num').forEach(x => x.remove());
      const title = h1.textContent.trim();
      const lede = (art.querySelector('.ch-head .lede') || {}).innerHTML || '';
      const key = `ict-g${grade}-c${String(n).padStart(2, '0')}`;

      // questions from "Check yourself"
      const questions = [];
      art.querySelectorAll('section.quiz li.qz-q').forEach(li => {
        const opts = [...li.querySelectorAll('.qz-opt')];
        const fb = li.querySelector('.qz-fb');
        let expl = '';
        if (fb) { const c = fb.cloneNode(true); c.querySelectorAll('.qz-verdict, .qz-ans').forEach(x => x.remove()); expl = c.innerHTML.trim(); }
        questions.push({
          type: 'mcq', origin: 'imported',
          prompt: li.querySelector('.qz-text').innerHTML.trim(),
          options: opts.map(o => { const s = o.querySelectorAll('span'); return (s[s.length - 1] || o).innerHTML.trim(); }),
          answer: opts.findIndex(o => o.dataset.ok === '1'),
          explanation: expl
        });
      });
      // flashcards from "Key terms"
      const flashcards = [...art.querySelectorAll('section.terms .term')].map(t => ({
        front: t.querySelector('dt').innerHTML.trim(), back: t.querySelector('dd').innerHTML.trim(), origin: 'imported'
      }));

      // note body
      const body = art.querySelector('.ch-body').cloneNode(true);
      body.querySelectorAll('section.quiz').forEach(s => s.remove());
      const { doc, root, html } = U.frag(body.innerHTML);
      U.commonClean(root, doc);
      root.querySelectorAll('aside.co').forEach(a => {
        const kindCls = [...a.classList].find(c => KIND[c]);
        const title = (a.querySelector('.co-title') || a.querySelector('.co-kind') || { textContent: 'Note' }).textContent.trim();
        const kindLabel = (a.querySelector('.co-kind') || { textContent: '' }).textContent.trim();
        const b = a.querySelector('.co-body');
        U.toCallout(doc, a, KIND[kindCls] || 'fact', kindLabel && kindLabel !== title ? `${kindLabel}: ${title}` : title, b ? b.innerHTML : '');
      });
      root.querySelectorAll('section.terms dl').forEach(dl => {
        dl.className = 'key-terms';
        dl.querySelectorAll('div.term').forEach(d => d.removeAttribute('class'));
      });
      root.querySelectorAll('section[data-sec]').forEach(s => s.removeAttribute('data-sec'));
      const toc = U.sectionize(root, key);
      const noteHtml = html();
      U.classesIn(noteHtml, allClasses);

      lessons.push({
        key, subject: 'ict', grade, number: n, unit: unitFor(grade, n), title,
        summary: U.textOf(lede),
        notes: [{ kind: 'notes', title: 'Notes', html: noteHtml, toc, scope: 'src-ict' }],
        flashcards, questions, source: 'ict-g10-11'
      });
    }
    const css = U.scopeCss(src.css, 'src-ict', allClasses);
    return { lessons, css: { 'src-ict': css } };
  }
};
