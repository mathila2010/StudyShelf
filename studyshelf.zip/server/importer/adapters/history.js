'use strict';
// Adapter: "O/L History Companion" — chapters in a CHAPTERS array with sections,
// takeaways, flashcards, quizzes, timeline events and embedded photographs.
const U = require('../util');

const UNITS = {
  10: n => (n <= 8 ? 'Ancient and Medieval Sri Lanka' : 'Europe and the Modern World'),
  11: n => ([1, 7, 8].includes(n) ? 'World History' : 'Sri Lanka under British Rule')
};

module.exports = {
  id: 'history',
  detect: src => /History Companion/.test(src.html) && Array.isArray(src.get('CHAPTERS')),
  run(src, ctx) {
    const CH = src.get('CHAPTERS');
    const IMG = src.get('IMG') || {};
    const IMGSRC = src.get('IMGSRC');
    const media = ctx.media;
    const lessons = [];
    const allClasses = new Set();
    const imageUrl = name => {
      const uri = IMGSRC ? IMGSRC(name) : '';
      if (!uri) { ctx.log('warn', `History: image "${name}" missing from source`); return ''; }
      return media.saveDataUri(uri, 'history', name);
    };
    for (const c of CH) {
      const key = `history-g${c.grade}-c${String(c.n).padStart(2, '0')}`;
      const secs = c.sections.map(s => `<section><h2>${s.t}</h2>${s.html}</section>`);
      secs.push(`<section><h2>Key takeaways</h2><ol class="takeaways">${c.takeaways.map(t => `<li>${t}</li>`).join('')}</ol>` +
        (c.apply && c.apply.length ? `<h3>In the real world</h3><div class="apply-cards">${c.apply.map(a => `<div class="apply-card"><h4>${a[0]}</h4><p>${a[1]}</p></div>`).join('')}</div>` : '') + `</section>`);
      const { doc, root, html } = U.frag(secs.join(''));
      U.commonClean(root, doc);
      media.rewriteImages(root, 'history');
      root.querySelectorAll('div.def').forEach(d => {
        const b = d.querySelector(':scope > b'); const title = b ? b.textContent.trim() : 'Definition'; if (b) b.remove();
        U.toCallout(doc, d, 'def', title, d.innerHTML);
      });
      root.querySelectorAll('div.note').forEach(d => {
        const kind = d.classList.contains('exam') ? 'exam' : d.classList.contains('fact') ? 'fact' : 'tip';
        const b = d.querySelector(':scope > b.t'); const title = b ? b.textContent.trim() : 'Note'; if (b) b.remove();
        U.toCallout(doc, d, kind, title, d.innerHTML);
      });
      const ix = [];
      root.querySelectorAll('[data-widget]').forEach(w => {
        const name = w.dataset.widget; ix.push({ pack: 'history', name });
        const t = doc.createElement('div'); t.className = 'sh-ix'; t.dataset.pack = 'history'; t.dataset.name = name; w.replaceWith(t);
      });
      const toc = U.sectionize(root, key);
      const noteHtml = html();
      U.classesIn(noteHtml, allClasses);
      lessons.push({
        key, subject: 'history', grade: c.grade, number: c.n, unit: UNITS[c.grade](c.n), title: c.title,
        summary: U.textOf(c.lede), era: c.era,
        image: c.img ? { url: imageUrl(c.img), alt: (IMG[c.img] || {}).alt || U.textOf(c.imgCap || ''), caption: c.imgCap || '' } : null,
        notes: [{ kind: 'notes', title: 'Notes', html: noteHtml, toc, scope: 'src-hist' }],
        flashcards: (c.flash || []).map(([a, b]) => ({ front: a, back: b, origin: 'imported' })),
        questions: (c.quiz || []).map(q => ({ type: 'mcq', origin: 'imported', prompt: q[0], options: q[1], answer: q[2], explanation: q[3] || '' })),
        events: (c.events || []).map(e => ({ label: e[0], year: e[1], title: e[2], detail: e[3] || '' })),
        interactives: ix, source: 'history-companion'
      });
    }
    // Interactive pack: generic widget builders + the WIDGETS definitions (original code).
    const script = src.scripts.find(s => /const WIDGETS\s*=/.test(s));
    const packs = {};
    if (script) {
      const st = U.topLevel(script);
      const wanted = new Set(['esc', 'mkExplorer', 'mkTimeline', 'mkStepper', 'mkCompare', 'mkTabs', 'mkBars', 'WIDGETS']);
      const code = st.filter(x => x.names.some(n => wanted.has(n))).map(x => x.code).join('\n');
      // widgets may show photos: point them at the extracted media files
      // (widgets look images up by name at run time, so map every image the page carries)
      const imgMap = {};
      for (const name of Object.keys(src.get('IMGDATA') || {})) imgMap[name] = imageUrl(name);
      const imgMeta = {};
      for (const [k, v] of Object.entries(IMG)) imgMeta[k] = { alt: v.alt, cap: v.cap };
      packs.history = `/* Interactive activities imported from "O/L History Companion" (original code). */
(function(){
const __IMG=${JSON.stringify(imgMap)};
const IMG=${JSON.stringify(imgMeta)};
function IMGSRC(k){ return __IMG[k]||''; }
const d = s => '<span class="date">'+s+'</span>';
const k = s => '<span class="k">'+s+'</span>';
${code}
(window.SH_IX=window.SH_IX||{}).history={
  names:Object.keys(WIDGETS),
  mount(name, el){
    const w=WIDGETS[name]; if(!w) throw new Error('Unknown activity '+name);
    el.classList.add('widget');
    el.innerHTML='<div class="wh"><h3>'+w.title+'</h3><span>'+(w.hint||'')+'</span></div><div class="wbody"></div>';
    w.render(el.querySelector('.wbody'));
  }
};
})();`;
      U.classTokensInJs(code, allClasses);
      ['widget', 'wh', 'wbody', 'btn', 'ghost', 'small'].forEach(c => allClasses.add(c));
    } else ctx.log('warn', 'History: widget code not found; activities will show as unavailable');
    return { lessons, packs, css: { 'src-hist': U.scopeCss(src.css, 'src-hist', allClasses) } };
  }
};
