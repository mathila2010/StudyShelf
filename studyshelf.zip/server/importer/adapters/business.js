'use strict';
// Adapter: "Business & Accounting Notes" — chapters live in a DATA object {g10:[…], g11:[…]}.
const U = require('../util');

const UNITS = {
  10: n => (n <= 3 ? 'Business Studies' : 'Accounting'),
  11: n => (n <= 3 || n === 8 ? 'Business Studies' : 'Accounting')
};
const KIND = { def: 'def', think: 'think', exam: 'exam', hook: 'trick', check: 'check' };
const DEFAULT_TITLE = { def: 'Definition', think: 'Think of it like…', exam: 'Exam alert', trick: 'Memory hook', check: 'Quick check' };

// "A business is an economic activity…" → { term: "Business", def: "…" }
function termFromDefinition(text) {
  const t = text.replace(/^Book definition:\s*/i, '').trim();
  const m = /^(?:An?\s+|The\s+)?(.{2,60}?)\s+(?:is|are|means|refers to|can be defined as|is defined as)\s+(.{10,})$/i.exec(t);
  if (!m || /[,;:]/.test(m[1]) || m[1].split(' ').length > 7) return null;
  return { term: m[1].charAt(0).toUpperCase() + m[1].slice(1), def: t };
}

module.exports = {
  id: 'business',
  detect: src => /Business &(amp;)? Accounting Notes/.test(src.html) && src.get('DATA') && src.get('DATA').g10,
  run(src, ctx) {
    const DATA = src.get('DATA');
    const lessons = [];
    const allClasses = new Set();
    for (const gk of Object.keys(DATA)) {
      const grade = +gk.slice(1);
      for (const c of DATA[gk]) {
        const key = `business-accounting-g${grade}-c${String(c.num).padStart(2, '0')}`;
        const { doc, root, html } = U.frag(U.sectionsFromHeadings(c.html, 'h3'));
        U.commonClean(root, doc);
        let summary = '';
        const flashcards = [];
        root.querySelectorAll('div.def, div.think, div.exam, div.hook, div.check').forEach(d => {
          const k = KIND[[...d.classList].find(x => KIND[x])];
          let title = DEFAULT_TITLE[k];
          const p = d.querySelector(':scope > p'); const b = p && p.firstElementChild;
          if (b && b.tagName === 'B' && p.innerHTML.trim().startsWith('<b>')) {
            title = b.textContent.replace(/:\s*$/, '').trim() || title; b.remove();
            p.innerHTML = p.innerHTML.replace(/^\s+/, '');
          }
          if (k === 'def') {
            const tf = termFromDefinition(U.textOf(d.innerHTML));
            if (tf) flashcards.push({ front: U.esc(tf.term), back: U.esc(tf.def), origin: 'extracted' });
          }
          if (k === 'check') {
            // "(1) question (2) question" + <details> "(1) answer (2) answer" → Q&A flashcards
            const qp = d.querySelector(':scope > p'); const ans = d.querySelector('details');
            if (qp && ans) {
              const split = h => h.split(/\(\d+\)\s*/).slice(1).map(x => x.trim()).filter(Boolean);
              const qs = split(qp.innerHTML), as = split([...ans.children].filter(x => x.tagName !== 'SUMMARY').map(x => x.innerHTML).join(' '));
              if (qs.length && qs.length === as.length) qs.forEach((q, i) => flashcards.push({ front: q, back: as[i], origin: 'imported' }));
              else ctx.log('info', `Business G${grade} Ch${c.num}: a quick-check box could not be split into question/answer pairs`, key);
            }
          }
          U.toCallout(doc, d, k, title, d.innerHTML);
        });
        // "<li><strong>Term</strong> — explanation</li>" → extracted flashcards
        root.querySelectorAll('li').forEach(li => {
          const s = li.firstElementChild;
          if (!s || !/^(STRONG|B)$/.test(s.tagName) || !li.innerHTML.trim().startsWith('<' + s.tagName.toLowerCase())) return;
          const rest = li.innerHTML.slice(li.innerHTML.indexOf('</' + s.tagName.toLowerCase() + '>') + s.tagName.length + 3);
          const m = /^\s*[—–:-]\s*([\s\S]+)$/.exec(rest);
          if (!m) return;
          const back = m[1].trim(), front = s.innerHTML.trim();
          const len = U.textOf(back).length;
          if (len >= 15 && len <= 240 && U.textOf(front).length <= 60) flashcards.push({ front, back: back.charAt(0).toUpperCase() + back.slice(1), origin: 'extracted' });
        });
        root.querySelectorAll('details.ans').forEach(x => x.className = 'answer');
        // first, heading-less section is the chapter's hook line
        const first = root.querySelector(':scope > section');
        if (first && !first.querySelector(':scope > h2')) {
          summary = U.textOf(first.innerHTML);
          first.classList.add('note-intro');
        }
        const toc = U.sectionize(root, key);
        const noteHtml = html();
        U.classesIn(noteHtml, allClasses);
        lessons.push({
          key, subject: 'business-accounting', grade, number: c.num, unit: UNITS[grade](c.num), title: c.title,
          summary, notes: [{ kind: 'notes', title: 'Notes', html: noteHtml, toc, scope: 'src-bas' }],
          flashcards, questions: [], source: 'business-accounting'
        });
      }
    }
    return { lessons, css: { 'src-bas': U.scopeCss(src.css, 'src-bas', allClasses) } };
  }
};
