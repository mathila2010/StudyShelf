'use strict';
// Shared helpers for the content importer.
// The source "websites" are self-contained HTML pages. Each adapter loads one
// in jsdom (scripts enabled, so data objects such as CH / DATA / CHAPTERS are
// built exactly as the original page builds them), then converts the content
// into the platform's normalized lesson format.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { JSDOM, VirtualConsole } = require('jsdom');
const createDOMPurify = require('dompurify');
const postcss = require('postcss');
const acorn = require('acorn');

const purifyWindow = new JSDOM('').window;
const DOMPurify = createDOMPurify(purifyWindow);

/** Load a source page with its scripts executed in an isolated jsdom window. */
function loadSource(file) {
  const html = fs.readFileSync(file, 'utf8');
  const errors = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => errors.push(String(e.message || e).slice(0, 300)));
  const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    pretendToBeVisual: true,
    virtualConsole: vc,
    url: 'https://source.invalid/',
    beforeParse(w) {
      w.matchMedia = () => ({ matches: false, addEventListener() {}, addListener() {}, removeEventListener() {} });
      w.IntersectionObserver = class { observe() {} unobserve() {} disconnect() {} };
      w.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };
      w.scrollTo = () => {};
      w.HTMLElement.prototype.scrollIntoView = () => {};
      w.speechSynthesis = { speak() {}, cancel() {}, getVoices: () => [] };
    }
  });
  const w = dom.window;
  const get = name => { try { return w.eval(`typeof ${name}!=="undefined" ? ${name} : undefined`); } catch (e) { return undefined; } };
  // Pull the raw <script> and <style> text too; interactive packs and diagram CSS come from these.
  const scripts = [...w.document.querySelectorAll('script')].map(s => s.textContent);
  const css = [...w.document.querySelectorAll('style')].map(s => s.textContent).join('\n');
  return { html, window: w, document: w.document, get, scripts, css, errors, close: () => w.close() };
}

/** Parse an HTML fragment into a detached container we can mutate. */
function frag(html) {
  const dom = new JSDOM(`<!doctype html><body><div id="root">${html}</div></body>`);
  const doc = dom.window.document;
  return { doc, root: doc.getElementById('root'), html: () => doc.getElementById('root').innerHTML };
}

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', '#39': "'" };
/** Plain text of an HTML string (cheap: no DOM). SVG/script/style content is dropped. */
function textOf(html) {
  return String(html == null ? '' : html)
    .replace(/<(svg|script|style)\b[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<\/(p|div|li|h\d|section|tr|td|th|dt|dd|figcaption|br)>/gi, ' ')
    .replace(/<[^>]+>/g, '')
    .replace(/&(#\d+|#x[0-9a-f]+|\w+);/gi, (m, e) => e[0] === '#' ? String.fromCodePoint(e[1] === 'x' ? parseInt(e.slice(2), 16) : +e.slice(1)) : (ENT[e] ?? m))
    .replace(/\s+/g, ' ').trim();
}

function unwrap(el) { const p = el.parentNode; while (el.firstChild) p.insertBefore(el.firstChild, el); p.removeChild(el); }

function slug(s) {
  return String(s).toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').slice(0, 60) || 'x';
}

const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/** Unified callout markup used by every subject. */
function callout(kind, title, bodyHtml) {
  return `<aside class="callout callout-${kind}"><p class="callout-title">${esc(title)}</p><div class="callout-body">${bodyHtml}</div></aside>`;
}

/** Replace an element with a unified callout. */
function toCallout(doc, el, kind, title, bodyHtml) {
  const t = doc.createElement('template');
  t.innerHTML = callout(kind, title, bodyHtml);
  el.replaceWith(t.content.firstElementChild);
}

/** Common clean-up applied to every note body. */
function commonClean(root, doc) {
  // UI chrome from the original pages
  root.querySelectorAll('button.fig-zoom, span.fig-hint, .sentinel, .clear, script, style, noscript').forEach(n => n.remove());
  // lightbox buttons around images → keep the image only
  root.querySelectorAll('button[data-lb]').forEach(b => unwrap(b));
  // tables: drop source wrappers and use one wrapper class
  root.querySelectorAll('div.tw, div.tbl').forEach(d => { if (d.querySelector('table')) unwrap(d); });
  root.querySelectorAll('table').forEach(t => {
    if (t.parentElement && t.parentElement.classList.contains('table-wrap')) return;
    const w = doc.createElement('div'); w.className = 'table-wrap'; t.replaceWith(w); w.appendChild(t);
  });
  // in-page jump links from the old sites point nowhere now
  root.querySelectorAll('[data-jump]').forEach(n => n.removeAttribute('data-jump'));
  // images: lazy-load
  root.querySelectorAll('img').forEach(i => { i.setAttribute('loading', 'lazy'); i.setAttribute('decoding', 'async'); });
}

/** Give each top-level <section> an id and make sure it starts with an <h2>. Returns the TOC. */
function sectionize(root, prefix) {
  const toc = [];
  let i = 0;
  root.querySelectorAll(':scope > section').forEach(sec => {
    i++;
    const h = sec.querySelector(':scope > h2, :scope > h3, :scope > h1');
    if (h && h.tagName !== 'H2') { const h2 = sec.ownerDocument.createElement('h2'); h2.innerHTML = h.innerHTML; h.replaceWith(h2); }
    const head = sec.querySelector(':scope > h2');
    const id = `${prefix}-s${i}`;
    sec.id = id; sec.className = 'note-sec';
    if (head) toc.push({ id, title: head.textContent.replace(/\s+/g, ' ').trim() });
  });
  return toc;
}

/** Split loose HTML into <section>s at each heading of the given tag. */
function sectionsFromHeadings(html, tag = 'h3') {
  const { root, doc } = frag(html);
  const out = doc.createElement('div');
  let cur = doc.createElement('section');
  for (const node of [...root.childNodes]) {
    if (node.nodeType === 1 && node.tagName.toLowerCase() === tag) {
      if (cur.childNodes.length) out.appendChild(cur);
      cur = doc.createElement('section');
      const h2 = doc.createElement('h2'); h2.innerHTML = node.innerHTML; cur.appendChild(h2);
    } else cur.appendChild(node);
  }
  if (cur.childNodes.length) out.appendChild(cur);
  return out.innerHTML;
}

/** Strip anything executable. SVG, MathML-free. data-* and class attributes are kept. */
function sanitize(html) { return sanitizeReport(html).html; }
/** Like sanitize(), also reporting how many elements/attributes were removed. */
function sanitizeReport(html) {
  const out = DOMPurify.sanitize(html, {
    USE_PROFILES: { html: true, svg: true, svgFilters: true },
    ADD_TAGS: ['details', 'summary', 'figure', 'figcaption', 'mark', 'output'],
    ADD_ATTR: ['loading', 'decoding', 'open', 'aria-label', 'aria-hidden', 'role', 'focusable', 'viewBox', 'marker-end', 'marker-start', 'text-anchor', 'dominant-baseline'],
    FORBID_TAGS: ['script', 'iframe', 'object', 'embed', 'form', 'input', 'style'],
    FORBID_ATTR: ['onerror', 'onload', 'onclick']
  });
  return { html: out, removed: DOMPurify.removed.filter(r => !(r.element && r.element.nodeName === '#comment')).length };
}

/** Media store: data: URIs become files under data/media/<group>/. */
class MediaStore {
  constructor(dir, urlBase) { this.dir = dir; this.urlBase = urlBase; this.files = new Map(); this.byHash = new Map(); }
  saveDataUri(uri, group, nameHint) {
    const m = /^data:(image\/[a-z+]+);base64,(.+)$/s.exec(uri);
    if (!m) return null;
    const ext = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/svg+xml': 'svg' }[m[1]] || 'bin';
    const buf = Buffer.from(m[2], 'base64');
    const hash = crypto.createHash('sha1').update(buf).digest('hex').slice(0, 10);
    if (this.byHash.has(hash)) return this.byHash.get(hash); // same picture used twice → one file
    const name = `${slug(nameHint || 'img')}-${hash}.${ext}`;
    const dir = path.join(this.dir, group);
    fs.mkdirSync(dir, { recursive: true });
    const fp = path.join(dir, name);
    if (!fs.existsSync(fp)) fs.writeFileSync(fp, buf);
    const url = `${this.urlBase}/${group}/${name}`;
    this.files.set(url, { path: fp, bytes: buf.length, type: m[1] });
    this.byHash.set(hash, url);
    return url;
  }
  rewriteImages(root, group) {
    root.querySelectorAll('img[src^="data:"]').forEach(img => {
      const url = this.saveDataUri(img.getAttribute('src'), group, img.getAttribute('alt') || 'image');
      if (url) img.setAttribute('src', url);
    });
  }
}

/**
 * Scope a source page's stylesheet so it only affects that source's content.
 * - :root / html / body selectors become the scope class
 * - :root[data-theme="dark"] X becomes [data-theme="dark"] .scope X
 * - prefers-color-scheme blocks are dropped (the platform always sets data-theme)
 * - rules are kept only if they mention a class from `keepClasses` or an SVG element
 */
function scopeCss(css, scope, keepClasses) {
  const SVG_TAGS = /(^|[\s>+~(,])(svg|text|tspan|path|rect|line|polyline|polygon|circle|ellipse|marker|g|figure|figcaption|mark|output|input\[type=range\])\b/;
  const root = postcss.parse(css);
  root.walkAtRules(at => {
    if (at.name === 'media' && /prefers-color-scheme/.test(at.params)) at.remove();
    else if (at.name === 'import' || at.name === 'font-face' || at.name === 'page') at.remove();
    else if (at.name === 'media' && /print/.test(at.params)) at.remove();
  });
  root.walkRules(rule => {
    if (rule.parent && rule.parent.type === 'atrule' && /keyframes/.test(rule.parent.name)) return;
    const out = [];
    for (let sel of rule.selectors) {
      sel = sel.trim();
      const isVarRoot = /^(:root|html|body)(\[data-theme=["']?(dark|light)["']?\])?$/.test(sel);
      if (isVarRoot) {
        // keep only custom property declarations from root-level rules
        const dark = /dark/.test(sel);
        out.push(dark ? `:root[data-theme="dark"] .${scope}` : `.${scope}`);
        continue;
      }
      let dark = false;
      let s = sel.replace(/^:root\[data-theme=["']?dark["']?\]\s*/, () => { dark = true; return ''; })
                 .replace(/^:root\[data-theme=["']?light["']?\]\s*/, '')
                 .replace(/^(:root|html|body)\s+/, '');
      if (/^(html|body|:root)\b/.test(s)) continue;
      const classes = (s.match(/\.([\w-]+)/g) || []).map(c => c.slice(1));
      const keep = classes.some(c => keepClasses.has(c)) || (!classes.length && (SVG_TAGS.test(' ' + s) || /^\[data-[\w-]+(=[^\]]+)?\]$/.test(s)));
      if (!keep) continue;
      out.push(`${dark ? ':root[data-theme="dark"] ' : ''}.${scope} ${s}`);
    }
    if (!out.length) { rule.remove(); return; }
    rule.selectors = out;
    if (out.every(s => /^(:root\[data-theme="dark"\] )?\.[\w-]+$/.test(s))) {
      // root-level rule: only custom properties are safe to carry over
      rule.walkDecls(d => { if (!d.prop.startsWith('--')) d.remove(); });
      if (!rule.nodes.length) rule.remove();
    }
  });
  root.walkAtRules(at => { if ((at.name === 'media' || at.name === 'supports') && !at.nodes.length) at.remove(); });
  return root.toString().replace(/\n{3,}/g, '\n\n');
}

/** Every class name used anywhere in an HTML string. */
function classesIn(html, set = new Set()) {
  for (const m of html.matchAll(/class=["']([^"']+)["']/g)) m[1].split(/\s+/).forEach(c => c && set.add(c));
  return set;
}
/** Class-like tokens that appear in JS source (used for runtime-generated widget markup). */
function classTokensInJs(js, set = new Set()) {
  for (const m of js.matchAll(/class(?:Name)?\s*=\s*\\?["'`]([^"'`$]+)/g)) m[1].split(/\s+/).forEach(c => /^[a-z][\w-]*$/i.test(c) && set.add(c));
  for (const m of js.matchAll(/classList\.(?:add|toggle|remove)\(\s*["']([\w-]+)/g)) set.add(m[1]);
  for (const m of js.matchAll(/class=\\?"([^"\\$]+)/g)) m[1].split(/\s+/).forEach(c => /^[a-z][\w-]*$/i.test(c) && set.add(c));
  return set;
}

/** Top-level statements of a script, with source ranges (for slicing out self-contained code). */
function topLevel(js) {
  const ast = acorn.parse(js, { ecmaVersion: 'latest', sourceType: 'script', allowReturnOutsideFunction: true });
  return ast.body.map(n => ({ type: n.type, start: n.start, end: n.end, names: declNames(n), code: js.slice(n.start, n.end) }));
}
function declNames(n) {
  if (n.type === 'FunctionDeclaration') return [n.id.name];
  if (n.type === 'VariableDeclaration') return n.declarations.map(d => d.id && d.id.name).filter(Boolean);
  if (n.type === 'ClassDeclaration') return [n.id.name];
  return [];
}

module.exports = { loadSource, frag, textOf, unwrap, slug, esc, callout, toCallout, commonClean, sectionize, sectionsFromHeadings, sanitize, sanitizeReport, MediaStore, scopeCss, classesIn, classTokensInJs, topLevel };
