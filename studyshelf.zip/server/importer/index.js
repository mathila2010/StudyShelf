'use strict';
// Content importer: reads every source page in a folder, runs the matching
// adapter, merges duplicates, sanitizes HTML, generates practice questions,
// and returns one normalized content package. applyPackage() (in ../content.js)
// writes it to the database.
const fs = require('fs');
const path = require('path');
const U = require('./util');
const ict = require('./adapters/ict');
const science = require('./adapters/science');
const business = require('./adapters/business');
const history = require('./adapters/history');

const ADAPTERS = [ict, science.descriptive, science.pocket, business, history];

const SUBJECTS = [
  { slug: 'science', name: 'Science', icon: 'flask', color: '#0f8b6c', description: 'Biology, Chemistry and Physics from the Grade 10 and 11 Science textbooks, in short and detailed notes.' },
  { slug: 'ict', name: 'ICT', icon: 'chip', color: '#2f5bd3', description: 'Information and Communication Technology: computer systems, office tools, databases, programming and the web.' },
  { slug: 'business-accounting', name: 'Business & Accounting', icon: 'ledger', color: '#b4521c', description: 'Business Studies and Accounting from the NIE textbooks, with worked examples and exam alerts.' },
  { slug: 'history', name: 'History', icon: 'column', color: '#8a3f8f', description: 'Sri Lankan and world history for the O/L, with photos, timelines and activities.' }
];
const NOTE_ORDER = { short: 0, notes: 1, detailed: 2 };

const norm = s => U.textOf(String(s)).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

function mergeLesson(a, b, log) {
  const out = { ...a };
  // the long-form source wins for the lesson title and summary
  const bDetailed = b.notes.some(n => n.kind === 'detailed');
  if (bDetailed) { out.title = b.title; out.summary = b.summary || a.summary; }
  else out.summary = a.summary || b.summary;
  out.hook = a.hook || b.hook;
  out.notes = [...a.notes, ...b.notes].sort((x, y) => NOTE_ORDER[x.kind] - NOTE_ORDER[y.kind]);
  const seenF = new Set(a.flashcards.map(f => norm(f.front)));
  let dupF = 0;
  out.flashcards = [...a.flashcards];
  for (const f of b.flashcards) { const k = norm(f.front); if (seenF.has(k)) { dupF++; continue; } seenF.add(k); out.flashcards.push(f); }
  const seenQ = new Set(a.questions.map(q => norm(q.prompt)));
  out.questions = [...a.questions, ...b.questions.filter(q => !seenQ.has(norm(q.prompt)))];
  out.interactives = [...(a.interactives || []), ...(b.interactives || [])];
  out.events = [...(a.events || []), ...(b.events || [])];
  out.sources = [...new Set([...(a.sources || [a.source]), b.source])];
  if (a.title !== b.title) out.altTitles = [...new Set([...(a.altTitles || []), a.title, b.title].filter(t => t !== out.title))];
  log('duplicate', `Merged "${out.title}" (${a.source} + ${b.source})${a.title !== b.title ? ` — titles differed: "${a.title}" / "${b.title}"` : ''}${dupF ? `; ${dupF} duplicate flashcard(s) skipped` : ''}`, out.key);
  return out;
}

function shuffle(arr, seed) {
  // deterministic so re-imports don't churn generated questions
  let s = seed >>> 0 || 1; const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) { s = (s * 1664525 + 1013904223) >>> 0; const j = s % (i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
const hash = s => [...s].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7);

// Hide the term inside its own definition so the answer is not given away.
function maskTerm(back, front) {
  const term = U.textOf(front).replace(/\(.*?\)/g, '').trim();
  if (term.length < 3 || term.split(' ').length > 6) return back;
  const re = new RegExp('\\b' + term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/s$/i, '') + '(s|es)?\\b', 'gi');
  return back.replace(/>([^<]+)</g, (m, t) => '>' + t.replace(re, '_____') + '<').replace(/^([^<]+)/, t => t.replace(re, '_____'));
}

/** Auto-generated practice questions, always flagged origin:'generated'. */
function generateQuestions(lesson, pool) {
  const cards = lesson.flashcards.filter(f => U.textOf(f.back).length >= 3 && U.textOf(f.back).length <= 260);
  const gen = [];
  if (cards.length >= 2) {
    const picks = shuffle(cards.map((_, i) => i), hash(lesson.key)).slice(0, Math.min(4, cards.length));
    picks.forEach((i, n) => {
      const c = cards[i];
      const truthy = n % 2 === 0;
      const other = cards[(i + 1 + (hash(c.front) % (cards.length - 1))) % cards.length];
      const back = maskTerm(truthy || other === c ? c.back : other.back, other === c ? c.front : (truthy ? c.front : other.front));
      const isTrue = truthy || other === c || norm(other.back) === norm(c.back);
      gen.push({
        type: 'tf', origin: 'generated',
        prompt: `<b>${c.front}</b> — ${back}`,
        options: ['True', 'False'], answer: isTrue ? 0 : 1,
        explanation: isTrue ? 'This matches the notes.' : `False. In the notes, <b>${c.front}</b> is: ${c.back}`
      });
    });
  }
  const existingMcq = lesson.questions.filter(q => q.type === 'mcq').length;
  if (existingMcq < 4) {
    const distractPool = pool.filter(f => U.textOf(f.back).length <= 260);
    shuffle(cards, hash(lesson.key + 'm')).slice(0, 4 - Math.min(existingMcq, 3)).forEach(c => {
      const wrong = shuffle(distractPool.filter(f => norm(f.back) !== norm(c.back) && norm(f.front) !== norm(c.front)), hash(c.front)).slice(0, 3);
      if (wrong.length < 3) return;
      const right = maskTerm(c.back, c.front);
      const opts = shuffle([right, ...wrong.map(w => maskTerm(w.back, w.front))], hash(c.back));
      gen.push({
        type: 'mcq', origin: 'generated',
        prompt: `Which of these best matches <b>${c.front}</b>?`,
        options: opts, answer: opts.indexOf(right), explanation: `<b>${c.front}</b>: ${c.back}`
      });
    });
  }
  return gen;
}

/**
 * @param {string} sourcesDir folder with the source .html files
 * @param {{mediaDir:string, mediaUrl?:string}} opts
 */
function runImport(sourcesDir, opts) {
  const started = Date.now();
  const logs = [];
  const log = (level, message, ref) => logs.push({ level, message, ref: ref || null, source: currentSource });
  let currentSource = null;
  const media = new U.MediaStore(opts.mediaDir, opts.mediaUrl || '/media');
  const lessons = new Map();
  const css = {}; const packs = {}; const sources = [];

  const files = fs.readdirSync(sourcesDir).filter(f => /\.html?$/i.test(f)).sort();
  if (!files.length) log('error', `No .html source files found in ${sourcesDir}`);
  for (const file of files) {
    currentSource = file;
    let src;
    try { src = U.loadSource(path.join(sourcesDir, file)); }
    catch (e) { log('error', `Could not open ${file}: ${e.message}`); continue; }
    try {
      const adapter = ADAPTERS.find(a => { try { return a.detect(src); } catch (e) { return false; } });
      if (!adapter) { log('error', `${file}: unrecognised page format — no importer adapter matches. Add an adapter in server/importer/adapters/.`); sources.push({ file, adapter: null, lessons: 0 }); continue; }
      src.errors.forEach(e => log('warn', `${file}: page script error while loading (content may still be complete): ${e}`));
      const res = adapter.run(src, { log, media });
      Object.assign(css, res.css || {}); Object.assign(packs, res.packs || {});
      for (const l of res.lessons) {
        l.sources = [l.source];
        if (lessons.has(l.key)) lessons.set(l.key, mergeLesson(lessons.get(l.key), l, log));
        else lessons.set(l.key, l);
      }
      sources.push({ file, adapter: adapter.id, lessons: res.lessons.length });
      log('info', `${file}: ${res.lessons.length} chapter(s) read with the "${adapter.id}" adapter`);
    } catch (e) {
      log('error', `${file}: import failed — ${e.message}`);
      sources.push({ file, adapter: 'failed', lessons: 0 });
    } finally { src.close(); }
  }
  currentSource = null;

  // sanitize, derive search text, generate questions
  const all = [...lessons.values()];
  const poolBy = {};
  all.forEach(l => { const k = l.subject + l.grade; (poolBy[k] = poolBy[k] || []).push(...l.flashcards); });
  for (const l of all) {
    for (const n of l.notes) {
      const before = n.html.length;
      n.html = U.sanitize(n.html);
      if (n.html.length < before * 0.8) log('warn', `Sanitizer removed a large part of "${l.title}" (${n.kind})`, l.key);
      n.text = U.textOf(n.html);
      if (n.text.length < 200) log('warn', `"${l.title}" ${n.kind} notes look very short (${n.text.length} chars)`, l.key);
    }
    l.flashcards = l.flashcards.map(f => ({ ...f, front: U.sanitize(f.front), back: U.sanitize(f.back) }));
    l.questions = l.questions.filter(q => {
      const ok = q.prompt && Array.isArray(q.options) && q.options.length >= 2 && q.answer >= 0 && q.answer < q.options.length;
      if (!ok) log('warn', `Dropped malformed question in "${l.title}": ${U.textOf(q.prompt || '').slice(0, 80)}`, l.key);
      return ok;
    }).map(q => ({ ...q, prompt: U.sanitize(q.prompt), options: q.options.map(o => U.sanitize(String(o))), explanation: U.sanitize(q.explanation || '') }));
    const gen = generateQuestions(l, poolBy[l.subject + l.grade] || []);
    l.questions.push(...gen.map(q => ({ ...q, prompt: U.sanitize(q.prompt), options: q.options.map(o => U.sanitize(o)), explanation: U.sanitize(q.explanation) })));
    l.guest = l.number === 1; // first chapter of each subject & grade is open to guests
    if (!l.flashcards.length) log('info', `"${l.title}" has no flashcards in its source`, l.key);
  }

  // check for interactive placeholders without code
  for (const l of all) for (const ix of l.interactives || []) {
    if (!packs[ix.pack]) log('warn', `Activity "${ix.name}" in "${l.title}" has no code pack (${ix.pack})`, l.key);
  }

  all.sort((a, b) => a.subject.localeCompare(b.subject) || a.grade - b.grade || a.number - b.number);
  const usedSubjects = new Set(all.map(l => l.subject));
  return {
    version: 1, createdAt: new Date().toISOString(), ms: Date.now() - started,
    subjects: SUBJECTS.filter(s => usedSubjects.has(s.slug)),
    lessons: all, css, packs, sources, logs,
    media: [...media.files.entries()].map(([url, f]) => ({ url, bytes: f.bytes, type: f.type }))
  };
}

module.exports = { runImport, SUBJECTS };

if (require.main === module) {
  const dir = process.argv[2] || path.join(__dirname, '../../sources');
  const pkg = runImport(dir, { mediaDir: path.join(__dirname, '../../data/media') });
  const out = process.argv[3];
  if (out) fs.writeFileSync(out, JSON.stringify(pkg));
  console.log(`${pkg.lessons.length} lessons, ${pkg.media.length} media, ${pkg.logs.length} log lines in ${pkg.ms} ms`);
}
