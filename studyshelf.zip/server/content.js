'use strict';
// Content storage: applying an import package, search index, catalog queries.
const fs = require('fs');
const path = require('path');
const { db, now } = require('./db');
const config = require('./config');
const U = require('./importer/util');

let catalogCache = null;
const invalidate = () => { catalogCache = null; };

const J = (s, d) => { try { return JSON.parse(s); } catch (e) { return d; } };

function ensureUnit(subjectId, grade, title) {
  if (!title) return null;
  const row = db.prepare('SELECT id FROM units WHERE subject_id=? AND grade=? AND title=?').get(subjectId, grade, title);
  if (row) return row.id;
  const pos = db.prepare('SELECT COALESCE(MAX(position),0)+1 p FROM units WHERE subject_id=? AND grade=?').get(subjectId, grade).p;
  return db.prepare('INSERT INTO units(subject_id,grade,title,position) VALUES(?,?,?,?)').run(subjectId, grade, title, pos).lastInsertRowid;
}

/** Write a content package to the DB. Lessons an admin has edited (locked) are left alone. */
function applyPackage(pkg, runId) {
  const logs = [];
  const log = (level, message, ref, source) => logs.push({ level, message, ref: ref || null, source: source || null });
  const t = now();
  const stats = { created: 0, updated: 0, skipped: 0 };

  db.transaction(() => {
    pkg.subjects.forEach((s, i) => {
      db.prepare(`INSERT INTO subjects(slug,name,icon,color,description,position) VALUES(@slug,@name,@icon,@color,@description,@position)
        ON CONFLICT(slug) DO NOTHING`).run({ ...s, position: i + 1 });
    });
    const subjectId = slug => db.prepare('SELECT id FROM subjects WHERE slug=?').get(slug).id;

    for (const l of pkg.lessons) {
      const sid = subjectId(l.subject);
      const existing = db.prepare('SELECT id, locked FROM lessons WHERE key=?').get(l.key);
      if (existing && existing.locked) { stats.skipped++; log('info', `Kept admin-edited version of "${l.title}" (not overwritten)`, l.key); continue; }
      const unitId = ensureUnit(sid, l.grade, l.unit);
      const row = {
        key: l.key, subject_id: sid, unit_id: unitId, grade: l.grade, number: l.number, title: l.title,
        summary: l.summary || '', hook: l.hook || '', era: l.era || null,
        image: l.image && l.image.url ? JSON.stringify(l.image) : null,
        sources: JSON.stringify(l.sources || [l.source]), alt_titles: JSON.stringify(l.altTitles || []), t
      };
      let id;
      if (existing) {
        id = existing.id;
        db.prepare(`UPDATE lessons SET subject_id=@subject_id, unit_id=@unit_id, grade=@grade, number=@number, title=@title, summary=@summary,
          hook=@hook, era=@era, image=@image, sources=@sources, alt_titles=@alt_titles, updated_at=@t WHERE id=@id`).run({ ...row, id });
        db.prepare('DELETE FROM notes WHERE lesson_id=?').run(id);
        db.prepare("DELETE FROM flashcards WHERE lesson_id=? AND origin<>'manual'").run(id);
        db.prepare("DELETE FROM questions WHERE lesson_id=? AND origin<>'manual' AND reviewed=0").run(id);
        db.prepare('DELETE FROM events WHERE lesson_id=?').run(id);
        stats.updated++;
      } else {
        id = db.prepare(`INSERT INTO lessons(key,subject_id,unit_id,grade,number,title,summary,hook,era,image,guest,sources,alt_titles,created_at,updated_at)
          VALUES(@key,@subject_id,@unit_id,@grade,@number,@title,@summary,@hook,@era,@image,@guest,@sources,@alt_titles,@t,@t)`).run({ ...row, guest: l.guest ? 1 : 0 }).lastInsertRowid;
        stats.created++;
      }
      l.notes.forEach((n, i) => db.prepare('INSERT INTO notes(lesson_id,kind,title,html,text,toc,scope,position,updated_at) VALUES(?,?,?,?,?,?,?,?,?)')
        .run(id, n.kind, n.title, n.html, n.text || U.textOf(n.html), JSON.stringify(n.toc || []), n.scope || null, i, t));
      l.flashcards.forEach((f, i) => db.prepare('INSERT INTO flashcards(lesson_id,front,back,origin,position) VALUES(?,?,?,?,?)').run(id, f.front, f.back, f.origin, i));
      const keptPrompts = new Set(db.prepare('SELECT prompt FROM questions WHERE lesson_id=?').all(id).map(r => r.prompt));
      l.questions.filter(q => !keptPrompts.has(q.prompt)).forEach((q, i) => db.prepare('INSERT INTO questions(lesson_id,type,prompt,options,answer,explanation,origin,position) VALUES(?,?,?,?,?,?,?,?)')
        .run(id, q.type, q.prompt, JSON.stringify(q.options), q.answer, q.explanation || '', q.origin, i));
      (l.events || []).forEach(e => db.prepare('INSERT INTO events(lesson_id,label,year,title,detail) VALUES(?,?,?,?,?)').run(id, e.label, e.year, e.title, e.detail));
      indexLesson(id);
    }
    db.prepare("DELETE FROM media WHERE origin='import'").run();
    for (const m of pkg.media || []) {
      db.prepare(`INSERT INTO media(url,name,type,bytes,origin,created_at) VALUES(?,?,?,?, 'import', ?) ON CONFLICT(url) DO NOTHING`)
        .run(m.url, path.basename(m.url), m.type, m.bytes, t);
    }
    const inDb = db.prepare("SELECT key,title FROM lessons WHERE locked=0").all();
    const inPkg = new Set(pkg.lessons.map(l => l.key));
    inDb.filter(r => !inPkg.has(r.key) && /^(science|ict|history|business-accounting)-g/.test(r.key))
      .forEach(r => log('warn', `"${r.title}" is in the library but no longer found in the sources (kept as is)`, r.key));
  })();

  // generated assets: scoped diagram CSS + interactive activity code
  fs.mkdirSync(config.generatedDir, { recursive: true });
  const cssAll = Object.entries(pkg.css || {}).map(([k, v]) => `/* ${k} */\n${v}`).join('\n');
  fs.writeFileSync(path.join(config.generatedDir, 'sources.css'), cssAll);
  for (const [name, js] of Object.entries(pkg.packs || {})) fs.writeFileSync(path.join(config.generatedDir, `ix-${name}.js`), js);
  invalidate();
  return { stats, logs };
}

/** (Re)build the full-text index row for one lesson. */
function indexLesson(id) {
  const l = db.prepare(`SELECT l.id,l.title,l.summary,l.hook,l.alt_titles,u.title unit,s.name subject FROM lessons l
    JOIN subjects s ON s.id=l.subject_id LEFT JOIN units u ON u.id=l.unit_id WHERE l.id=?`).get(id);
  db.prepare('DELETE FROM lesson_fts WHERE rowid=?').run(id);
  if (!l) return;
  const body = db.prepare('SELECT text FROM notes WHERE lesson_id=? ORDER BY position').all(id).map(r => r.text).join('\n');
  const terms = db.prepare('SELECT front, back FROM flashcards WHERE lesson_id=?').all(id).map(r => U.textOf(r.front) + ' ' + U.textOf(r.back)).join('\n');
  db.prepare('INSERT INTO lesson_fts(rowid,title,summary,body,terms,unit,subject) VALUES(?,?,?,?,?,?,?)')
    .run(id, l.title + ' ' + J(l.alt_titles, []).join(' '), (l.summary || '') + ' ' + (l.hook || ''), body, terms, l.unit || '', l.subject);
}
function reindexAll() { db.prepare('SELECT id FROM lessons').all().forEach(r => indexLesson(r.id)); }

/** Everything the library pages need, without note bodies. Cached until content changes. */
function catalog() {
  if (catalogCache) return catalogCache;
  const subjects = db.prepare('SELECT * FROM subjects WHERE published=1 ORDER BY position, name').all();
  const units = db.prepare('SELECT * FROM units ORDER BY grade, position').all();
  const lessons = db.prepare(`SELECT l.id,l.key,l.subject_id,l.unit_id,l.grade,l.number,l.title,l.summary,l.hook,l.era,l.image,l.difficulty,l.guest,l.created_at,l.updated_at,
      (SELECT group_concat(kind) FROM (SELECT kind FROM notes n WHERE n.lesson_id=l.id ORDER BY position)) kinds,
      (SELECT COUNT(*) FROM flashcards f WHERE f.lesson_id=l.id) cards,
      (SELECT COUNT(*) FROM questions q WHERE q.lesson_id=l.id) questions,
      (SELECT COUNT(*) FROM notes n WHERE n.lesson_id=l.id AND n.html LIKE '%class="sh-ix"%') activities,
      (SELECT COUNT(*) FROM notes n WHERE n.lesson_id=l.id AND (n.html LIKE '%<svg%' OR n.html LIKE '%<img%')) illustrated
    FROM lessons l JOIN subjects s ON s.id=l.subject_id WHERE l.published=1 AND s.published=1 ORDER BY l.grade, l.number`).all();
  catalogCache = {
    subjects: subjects.map(s => ({ id: s.id, slug: s.slug, name: s.name, icon: s.icon, color: s.color, description: s.description })),
    units: units.map(u => ({ id: u.id, subjectId: u.subject_id, grade: u.grade, title: u.title, position: u.position })),
    lessons: lessons.map(l => ({
      id: l.id, key: l.key, subjectId: l.subject_id, unitId: l.unit_id, grade: l.grade, number: l.number, title: l.title,
      summary: l.summary, hook: l.hook, era: l.era, image: J(l.image, null), difficulty: l.difficulty, guest: !!l.guest,
      kinds: (l.kinds || '').split(',').filter(Boolean), cards: l.cards, questions: l.questions, activities: l.activities > 0,
      illustrated: l.illustrated > 0, createdAt: l.created_at, updatedAt: l.updated_at
    }))
  };
  catalogCache.grades = [...new Set(catalogCache.lessons.map(l => l.grade))].sort();
  return catalogCache;
}

function lessonFull(key, { includeUnpublished = false } = {}) {
  const l = db.prepare(`SELECT l.*, s.slug subject_slug, s.name subject_name, s.color subject_color, u.title unit_title FROM lessons l
    JOIN subjects s ON s.id=l.subject_id LEFT JOIN units u ON u.id=l.unit_id WHERE l.key=?`).get(key);
  if (!l || (!includeUnpublished && !l.published)) return null;
  return {
    id: l.id, key: l.key, grade: l.grade, number: l.number, title: l.title, summary: l.summary, hook: l.hook, era: l.era,
    image: J(l.image, null), difficulty: l.difficulty, guest: !!l.guest, published: !!l.published, locked: !!l.locked,
    subject: { id: l.subject_id, slug: l.subject_slug, name: l.subject_name, color: l.subject_color },
    unit: l.unit_id ? { id: l.unit_id, title: l.unit_title } : null,
    sources: J(l.sources, []), altTitles: J(l.alt_titles, []), updatedAt: l.updated_at, createdAt: l.created_at,
    notes: db.prepare('SELECT id,kind,title,html,toc,scope FROM notes WHERE lesson_id=? ORDER BY position').all(l.id).map(n => ({ ...n, toc: J(n.toc, []) })),
    flashcards: db.prepare('SELECT id,front,back,origin,reviewed FROM flashcards WHERE lesson_id=? ORDER BY position, id').all(l.id),
    questions: db.prepare('SELECT id,type,prompt,options,answer,explanation,origin,reviewed FROM questions WHERE lesson_id=? ORDER BY position, id').all(l.id).map(q => ({ ...q, options: J(q.options, []) })),
    events: db.prepare('SELECT label,year,title,detail FROM events WHERE lesson_id=? ORDER BY year').all(l.id)
  };
}

module.exports = { applyPackage, indexLesson, reindexAll, catalog, lessonFull, invalidate, ensureUnit, J };
