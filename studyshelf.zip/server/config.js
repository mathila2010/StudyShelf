'use strict';
// All configuration comes from environment variables (see .env.example).
const path = require('path');
const fs = require('fs');

// Minimal .env loader (no dependency): KEY=VALUE lines, # comments.
const envFile = path.join(__dirname, '..', '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
}

const root = path.join(__dirname, '..');
const dataDir = path.resolve(root, process.env.DATA_DIR || 'data');
const production = process.env.NODE_ENV === 'production';

module.exports = {
  production,
  port: +(process.env.PORT || 3000),
  appUrl: (process.env.APP_URL || `http://localhost:${process.env.PORT || 3000}`).replace(/\/$/, ''),
  appName: process.env.APP_NAME || 'StudyShelf',
  dataDir,
  dbFile: path.join(dataDir, 'studyshelf.db'),
  mediaDir: path.join(dataDir, 'media'),
  generatedDir: path.join(dataDir, 'generated'),
  sourcesDir: path.resolve(root, process.env.SOURCES_DIR || 'sources'),
  publicDir: path.join(root, 'public'),
  sessionDays: +(process.env.SESSION_DAYS || 14),
  cookieSecure: process.env.COOKIE_SECURE ? process.env.COOKIE_SECURE === 'true' : production,
  trustProxy: process.env.TRUST_PROXY === 'true',
  smtp: process.env.SMTP_HOST ? {
    host: process.env.SMTP_HOST,
    port: +(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true',
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    from: process.env.MAIL_FROM || process.env.SMTP_USER
  } : null,
  adminEmail: process.env.ADMIN_EMAIL || '',
  adminPassword: process.env.ADMIN_PASSWORD || '',
  maxUploadMb: +(process.env.MAX_UPLOAD_MB || 15)
};
