'use strict';
// Authentication: scrypt password hashes, server-side sessions in SQLite,
// httpOnly cookies, role checks, simple per-IP rate limiting.
const crypto = require('crypto');
const { db, now } = require('./db');
const config = require('./config');

const COOKIE = 'ss_session';
const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 64 };

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(pw, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${key.toString('base64')}`;
}
function verifyPassword(pw, stored) {
  try {
    const [alg, N, r, p, salt, key] = stored.split('$');
    if (alg !== 'scrypt') return false;
    const expect = Buffer.from(key, 'base64');
    const got = crypto.scryptSync(pw, Buffer.from(salt, 'base64'), expect.length, { N: +N, r: +r, p: +p });
    return crypto.timingSafeEqual(expect, got);
  } catch (e) { return false; }
}
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');

function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < 8) return 'Use at least 8 characters for your password.';
  if (pw.length > 200) return 'That password is too long.';
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Use at least one letter and one number in your password.';
  return null;
}

function createSession(res, userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  const t = now();
  db.prepare('INSERT INTO sessions(id,user_id,created_at,expires_at) VALUES(?,?,?,?)').run(sha256(token), userId, t, t + config.sessionDays * 864e5);
  db.prepare('UPDATE users SET last_login_at=?, failed_logins=0, locked_until=NULL WHERE id=?').run(t, userId);
  res.cookie(COOKIE, token, { httpOnly: true, sameSite: 'lax', secure: config.cookieSecure, maxAge: config.sessionDays * 864e5, path: '/' });
}
function destroySession(req, res) {
  const token = req.cookies && req.cookies[COOKIE];
  if (token) db.prepare('DELETE FROM sessions WHERE id=?').run(sha256(token));
  res.clearCookie(COOKIE, { path: '/' });
}

/** Attach req.user when a valid session cookie is present. */
function loadUser(req, res, next) {
  const token = req.cookies && req.cookies[COOKIE];
  if (token) {
    const row = db.prepare(`SELECT u.id,u.name,u.email,u.role,u.grade,u.subjects,u.disabled,u.created_at,s.expires_at FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=?`).get(sha256(token));
    if (row && row.expires_at > now() && !row.disabled) {
      req.user = { id: row.id, name: row.name, email: row.email, role: row.role, grade: row.grade, subjects: JSON.parse(row.subjects || '[]'), createdAt: row.created_at };
    } else if (row) destroySession(req, res);
  }
  next();
}

class HttpError extends Error { constructor(status, message, extra) { super(message); this.status = status; this.extra = extra; } }
const requireUser = (req, res, next) => req.user ? next() : next(new HttpError(401, 'Please log in to continue.'));
const requireAdmin = (req, res, next) => !req.user ? next(new HttpError(401, 'Please log in to continue.')) : req.user.role === 'admin' ? next() : next(new HttpError(403, 'This area is for administrators only.'));

/** Mutating requests must carry a custom header (blocks cross-site form posts) — paired with SameSite cookies. */
function csrfGuard(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('X-Requested-With') !== 'StudyShelf') return next(new HttpError(403, 'Request blocked. Reload the page and try again.'));
  next();
}

/** Tiny fixed-window rate limiter (per process). */
function rateLimit({ windowMs, max, message }) {
  const hits = new Map();
  setInterval(() => { const t = now(); for (const [k, v] of hits) if (v.reset < t) hits.delete(k); }, windowMs).unref();
  return (req, res, next) => {
    const k = req.ip + ':' + req.path; const t = now();
    let h = hits.get(k); if (!h || h.reset < t) { h = { n: 0, reset: t + windowMs }; hits.set(k, h); }
    if (++h.n > max) { res.set('Retry-After', Math.ceil((h.reset - t) / 1000)); return next(new HttpError(429, message || 'Too many attempts. Wait a few minutes and try again.')); }
    next();
  };
}

function publicUser(u) { return u && { id: u.id, name: u.name, email: u.email, role: u.role, grade: u.grade, subjects: u.subjects, createdAt: u.createdAt }; }

module.exports = { COOKIE, hashPassword, verifyPassword, sha256, passwordProblem, createSession, destroySession, loadUser, requireUser, requireAdmin, csrfGuard, rateLimit, HttpError, publicUser };
