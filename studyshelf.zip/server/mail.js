'use strict';
// Outgoing email (password resets). Uses SMTP when configured; otherwise the
// message is written to the server log so a developer can follow the link.
const nodemailer = require('nodemailer');
const config = require('./config');

let transport = null;
if (config.smtp) transport = nodemailer.createTransport(config.smtp);

async function send({ to, subject, text }) {
  if (!transport) {
    console.log(`\n[mail:not-configured] To: ${to}\nSubject: ${subject}\n${text}\n`);
    return { delivered: false };
  }
  await transport.sendMail({ from: config.smtp.from, to, subject, text });
  return { delivered: true };
}

module.exports = { send, configured: () => !!transport };
