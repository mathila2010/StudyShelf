'use strict';
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const config = require('./config');

fs.mkdirSync(path.dirname(config.dbFile), { recursive: true });
const db = new Database(config.dbFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

const MIGRATIONS = [
  `
  CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student','admin')),
    grade INTEGER,
    subjects TEXT NOT NULL DEFAULT '[]',
    disabled INTEGER NOT NULL DEFAULT 0,
    failed_logins INTEGER NOT NULL DEFAULT 0,
    locked_until INTEGER,
    created_at INTEGER NOT NULL,
    last_login_at INTEGER
  );
  CREATE TABLE sessions (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
  );
  CREATE INDEX sessions_user ON sessions(user_id);
  CREATE TABLE password_resets (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL,
    used_at INTEGER
  );

  CREATE TABLE subjects (
    id INTEGER PRIMARY KEY,
    slug TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    icon TEXT NOT NULL DEFAULT 'book',
    color TEXT NOT NULL DEFAULT '#2f5bd3',
    description TEXT NOT NULL DEFAULT '',
    position INTEGER NOT NULL DEFAULT 0,
    published INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE units (
    id INTEGER PRIMARY KEY,
    subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    grade INTEGER NOT NULL,
    title TEXT NOT NULL,
    position INTEGER NOT NULL DEFAULT 0,
    UNIQUE (subject_id, grade, title)
  );
  CREATE TABLE lessons (
    id INTEGER PRIMARY KEY,
    key TEXT NOT NULL UNIQUE,
    subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    unit_id INTEGER REFERENCES units(id) ON DELETE SET NULL,
    grade INTEGER NOT NULL,
    number INTEGER NOT NULL DEFAULT 0,
    title TEXT NOT NULL,
    summary TEXT NOT NULL DEFAULT '',
    hook TEXT NOT NULL DEFAULT '',
    era TEXT,
    image TEXT,
    difficulty TEXT CHECK (difficulty IN ('foundation','core','extension') OR difficulty IS NULL),
    guest INTEGER NOT NULL DEFAULT 0,
    published INTEGER NOT NULL DEFAULT 1,
    locked INTEGER NOT NULL DEFAULT 0,
    sources TEXT NOT NULL DEFAULT '[]',
    alt_titles TEXT NOT NULL DEFAULT '[]',
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  );
  CREATE INDEX lessons_subject ON lessons(subject_id, grade, number);
  CREATE TABLE notes (
    id INTEGER PRIMARY KEY,
    lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    kind TEXT NOT NULL DEFAULT 'notes',
    title TEXT NOT NULL,
    html TEXT NOT NULL,
    text TEXT NOT NULL DEFAULT '',
    toc TEXT NOT NULL DEFAULT '[]',
    scope TEXT,
    position INTEGER NOT NULL DEFAULT 0,
    updated_at INTEGER NOT NULL
  );
  CREATE INDEX notes_lesson ON notes(lesson_id);
  CREATE TABLE flashcards (
    id INTEGER PRIMARY KEY,
    lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    front TEXT NOT NULL, back TEXT NOT NULL,
    origin TEXT NOT NULL DEFAULT 'manual',
    reviewed INTEGER NOT NULL DEFAULT 0,
    position INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX flash_lesson ON flashcards(lesson_id);
  CREATE TABLE questions (
    id INTEGER PRIMARY KEY,
    lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    type TEXT NOT NULL CHECK (type IN ('mcq','tf')),
    prompt TEXT NOT NULL,
    options TEXT NOT NULL,
    answer INTEGER NOT NULL,
    explanation TEXT NOT NULL DEFAULT '',
    origin TEXT NOT NULL DEFAULT 'manual',
    reviewed INTEGER NOT NULL DEFAULT 0,
    position INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX q_lesson ON questions(lesson_id);
  CREATE TABLE events (
    id INTEGER PRIMARY KEY,
    lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    label TEXT NOT NULL, year REAL, title TEXT NOT NULL, detail TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE bookmarks (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    kind TEXT NOT NULL CHECK (kind IN ('bookmark','favorite')),
    created_at INTEGER NOT NULL,
    PRIMARY KEY (user_id, lesson_id, kind)
  );
  CREATE TABLE progress (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    first_viewed_at INTEGER, last_viewed_at INTEGER,
    views INTEGER NOT NULL DEFAULT 0,
    last_tab TEXT,
    completed_at INTEGER,
    revise INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, lesson_id)
  );
  CREATE TABLE quiz_attempts (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    lesson_id INTEGER REFERENCES lessons(id) ON DELETE SET NULL,
    kind TEXT NOT NULL DEFAULT 'lesson',
    subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    score INTEGER NOT NULL, total INTEGER NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX qa_user ON quiz_attempts(user_id, created_at);

  CREATE TABLE media (
    id INTEGER PRIMARY KEY,
    url TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    bytes INTEGER NOT NULL,
    origin TEXT NOT NULL DEFAULT 'upload',
    uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE import_runs (
    id INTEGER PRIMARY KEY,
    started_at INTEGER NOT NULL, finished_at INTEGER,
    status TEXT NOT NULL DEFAULT 'running',
    summary TEXT NOT NULL DEFAULT '{}',
    triggered_by INTEGER REFERENCES users(id) ON DELETE SET NULL
  );
  CREATE TABLE import_logs (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES import_runs(id) ON DELETE CASCADE,
    level TEXT NOT NULL, source TEXT, message TEXT NOT NULL, ref TEXT,
    resolved INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE activity (
    day TEXT NOT NULL, kind TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (day, kind)
  );
  CREATE VIRTUAL TABLE lesson_fts USING fts5(
    title, summary, body, terms, unit, subject,
    tokenize = 'porter unicode61 remove_diacritics 2'
  );
  `
];

function migrate() {
  const v = db.pragma('user_version', { simple: true });
  for (let i = v; i < MIGRATIONS.length; i++) {
    db.transaction(() => { db.exec(MIGRATIONS[i]); db.pragma(`user_version = ${i + 1}`); })();
  }
}
migrate();

const now = () => Date.now();
function bump(kind) {
  const day = new Date().toISOString().slice(0, 10);
  db.prepare('INSERT INTO activity(day,kind,count) VALUES(?,?,1) ON CONFLICT(day,kind) DO UPDATE SET count=count+1').run(day, kind);
}

module.exports = { db, now, bump };
