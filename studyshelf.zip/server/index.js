'use strict';
const express = require('express');
const path = require('path');
const fs = require('fs');
const cookieParser = require('cookie-parser');
const config = require('./config');
const { db, now } = require('./db');
const A = require('./auth');
const api = require('./routes/api');
const admin = require('./routes/admin');

const app = express();
app.disable('x-powered-by');
if (config.trustProxy) app.set('trust proxy', 1);

// security headers
app.use((req, res, next) => {
  res.set({
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; media-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'",
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'same-origin',
    'X-Frame-Options': 'DENY',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()'
  });
  if (config.cookieSecure) res.set('Strict-Transport-Security', 'max-age=15552000');
  next();
});

app.use(express.json({ limit: '4mb' }));
app.use(cookieParser());
app.use(A.loadUser);

app.get('/healthz', (req, res) => res.json({ ok: true }));
app.use('/api', A.csrfGuard);
app.use('/api/admin', A.requireAdmin, admin.router);
app.use('/api', api.router);
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

const staticOpts = { maxAge: config.production ? '7d' : 0, fallthrough: true };
app.use('/media', express.static(config.mediaDir, { ...staticOpts, setHeaders: res => res.set('Content-Security-Policy', "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox") }));
app.use('/generated', express.static(config.generatedDir, { maxAge: 0 }));
app.use(express.static(config.publicDir, { maxAge: config.production ? '1h' : 0, index: false }));
const indexHtml = () => fs.readFileSync(path.join(config.publicDir, 'index.html'), 'utf8').replace(/__APP_NAME__/g, config.appName);
app.get(/^\/(?!api\/|media\/|generated\/).*/, (req, res) => res.type('html').set('Cache-Control', 'no-cache').send(indexHtml()));

// errors → JSON with a helpful message
app.use((err, req, res, next) => {
  if (err.type === 'entity.too.large') err = new A.HttpError(413, 'That is too large to save.');
  if (err.code === 'LIMIT_FILE_SIZE') err = new A.HttpError(413, `Files must be smaller than ${config.maxUploadMb} MB.`);
  if (err instanceof SyntaxError && err.body !== undefined) err = new A.HttpError(400, 'The request was not valid JSON.');
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 && config.production ? 'Something went wrong on the server. Try again in a moment.' : err.message, ...(err.extra || {}) });
});

/** First start: import the bundled sources and create the admin from env vars. */
async function bootstrap() {
  if (config.adminEmail && config.adminPassword) {
    const exists = db.prepare('SELECT id FROM users WHERE email=?').get(config.adminEmail.toLowerCase());
    if (!exists) {
      const prob = A.passwordProblem(config.adminPassword);
      if (prob) console.warn(`ADMIN_PASSWORD rejected: ${prob}`);
      else {
        db.prepare("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,'admin',?)").run('Administrator', config.adminEmail.toLowerCase(), A.hashPassword(config.adminPassword), now());
        console.log(`Created administrator ${config.adminEmail}`);
      }
    }
  }
  const lessons = db.prepare('SELECT COUNT(*) n FROM lessons').get().n;
  const generated = fs.existsSync(path.join(config.generatedDir, 'sources.css'));
  if (!lessons || !generated) {
    console.log('Importing notes from', config.sourcesDir, '…');
    const { summary } = await admin.doImport(null);
    console.log(`Imported ${summary.lessons} lessons (${summary.errors} errors, ${summary.warnings} warnings).`);
  }
  if (!db.prepare("SELECT 1 FROM users WHERE role='admin'").get()) console.warn('No administrator yet. Set ADMIN_EMAIL and ADMIN_PASSWORD, or run: npm run create-admin');
}

if (require.main === module) {
  bootstrap().then(() => app.listen(config.port, () => console.log(`${config.appName} running at ${config.appUrl}`)))
    .catch(e => { console.error(e); process.exit(1); });
}
module.exports = { app, bootstrap };
