'use strict';
// Public + student API.
const express = require('express');
const crypto = require('crypto');
const { db, now, bump } = require('../db');
const config = require('../config');
const A = require('../auth');
const C = require('../content');
const mail = require('../mail');

const r = express.Router();
const { HttpError } = A;

// ---------- validation helpers ----------
const str = (v, { min = 0, max = 200, name = 'value' } = {}) => {
  if (typeof v !== 'string') throw new HttpError(400, `Enter a ${name}.`);
  const s = v.trim();
  if (s.length < min) throw new HttpError(400, min > 1 ? `${name[0].toUpperCase() + name.slice(1)} must be at least ${min} characters.` : `Enter a ${name}.`);
  if (s.length > max) throw new HttpError(400, `${name[0].toUpperCase() + name.slice(1)} must be ${max} characters or fewer.`);
  return s;
};
const emailOf = v => {
  const e = str(v, { min: 3, max: 254, name: 'email address' }).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) throw new HttpError(400, 'Enter a valid email address, like name@example.com.');
  return e;
};
const gradeOf = v => {
  const grades = C.catalog().grades;
  const g = +v;
  if (!grades.includes(g)) throw new HttpError(400, `Choose your grade (${grades.join(' or ')}).`);
  return g;
};
const subjectsOf = v => {
  if (v == null) return [];
  if (!Array.isArray(v)) throw new HttpError(400, 'Subjects must be a list.');
  const valid = new Set(C.catalog().subjects.map(s => s.slug));
  return [...new Set(v.filter(s => valid.has(s)))];
};
const wrap = fn => (req, res, next) => { try { const out = fn(req, res, next); if (out && out.catch) out.catch(next); } catch (e) { next(e); } };

const authLimiter = A.rateLimit({ windowMs: 15 * 60e3, max: 20, message: 'Too many attempts from this device. Wait 15 minutes and try again.' });

// ---------- auth ----------
r.post('/auth/signup', authLimiter, wrap((req, res) => {
  const name = str(req.body.name, { min: 1, max: 60, name: 'name' });
  const email = emailOf(req.body.email);
  const pw = req.body.password; const prob = A.passwordProblem(pw); if (prob) throw new HttpError(400, prob);
  const grade = gradeOf(req.body.grade);
  const subjects = subjectsOf(req.body.subjects);
  if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email)) throw new HttpError(409, 'An account with this email already exists. Log in instead, or reset your password.');
  const id = db.prepare('INSERT INTO users(name,email,password_hash,grade,subjects,created_at) VALUES(?,?,?,?,?,?)')
    .run(name, email, A.hashPassword(pw), grade, JSON.stringify(subjects), now()).lastInsertRowid;
  A.createSession(res, id); bump('signup');
  res.status(201).json({ user: A.publicUser(userById(id)) });
}));

r.post('/auth/login', authLimiter, wrap((req, res) => {
  const email = emailOf(req.body.email);
  const pw = typeof req.body.password === 'string' ? req.body.password : '';
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  const fail = () => { throw new HttpError(401, 'That email and password don’t match. Check them and try again.'); };
  if (!u) { A.verifyPassword(pw, A.hashPassword('timing-equaliser')); fail(); }
  if (u.locked_until && u.locked_until > now()) throw new HttpError(429, 'This account is paused for 15 minutes after too many wrong passwords.');
  if (!A.verifyPassword(pw, u.password_hash)) {
    const n = u.failed_logins + 1;
    db.prepare('UPDATE users SET failed_logins=?, locked_until=? WHERE id=?').run(n, n >= 8 ? now() + 15 * 60e3 : null, u.id);
    fail();
  }
  if (u.disabled) throw new HttpError(403, 'This account has been turned off. Ask your teacher or the site administrator.');
  A.createSession(res, u.id); bump('login');
  res.json({ user: A.publicUser(userById(u.id)) });
}));

r.post('/auth/logout', (req, res) => { A.destroySession(req, res); res.json({ ok: true }); });
r.get('/auth/me', (req, res) => res.json({ user: A.publicUser(req.user) || null, mailConfigured: mail.configured() }));

r.post('/auth/forgot', authLimiter, wrap(async (req, res) => {
  const email = emailOf(req.body.email);
  const u = db.prepare('SELECT id,name,email,disabled FROM users WHERE email=?').get(email);
  if (u && !u.disabled) await sendReset(u);
  // same answer either way, so the form can't be used to find out who has an account
  res.json({ ok: true, message: 'If an account uses that email, we’ve sent a link to reset the password. It works for 1 hour.' });
}));

r.post('/auth/reset', authLimiter, wrap((req, res) => {
  const token = str(req.body.token, { min: 10, max: 200, name: 'reset link' });
  const pw = req.body.password; const prob = A.passwordProblem(pw); if (prob) throw new HttpError(400, prob);
  const row = db.prepare('SELECT * FROM password_resets WHERE token_hash=?').get(A.sha256(token));
  if (!row || row.used_at || row.expires_at < now()) throw new HttpError(400, 'This reset link has expired or was already used. Ask for a new one.');
  db.transaction(() => {
    db.prepare('UPDATE users SET password_hash=?, failed_logins=0, locked_until=NULL WHERE id=?').run(A.hashPassword(pw), row.user_id);
    db.prepare('UPDATE password_resets SET used_at=? WHERE token_hash=?').run(now(), row.token_hash);
    db.prepare('DELETE FROM sessions WHERE user_id=?').run(row.user_id);
  })();
  A.createSession(res, row.user_id);
  res.json({ user: A.publicUser(userById(row.user_id)) });
}));

async function sendReset(u) {
  const token = crypto.randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO password_resets(token_hash,user_id,expires_at) VALUES(?,?,?)').run(A.sha256(token), u.id, now() + 3600e3);
  const link = `${config.appUrl}/reset-password?token=${token}`;
  await mail.send({
    to: u.email, subject: `Reset your ${config.appName} password`,
    text: `Hi ${u.name},\n\nSomeone asked to reset the password for your ${config.appName} account. If it was you, open this link within 1 hour:\n\n${link}\n\nIf you didn't ask for this, you can ignore this email; your password stays the same.\n`
  });
  return link;
}

function userById(id) {
  const u = db.prepare('SELECT id,name,email,role,grade,subjects,created_at FROM users WHERE id=?').get(id);
  return u && { ...u, subjects: JSON.parse(u.subjects || '[]'), createdAt: u.created_at };
}

// ---------- profile ----------
r.patch('/me', A.requireUser, wrap((req, res) => {
  const b = req.body || {};
  const name = b.name !== undefined ? str(b.name, { min: 1, max: 60, name: 'name' }) : req.user.name;
  const grade = b.grade !== undefined ? gradeOf(b.grade) : req.user.grade;
  const subjects = b.subjects !== undefined ? subjectsOf(b.subjects) : req.user.subjects;
  db.prepare('UPDATE users SET name=?, grade=?, subjects=? WHERE id=?').run(name, grade, JSON.stringify(subjects), req.user.id);
  res.json({ user: A.publicUser(userById(req.user.id)) });
}));
r.post('/me/password', A.requireUser, authLimiter, wrap((req, res) => {
  const u = db.prepare('SELECT password_hash FROM users WHERE id=?').get(req.user.id);
  if (!A.verifyPassword(String(req.body.current || ''), u.password_hash)) throw new HttpError(400, 'Your current password is not right.');
  const prob = A.passwordProblem(req.body.password); if (prob) throw new HttpError(400, prob);
  db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(A.hashPassword(req.body.password), req.user.id);
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(req.user.id);
  A.createSession(res, req.user.id);
  res.json({ ok: true });
}));
r.delete('/me', A.requireUser, wrap((req, res) => {
  const u = db.prepare('SELECT password_hash, role FROM users WHERE id=?').get(req.user.id);
  if (!A.verifyPassword(String(req.body.password || ''), u.password_hash)) throw new HttpError(400, 'Your password is not right.');
  if (u.role === 'admin' && db.prepare("SELECT COUNT(*) n FROM users WHERE role='admin' AND disabled=0").get().n <= 1) throw new HttpError(400, 'You are the only administrator. Make someone else an administrator first.');
  db.prepare('DELETE FROM users WHERE id=?').run(req.user.id);
  A.destroySession(req, res);
  res.json({ ok: true });
}));

// ---------- catalog & lessons ----------
r.get('/catalog', (req, res) => { res.set('Cache-Control', 'no-cache'); res.json(C.catalog()); });

r.get('/lessons/:key', wrap((req, res) => {
  const l = C.lessonFull(req.params.key);
  if (!l) throw new HttpError(404, 'We couldn’t find that note. It may have been moved or unpublished.');
  if (!l.guest && !req.user) throw new HttpError(401, 'Log in or create a free account to read this note.', { preview: { title: l.title, summary: l.summary, subject: l.subject, grade: l.grade, number: l.number } });
  bump('lesson_view');
  let me = null;
  if (req.user) {
    const p = db.prepare('SELECT * FROM progress WHERE user_id=? AND lesson_id=?').get(req.user.id, l.id) || {};
    const bm = db.prepare('SELECT kind FROM bookmarks WHERE user_id=? AND lesson_id=?').all(req.user.id, l.id).map(x => x.kind);
    const best = db.prepare("SELECT MAX(score*100/total) best FROM quiz_attempts WHERE user_id=? AND lesson_id=? AND total>0").get(req.user.id, l.id).best;
    me = { completed: !!p.completed_at, revise: !!p.revise, lastTab: p.last_tab || null, bookmark: bm.includes('bookmark'), favorite: bm.includes('favorite'), bestQuiz: best };
  }
  res.json({ lesson: l, me });
}));

r.get('/subjects/:slug/timeline', wrap((req, res) => {
  const s = db.prepare('SELECT id,name FROM subjects WHERE slug=? AND published=1').get(req.params.slug);
  if (!s) throw new HttpError(404, 'Subject not found.');
  const rows = db.prepare(`SELECT e.label,e.year,e.title,e.detail,l.key,l.title lesson,l.grade,l.number,l.guest FROM events e JOIN lessons l ON l.id=e.lesson_id
    WHERE l.subject_id=? AND l.published=1 ORDER BY e.year, l.grade, l.number`).all(s.id);
  res.json({ subject: s, events: rows });
}));

// ---------- search ----------
r.get('/search', wrap((req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 120);
  const terms = q.toLowerCase().match(/[\p{L}\p{N}]+/gu) || [];
  const filters = [], args = [];
  if (req.query.grade) { filters.push('l.grade=?'); args.push(+req.query.grade); }
  if (req.query.subject) { filters.push('s.slug=?'); args.push(String(req.query.subject)); }
  if (req.query.unit) { filters.push('l.unit_id=?'); args.push(+req.query.unit); }
  const where = ['l.published=1', 's.published=1', ...filters].join(' AND ');
  let rows;
  if (terms.length) {
    const match = terms.slice(0, 8).map(t => `"${t}"*`).join(' ');
    rows = db.prepare(`SELECT l.id,l.key,l.title,l.summary,l.grade,l.number,l.image,l.guest,l.created_at,s.slug subject,s.name subject_name,s.color,u.title unit,
        snippet(lesson_fts, 2, char(1), char(2), '…', 18) snip, bm25(lesson_fts, 10.0, 4.0, 1.0, 3.0, 2.0, 1.0) rank
      FROM lesson_fts JOIN lessons l ON l.id=lesson_fts.rowid JOIN subjects s ON s.id=l.subject_id LEFT JOIN units u ON u.id=l.unit_id
      WHERE lesson_fts MATCH ? AND ${where} ORDER BY ${req.query.sort === 'recent' ? 'l.created_at DESC,' : ''} rank LIMIT 40`).all(match, ...args);
  } else if (filters.length || req.query.sort === 'recent') {
    rows = db.prepare(`SELECT l.id,l.key,l.title,l.summary,l.grade,l.number,l.image,l.guest,l.created_at,s.slug subject,s.name subject_name,s.color,u.title unit, NULL snip
      FROM lessons l JOIN subjects s ON s.id=l.subject_id LEFT JOIN units u ON u.id=l.unit_id WHERE ${where}
      ORDER BY ${req.query.sort === 'recent' ? 'l.created_at DESC,' : ''} l.grade, s.position, l.number LIMIT 60`).all(...args);
  } else rows = [];
  const escH = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  if (terms.length) bump('search');
  res.json({
    q, results: rows.map(x => ({
      key: x.key, title: x.title, grade: x.grade, number: x.number, subject: x.subject, subjectName: x.subject_name, color: x.color, unit: x.unit,
      guest: !!x.guest, image: C.J(x.image, null), createdAt: x.created_at,
      snippet: x.snip ? escH(x.snip).replace(/\u0001/g, '<mark>').replace(/\u0002/g, '</mark>') : escH(x.summary.slice(0, 180))
    }))
  });
}));

// ---------- bookmarks & progress ----------
const lessonId = id => { const l = db.prepare('SELECT id FROM lessons WHERE id=?').get(+id); if (!l) throw new HttpError(404, 'Note not found.'); return l.id; };

r.put('/bookmarks/:id/:kind', A.requireUser, wrap((req, res) => {
  const kind = req.params.kind; if (!['bookmark', 'favorite'].includes(kind)) throw new HttpError(400, 'Unknown bookmark type.');
  db.prepare('INSERT OR IGNORE INTO bookmarks(user_id,lesson_id,kind,created_at) VALUES(?,?,?,?)').run(req.user.id, lessonId(req.params.id), kind, now());
  res.json({ ok: true });
}));
r.delete('/bookmarks/:id/:kind', A.requireUser, wrap((req, res) => {
  db.prepare('DELETE FROM bookmarks WHERE user_id=? AND lesson_id=? AND kind=?').run(req.user.id, +req.params.id, req.params.kind);
  res.json({ ok: true });
}));

r.post('/progress/:id/view', A.requireUser, wrap((req, res) => {
  const id = lessonId(req.params.id); const t = now();
  const tab = typeof req.body.tab === 'string' ? req.body.tab.slice(0, 20) : null;
  db.prepare(`INSERT INTO progress(user_id,lesson_id,first_viewed_at,last_viewed_at,views,last_tab) VALUES(?,?,?,?,1,?)
    ON CONFLICT(user_id,lesson_id) DO UPDATE SET last_viewed_at=excluded.last_viewed_at, views=views+1, last_tab=COALESCE(excluded.last_tab,last_tab)`).run(req.user.id, id, t, t, tab);
  res.json({ ok: true });
}));
r.post('/progress/:id', A.requireUser, wrap((req, res) => {
  const id = lessonId(req.params.id); const t = now();
  db.prepare('INSERT OR IGNORE INTO progress(user_id,lesson_id,first_viewed_at,last_viewed_at,views) VALUES(?,?,?,?,0)').run(req.user.id, id, t, t);
  if (req.body.completed !== undefined) db.prepare('UPDATE progress SET completed_at=? WHERE user_id=? AND lesson_id=?').run(req.body.completed ? t : null, req.user.id, id);
  if (req.body.revise !== undefined) db.prepare('UPDATE progress SET revise=? WHERE user_id=? AND lesson_id=?').run(req.body.revise ? 1 : 0, req.user.id, id);
  if (req.body.completed) bump('lesson_complete');
  res.json({ ok: true });
}));

/** Everything the student's dashboard, bookmarks and progress pages need. */
r.get('/me/summary', A.requireUser, wrap((req, res) => {
  const uid = req.user.id;
  const progress = db.prepare('SELECT lesson_id id,first_viewed_at,last_viewed_at,views,last_tab,completed_at,revise FROM progress WHERE user_id=?').all(uid);
  const bookmarks = db.prepare('SELECT lesson_id id,kind,created_at FROM bookmarks WHERE user_id=? ORDER BY created_at DESC').all(uid);
  const quizzes = db.prepare(`SELECT q.id,q.lesson_id,q.kind,q.score,q.total,q.created_at,s.slug subject FROM quiz_attempts q LEFT JOIN subjects s ON s.id=q.subject_id
    WHERE q.user_id=? ORDER BY q.created_at DESC LIMIT 200`).all(uid);
  res.json({ progress, bookmarks, quizzes });
}));

// ---------- quizzes ----------
r.get('/practice', wrap((req, res) => {
  const n = Math.min(Math.max(+req.query.n || 10, 3), 30);
  const where = ['l.published=1'], args = [];
  if (!req.user) where.push('l.guest=1');
  if (req.query.subject) { where.push('s.slug=?'); args.push(String(req.query.subject)); }
  if (req.query.grade) { where.push('l.grade=?'); args.push(+req.query.grade); }
  if (req.query.lessons) { const ids = String(req.query.lessons).split(',').map(Number).filter(Boolean).slice(0, 50); if (ids.length) { where.push(`l.id IN (${ids.map(() => '?').join(',')})`); args.push(...ids); } }
  if (req.query.type === 'mcq' || req.query.type === 'tf') { where.push('q.type=?'); args.push(req.query.type); }
  if (req.query.origin === 'reviewed') where.push("(q.origin<>'generated' OR q.reviewed=1)");
  const rows = db.prepare(`SELECT q.id,q.type,q.prompt,q.options,q.answer,q.explanation,q.origin,q.reviewed,l.key,l.title lesson,l.id lesson_id FROM questions q
    JOIN lessons l ON l.id=q.lesson_id JOIN subjects s ON s.id=l.subject_id WHERE ${where.join(' AND ')} ORDER BY random() LIMIT ?`).all(...args, n);
  res.json({ questions: rows.map(q => ({ ...q, options: C.J(q.options, []) })) });
}));

r.post('/quiz/attempt', A.requireUser, wrap((req, res) => {
  const answers = req.body.answers;
  if (!answers || typeof answers !== 'object') throw new HttpError(400, 'No answers were sent.');
  const ids = Object.keys(answers).map(Number).filter(Boolean).slice(0, 60);
  if (!ids.length) throw new HttpError(400, 'Answer at least one question first.');
  const qs = db.prepare(`SELECT q.id,q.answer,l.subject_id,l.id lesson_id FROM questions q JOIN lessons l ON l.id=q.lesson_id WHERE q.id IN (${ids.map(() => '?').join(',')})`).all(...ids);
  const score = qs.filter(q => +answers[q.id] === q.answer).length;
  const lessonIds = [...new Set(qs.map(q => q.lesson_id))], subjectIds = [...new Set(qs.map(q => q.subject_id))];
  const kind = req.body.kind === 'practice' ? 'practice' : 'lesson';
  db.prepare('INSERT INTO quiz_attempts(user_id,lesson_id,kind,subject_id,score,total,created_at) VALUES(?,?,?,?,?,?,?)')
    .run(req.user.id, lessonIds.length === 1 ? lessonIds[0] : null, kind, subjectIds.length === 1 ? subjectIds[0] : null, score, qs.length, now());
  bump('quiz');
  res.json({ score, total: qs.length, correct: Object.fromEntries(qs.map(q => [q.id, q.answer])) });
}));

module.exports = { router: r, sendReset, wrap, str, emailOf, gradeOf, userById };
