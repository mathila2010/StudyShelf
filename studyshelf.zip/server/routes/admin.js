'use strict';
// Administrator API. Every route requires an admin session (mounted behind requireAdmin).
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const { db, now } = require('../db');
const config = require('../config');
const A = require('../auth');
const C = require('../content');
const U = require('../importer/util');
const { runImport } = require('../importer');
const mail = require('../mail');
const { wrap, str, sendReset } = require('./api');

const r = express.Router();
const { HttpError } = A;
const J = C.J;

const int = (v, name, { min = -1e9, max = 1e9 } = {}) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw new HttpError(400, `${name} must be a whole number${min > -1e9 ? ` from ${min}` : ''}${max < 1e9 ? ` to ${max}` : ''}.`);
  return n;
};
const color = v => { if (!/^#[0-9a-f]{6}$/i.test(String(v))) throw new HttpError(400, 'Colour must be a hex value like #2f5bd3.'); return v; };
const slugOk = v => { const s = String(v || '').trim().toLowerCase(); if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(s)) throw new HttpError(400, 'Use lowercase letters, numbers and dashes for the web address name (e.g. "english").'); return s; };
const requireConfirm = (req, word) => { if (String(req.body.confirm || '').trim().toLowerCase() !== String(word).toLowerCase()) throw new HttpError(400, `Type "${word}" to confirm.`); };

// ---------- dashboard ----------
r.get('/stats', wrap((req, res) => {
  const t = now(), week = t - 7 * 864e5;
  const days = [...Array(14)].map((_, i) => new Date(t - (13 - i) * 864e5).toISOString().slice(0, 10));
  const act = db.prepare('SELECT day,kind,count FROM activity WHERE day>=?').all(days[0]);
  const series = kind => days.map(d => (act.find(a => a.day === d && a.kind === kind) || { count: 0 }).count);
  const lastRun = db.prepare('SELECT * FROM import_runs ORDER BY id DESC LIMIT 1').get();
  res.json({
    users: db.prepare("SELECT SUM(role='student') students, SUM(role='admin') admins, SUM(created_at>?) new7, SUM(last_login_at>?) active7, SUM(disabled) disabled FROM users").get(week, week),
    content: db.prepare(`SELECT (SELECT COUNT(*) FROM subjects) subjects, (SELECT COUNT(*) FROM lessons) lessons, (SELECT COUNT(*) FROM lessons WHERE published=0) unpublished,
      (SELECT COUNT(*) FROM lessons WHERE locked=1) edited, (SELECT COUNT(*) FROM flashcards) flashcards, (SELECT COUNT(*) FROM questions) questions,
      (SELECT COUNT(*) FROM questions WHERE origin='generated' AND reviewed=0) unreviewed, (SELECT COUNT(*) FROM media) media`).get(),
    activity: { days, views: series('lesson_view'), logins: series('login'), signups: series('signup'), quizzes: series('quiz'), searches: series('search') },
    topLessons: db.prepare(`SELECT l.key,l.title,l.grade,s.name subject,SUM(p.views) views,COUNT(p.completed_at) completions FROM progress p JOIN lessons l ON l.id=p.lesson_id
      JOIN subjects s ON s.id=l.subject_id GROUP BY l.id ORDER BY views DESC LIMIT 8`).all(),
    import: lastRun ? { ...lastRun, summary: J(lastRun.summary, {}), open: db.prepare("SELECT COUNT(*) n FROM import_logs WHERE run_id=? AND level IN ('warn','error') AND resolved=0").get(lastRun.id).n } : null,
    mailConfigured: mail.configured()
  });
}));

// ---------- subjects ----------
r.get('/subjects', wrap((req, res) => {
  res.json({ subjects: db.prepare('SELECT s.*, (SELECT COUNT(*) FROM lessons l WHERE l.subject_id=s.id) lessons FROM subjects s ORDER BY position, name').all(),
    units: db.prepare('SELECT u.*, (SELECT COUNT(*) FROM lessons l WHERE l.unit_id=u.id) lessons FROM units u ORDER BY subject_id, grade, position').all() });
}));
r.post('/subjects', wrap((req, res) => {
  const b = req.body;
  const s = { slug: slugOk(b.slug || b.name), name: str(b.name, { min: 2, max: 60, name: 'subject name' }), icon: str(b.icon || 'book', { max: 20, name: 'icon' }),
    color: color(b.color || '#2f5bd3'), description: str(b.description || '', { max: 400, name: 'description' }) };
  if (db.prepare('SELECT 1 FROM subjects WHERE slug=?').get(s.slug)) throw new HttpError(409, 'A subject with that web address name already exists.');
  s.position = db.prepare('SELECT COALESCE(MAX(position),0)+1 p FROM subjects').get().p;
  const id = db.prepare('INSERT INTO subjects(slug,name,icon,color,description,position) VALUES(@slug,@name,@icon,@color,@description,@position)').run(s).lastInsertRowid;
  C.invalidate(); res.status(201).json({ id });
}));
r.patch('/subjects/:id', wrap((req, res) => {
  const cur = db.prepare('SELECT * FROM subjects WHERE id=?').get(+req.params.id); if (!cur) throw new HttpError(404, 'Subject not found.');
  const b = req.body;
  const s = {
    id: cur.id, name: b.name !== undefined ? str(b.name, { min: 2, max: 60, name: 'subject name' }) : cur.name,
    icon: b.icon !== undefined ? str(b.icon, { max: 20, name: 'icon' }) : cur.icon, color: b.color !== undefined ? color(b.color) : cur.color,
    description: b.description !== undefined ? str(b.description, { max: 400, name: 'description' }) : cur.description,
    position: b.position !== undefined ? int(b.position, 'Position', { min: 0, max: 999 }) : cur.position,
    published: b.published !== undefined ? (b.published ? 1 : 0) : cur.published
  };
  db.prepare('UPDATE subjects SET name=@name,icon=@icon,color=@color,description=@description,position=@position,published=@published WHERE id=@id').run(s);
  db.prepare('SELECT id FROM lessons WHERE subject_id=?').all(cur.id).forEach(l => C.indexLesson(l.id));
  C.invalidate(); res.json({ ok: true });
}));
r.delete('/subjects/:id', wrap((req, res) => {
  const cur = db.prepare('SELECT * FROM subjects WHERE id=?').get(+req.params.id); if (!cur) throw new HttpError(404, 'Subject not found.');
  requireConfirm(req, cur.slug);
  const ids = db.prepare('SELECT id FROM lessons WHERE subject_id=?').all(cur.id);
  db.transaction(() => { ids.forEach(l => db.prepare('DELETE FROM lesson_fts WHERE rowid=?').run(l.id)); db.prepare('DELETE FROM subjects WHERE id=?').run(cur.id); })();
  C.invalidate(); res.json({ ok: true, deletedLessons: ids.length });
}));

// ---------- units ----------
r.post('/units', wrap((req, res) => {
  const sid = int(req.body.subjectId, 'Subject'); if (!db.prepare('SELECT 1 FROM subjects WHERE id=?').get(sid)) throw new HttpError(400, 'Choose a subject.');
  const grade = int(req.body.grade, 'Grade', { min: 1, max: 13 });
  const title = str(req.body.title, { min: 2, max: 80, name: 'unit title' });
  if (db.prepare('SELECT 1 FROM units WHERE subject_id=? AND grade=? AND title=?').get(sid, grade, title)) throw new HttpError(409, 'That unit already exists for this subject and grade.');
  const id = C.ensureUnit(sid, grade, title); C.invalidate(); res.status(201).json({ id });
}));
r.patch('/units/:id', wrap((req, res) => {
  const u = db.prepare('SELECT * FROM units WHERE id=?').get(+req.params.id); if (!u) throw new HttpError(404, 'Unit not found.');
  const title = req.body.title !== undefined ? str(req.body.title, { min: 2, max: 80, name: 'unit title' }) : u.title;
  const position = req.body.position !== undefined ? int(req.body.position, 'Position', { min: 0, max: 999 }) : u.position;
  db.prepare('UPDATE units SET title=?, position=? WHERE id=?').run(title, position, u.id);
  db.prepare('SELECT id FROM lessons WHERE unit_id=?').all(u.id).forEach(l => C.indexLesson(l.id));
  C.invalidate(); res.json({ ok: true });
}));
r.delete('/units/:id', wrap((req, res) => {
  const u = db.prepare('SELECT * FROM units WHERE id=?').get(+req.params.id); if (!u) throw new HttpError(404, 'Unit not found.');
  db.prepare('DELETE FROM units WHERE id=?').run(u.id); C.invalidate(); res.json({ ok: true });
}));

// ---------- lessons ----------
r.get('/lessons', wrap((req, res) => {
  res.json({ lessons: db.prepare(`SELECT l.id,l.key,l.title,l.grade,l.number,l.published,l.guest,l.locked,l.difficulty,l.updated_at,l.created_at,l.subject_id,l.unit_id,s.name subject,u.title unit,
    (SELECT COUNT(*) FROM questions q WHERE q.lesson_id=l.id) questions, (SELECT COUNT(*) FROM questions q WHERE q.lesson_id=l.id AND q.origin='generated' AND q.reviewed=0) unreviewed,
    (SELECT COUNT(*) FROM flashcards f WHERE f.lesson_id=l.id) cards, (SELECT group_concat(kind) FROM notes n WHERE n.lesson_id=l.id) kinds
    FROM lessons l JOIN subjects s ON s.id=l.subject_id LEFT JOIN units u ON u.id=l.unit_id ORDER BY s.position, l.grade, l.number`).all() });
}));
r.get('/lessons/:key', wrap((req, res) => {
  const l = C.lessonFull(req.params.key, { includeUnpublished: true }); if (!l) throw new HttpError(404, 'Note not found.');
  res.json({ lesson: l });
}));

function lessonFields(b, cur = {}) {
  const f = {};
  if (b.subjectId !== undefined || !cur.id) { f.subject_id = int(b.subjectId, 'Subject'); if (!db.prepare('SELECT 1 FROM subjects WHERE id=?').get(f.subject_id)) throw new HttpError(400, 'Choose a subject.'); }
  if (b.grade !== undefined || !cur.id) f.grade = int(b.grade, 'Grade', { min: 1, max: 13 });
  if (b.number !== undefined || !cur.id) f.number = int(b.number ?? 0, 'Lesson number', { min: 0, max: 999 });
  if (b.title !== undefined || !cur.id) f.title = str(b.title, { min: 2, max: 140, name: 'title' });
  if (b.summary !== undefined) f.summary = str(b.summary, { max: 1000, name: 'summary' });
  if (b.hook !== undefined) f.hook = str(b.hook, { max: 300, name: 'hook line' });
  if (b.unitId !== undefined) f.unit_id = b.unitId ? int(b.unitId, 'Unit') : null;
  if (b.unitTitle) f.unit_id = C.ensureUnit(f.subject_id || cur.subject_id, f.grade || cur.grade, str(b.unitTitle, { min: 2, max: 80, name: 'unit title' }));
  if (b.difficulty !== undefined) { if (b.difficulty && !['foundation', 'core', 'extension'].includes(b.difficulty)) throw new HttpError(400, 'Difficulty must be foundation, core or extension.'); f.difficulty = b.difficulty || null; }
  if (b.guest !== undefined) f.guest = b.guest ? 1 : 0;
  if (b.published !== undefined) f.published = b.published ? 1 : 0;
  if (b.image !== undefined) f.image = b.image && b.image.url ? JSON.stringify({ url: String(b.image.url).slice(0, 300), alt: String(b.image.alt || '').slice(0, 300), caption: String(b.image.caption || '').slice(0, 300) }) : null;
  return f;
}
r.post('/lessons', wrap((req, res) => {
  const f = lessonFields(req.body);
  const subj = db.prepare('SELECT slug FROM subjects WHERE id=?').get(f.subject_id).slug;
  let key = `${subj}-g${f.grade}-${U.slug(f.title)}`; let i = 1;
  while (db.prepare('SELECT 1 FROM lessons WHERE key=?').get(key)) key = `${subj}-g${f.grade}-${U.slug(f.title)}-${++i}`;
  const t = now();
  const id = db.prepare(`INSERT INTO lessons(key,subject_id,unit_id,grade,number,title,summary,hook,difficulty,guest,published,locked,sources,created_at,updated_at)
    VALUES(@key,@subject_id,@unit_id,@grade,@number,@title,@summary,@hook,@difficulty,@guest,@published,1,'["manual"]',@t,@t)`)
    .run({ key, unit_id: null, summary: '', hook: '', difficulty: null, guest: 0, published: 0, ...f, t }).lastInsertRowid;
  db.prepare('INSERT INTO notes(lesson_id,kind,title,html,text,toc,position,updated_at) VALUES(?,?,?,?,?,?,0,?)').run(id, 'notes', 'Notes', '<section><h2>Introduction</h2><p>Start writing here.</p></section>', 'Introduction Start writing here.', '[]', t);
  C.indexLesson(id); C.invalidate();
  res.status(201).json({ id, key });
}));
r.patch('/lessons/:id', wrap((req, res) => {
  const cur = db.prepare('SELECT * FROM lessons WHERE id=?').get(+req.params.id); if (!cur) throw new HttpError(404, 'Note not found.');
  const f = lessonFields(req.body, cur);
  if (!Object.keys(f).length) return res.json({ ok: true });
  const keys = Object.keys(f);
  const metaOnly = keys.every(k => ['published', 'guest', 'difficulty'].includes(k));
  db.prepare(`UPDATE lessons SET ${keys.map(k => `${k}=@${k}`).join(',')}, updated_at=@t${metaOnly ? '' : ', locked=1'} WHERE id=@id`).run({ ...f, t: now(), id: cur.id });
  if (req.body.locked === false) db.prepare('UPDATE lessons SET locked=0 WHERE id=?').run(cur.id);
  C.indexLesson(cur.id); C.invalidate(); res.json({ ok: true });
}));
r.delete('/lessons/:id', wrap((req, res) => {
  const cur = db.prepare('SELECT * FROM lessons WHERE id=?').get(+req.params.id); if (!cur) throw new HttpError(404, 'Note not found.');
  requireConfirm(req, 'delete');
  db.prepare('DELETE FROM lesson_fts WHERE rowid=?').run(cur.id); db.prepare('DELETE FROM lessons WHERE id=?').run(cur.id);
  C.invalidate(); res.json({ ok: true });
}));

/** Sanitize admin-written note HTML, give every <h2> an id, and return the TOC. */
function prepareNote(html, prefix) {
  const { html: clean, removed } = U.sanitizeReport(String(html || ''));
  const { root, html: out } = U.frag(clean);
  const toc = []; let i = 0;
  root.querySelectorAll('h2').forEach(h => { i++; const id = `${prefix}-h${i}`; h.id = id; toc.push({ id, title: h.textContent.replace(/\s+/g, ' ').trim() }); });
  root.querySelectorAll('section').forEach(s => s.removeAttribute('id'));
  const h = out();
  return { html: h, toc, text: U.textOf(h), removed };
}
r.put('/lessons/:id/notes', wrap((req, res) => {
  const cur = db.prepare('SELECT * FROM lessons WHERE id=?').get(+req.params.id); if (!cur) throw new HttpError(404, 'Note not found.');
  const list = req.body.notes;
  if (!Array.isArray(list) || !list.length || list.length > 6) throw new HttpError(400, 'A lesson needs between 1 and 6 note tabs.');
  const t = now();
  const prepared = list.map((n, i) => {
    const kind = ['short', 'detailed', 'notes'].includes(n.kind) ? n.kind : 'notes';
    const title = str(n.title || 'Notes', { min: 1, max: 40, name: 'tab name' });
    if (String(n.html || '').length > 2_000_000) throw new HttpError(413, `"${title}" is too large (2 MB limit).`);
    return { id: n.id, kind, title, scope: n.scope || null, ...prepareNote(n.html, `${cur.key}-${i}`) };
  });
  db.transaction(() => {
    const keep = prepared.filter(n => n.id).map(n => +n.id);
    db.prepare(`DELETE FROM notes WHERE lesson_id=? ${keep.length ? `AND id NOT IN (${keep.join(',')})` : ''}`).run(cur.id);
    prepared.forEach((n, i) => {
      const exists = n.id && db.prepare('SELECT scope FROM notes WHERE id=? AND lesson_id=?').get(+n.id, cur.id);
      if (exists) db.prepare('UPDATE notes SET kind=?,title=?,html=?,text=?,toc=?,position=?,updated_at=? WHERE id=?').run(n.kind, n.title, n.html, n.text, JSON.stringify(n.toc), i, t, +n.id);
      else db.prepare('INSERT INTO notes(lesson_id,kind,title,html,text,toc,scope,position,updated_at) VALUES(?,?,?,?,?,?,?,?,?)').run(cur.id, n.kind, n.title, n.html, n.text, JSON.stringify(n.toc), null, i, t);
    });
    db.prepare('UPDATE lessons SET locked=1, updated_at=? WHERE id=?').run(t, cur.id);
  })();
  C.indexLesson(cur.id); C.invalidate();
  res.json({ ok: true, removed: prepared.reduce((a, n) => a + n.removed, 0) });
}));

function syncList(table, lessonId, items, mapRow) {
  const existing = new Set(db.prepare(`SELECT id FROM ${table} WHERE lesson_id=?`).all(lessonId).map(r => r.id));
  const keep = new Set();
  items.forEach((it, i) => {
    const row = mapRow(it, i);
    if (it.id && existing.has(+it.id)) {
      keep.add(+it.id);
      db.prepare(`UPDATE ${table} SET ${Object.keys(row).map(k => `${k}=@${k}`).join(',')} WHERE id=@id`).run({ ...row, id: +it.id });
    } else db.prepare(`INSERT INTO ${table}(lesson_id,${Object.keys(row).join(',')}) VALUES(@lesson_id,${Object.keys(row).map(k => '@' + k).join(',')})`).run({ ...row, lesson_id: lessonId });
  });
  existing.forEach(id => { if (!keep.has(id)) db.prepare(`DELETE FROM ${table} WHERE id=?`).run(id); });
}
r.put('/lessons/:id/flashcards', wrap((req, res) => {
  const cur = db.prepare('SELECT id FROM lessons WHERE id=?').get(+req.params.id); if (!cur) throw new HttpError(404, 'Note not found.');
  const items = req.body.flashcards; if (!Array.isArray(items) || items.length > 300) throw new HttpError(400, 'Send a list of flashcards (300 at most).');
  db.transaction(() => syncList('flashcards', cur.id, items, (f, i) => ({
    front: U.sanitize(str(f.front, { min: 1, max: 2000, name: `front of card ${i + 1}` })), back: U.sanitize(str(f.back, { min: 1, max: 4000, name: `back of card ${i + 1}` })),
    origin: ['imported', 'extracted', 'generated', 'manual'].includes(f.origin) ? f.origin : 'manual', reviewed: f.reviewed ? 1 : 0, position: i
  })))();
  C.indexLesson(cur.id); C.invalidate(); res.json({ ok: true });
}));
r.put('/lessons/:id/questions', wrap((req, res) => {
  const cur = db.prepare('SELECT id FROM lessons WHERE id=?').get(+req.params.id); if (!cur) throw new HttpError(404, 'Note not found.');
  const items = req.body.questions; if (!Array.isArray(items) || items.length > 300) throw new HttpError(400, 'Send a list of questions (300 at most).');
  db.transaction(() => syncList('questions', cur.id, items, (q, i) => {
    const type = q.type === 'tf' ? 'tf' : 'mcq';
    const options = type === 'tf' ? ['True', 'False'] : (Array.isArray(q.options) ? q.options : []).map(o => U.sanitize(String(o).trim())).filter(Boolean);
    if (options.length < 2 || options.length > 6) throw new HttpError(400, `Question ${i + 1} needs 2 to 6 answer options.`);
    const answer = int(q.answer, `Correct answer for question ${i + 1}`, { min: 0, max: options.length - 1 });
    return { type, prompt: U.sanitize(str(q.prompt, { min: 3, max: 2000, name: `question ${i + 1}` })), options: JSON.stringify(options), answer,
      explanation: U.sanitize(String(q.explanation || '').slice(0, 3000)), origin: ['imported', 'generated', 'manual'].includes(q.origin) ? q.origin : 'manual', reviewed: q.reviewed ? 1 : 0, position: i };
  }))();
  C.invalidate(); res.json({ ok: true });
}));

// ---------- media ----------
const ALLOWED = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/svg+xml': 'svg', 'application/pdf': 'pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx', 'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx' };
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: config.maxUploadMb * 1024 * 1024, files: 10 } });
r.get('/media', wrap((req, res) => res.json({ media: db.prepare('SELECT * FROM media ORDER BY created_at DESC, id DESC LIMIT 500').all() })));
r.post('/media', upload.array('files', 10), wrap((req, res) => {
  if (!req.files || !req.files.length) throw new HttpError(400, 'Choose at least one file to upload.');
  const out = [];
  for (const f of req.files) {
    const ext = ALLOWED[f.mimetype];
    if (!ext) throw new HttpError(415, `"${f.originalname}" is a ${f.mimetype || 'unknown'} file. Upload images (JPG, PNG, WebP, GIF, SVG), PDF, Word or PowerPoint files.`);
    let buf = f.buffer;
    if (ext === 'svg') buf = Buffer.from(U.sanitize(buf.toString('utf8')));
    const name = `${U.slug(path.parse(f.originalname).name)}-${crypto.randomBytes(4).toString('hex')}.${ext}`;
    const dir = path.join(config.mediaDir, 'uploads'); fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, name), buf);
    const url = `/media/uploads/${name}`;
    const id = db.prepare("INSERT INTO media(url,name,type,bytes,origin,uploaded_by,created_at) VALUES(?,?,?,?,'upload',?,?)").run(url, f.originalname.slice(0, 200), f.mimetype, buf.length, req.user.id, now()).lastInsertRowid;
    out.push({ id, url, name: f.originalname, type: f.mimetype });
  }
  res.status(201).json({ media: out });
}));
r.delete('/media/:id', wrap((req, res) => {
  const m = db.prepare('SELECT * FROM media WHERE id=?').get(+req.params.id); if (!m) throw new HttpError(404, 'File not found.');
  const used = db.prepare('SELECT COUNT(*) n FROM notes WHERE html LIKE ?').get(`%${m.url}%`).n + db.prepare('SELECT COUNT(*) n FROM lessons WHERE image LIKE ?').get(`%${m.url}%`).n;
  if (used && req.body.confirm !== 'delete') throw new HttpError(409, `This file is used in ${used} note(s). Type "delete" to remove it anyway.`);
  const fp = path.join(config.mediaDir, m.url.replace(/^\/media\//, ''));
  if (fp.startsWith(config.mediaDir) && fs.existsSync(fp)) fs.unlinkSync(fp);
  db.prepare('DELETE FROM media WHERE id=?').run(m.id); res.json({ ok: true });
}));

// ---------- users ----------
r.get('/users', wrap((req, res) => {
  const q = `%${String(req.query.q || '').trim()}%`;
  res.json({ users: db.prepare(`SELECT u.id,u.name,u.email,u.role,u.grade,u.disabled,u.created_at,u.last_login_at,
    (SELECT COUNT(*) FROM progress p WHERE p.user_id=u.id AND p.completed_at IS NOT NULL) completed FROM users u
    WHERE u.name LIKE ? OR u.email LIKE ? ORDER BY u.created_at DESC LIMIT 500`).all(q, q) });
}));
const adminsLeft = exceptId => db.prepare("SELECT COUNT(*) n FROM users WHERE role='admin' AND disabled=0 AND id<>?").get(exceptId).n;
r.patch('/users/:id', wrap((req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(+req.params.id); if (!u) throw new HttpError(404, 'User not found.');
  const b = req.body;
  if (b.role !== undefined && !['student', 'admin'].includes(b.role)) throw new HttpError(400, 'Role must be student or admin.');
  const losingAdmin = u.role === 'admin' && ((b.role && b.role !== 'admin') || b.disabled);
  if (losingAdmin && !adminsLeft(u.id)) throw new HttpError(400, 'At least one active administrator is needed.');
  if (u.id === req.user.id && b.disabled) throw new HttpError(400, 'You can’t turn off your own account.');
  db.prepare('UPDATE users SET role=?, disabled=?, grade=?, name=? WHERE id=?').run(b.role ?? u.role, b.disabled !== undefined ? (b.disabled ? 1 : 0) : u.disabled,
    b.grade !== undefined ? (b.grade ? int(b.grade, 'Grade', { min: 1, max: 13 }) : null) : u.grade, b.name !== undefined ? str(b.name, { min: 1, max: 60, name: 'name' }) : u.name, u.id);
  if (b.disabled) db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
  res.json({ ok: true });
}));
r.post('/users/:id/reset', wrap(async (req, res) => {
  const u = db.prepare('SELECT id,name,email FROM users WHERE id=?').get(+req.params.id); if (!u) throw new HttpError(404, 'User not found.');
  const link = await sendReset(u);
  // Without email set up, the admin gets the link to pass on in person.
  res.json(mail.configured() ? { ok: true, message: `Reset email sent to ${u.email}.` } : { ok: true, link, message: 'Email isn’t set up, so copy this one-hour link and give it to the student.' });
}));
r.delete('/users/:id', wrap((req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(+req.params.id); if (!u) throw new HttpError(404, 'User not found.');
  requireConfirm(req, 'delete');
  if (u.id === req.user.id) throw new HttpError(400, 'Delete your own account from your profile page instead.');
  if (u.role === 'admin' && !adminsLeft(u.id)) throw new HttpError(400, 'At least one active administrator is needed.');
  db.prepare('DELETE FROM users WHERE id=?').run(u.id); res.json({ ok: true });
}));

// ---------- import ----------
r.get('/import', wrap((req, res) => {
  const runs = db.prepare('SELECT * FROM import_runs ORDER BY id DESC LIMIT 20').all().map(x => ({ ...x, summary: J(x.summary, {}) }));
  const runId = +req.query.run || (runs[0] && runs[0].id);
  const logs = runId ? db.prepare('SELECT * FROM import_logs WHERE run_id=? ORDER BY CASE level WHEN \'error\' THEN 0 WHEN \'warn\' THEN 1 WHEN \'duplicate\' THEN 2 ELSE 3 END, id').all(runId) : [];
  fs.mkdirSync(config.sourcesDir, { recursive: true });
  const sources = fs.readdirSync(config.sourcesDir).filter(f => /\.html?$/i.test(f)).map(f => { const st = fs.statSync(path.join(config.sourcesDir, f)); return { file: f, bytes: st.size, modified: st.mtimeMs }; });
  res.json({ runs, runId, logs, sources });
}));
let importing = false;
async function doImport(userId) {
  if (importing) throw new HttpError(409, 'An import is already running. Wait for it to finish.');
  importing = true;
  const runId = db.prepare('INSERT INTO import_runs(started_at,triggered_by) VALUES(?,?)').run(now(), userId || null).lastInsertRowid;
  try {
    const pkg = runImport(config.sourcesDir, { mediaDir: config.mediaDir, mediaUrl: '/media' });
    const applied = C.applyPackage(pkg, runId);
    const logs = [...pkg.logs, ...applied.logs];
    const ins = db.prepare('INSERT INTO import_logs(run_id,level,source,message,ref) VALUES(?,?,?,?,?)');
    db.transaction(() => logs.forEach(l => ins.run(runId, l.level, l.source, l.message, l.ref)))();
    const count = lvl => logs.filter(l => l.level === lvl).length;
    const summary = { lessons: pkg.lessons.length, ...applied.stats, media: pkg.media.length, sources: pkg.sources, errors: count('error'), warnings: count('warn'), duplicates: count('duplicate'), ms: pkg.ms };
    db.prepare('UPDATE import_runs SET finished_at=?, status=?, summary=? WHERE id=?').run(now(), summary.errors ? 'finished_with_errors' : 'ok', JSON.stringify(summary), runId);
    return { runId, summary };
  } catch (e) {
    db.prepare('INSERT INTO import_logs(run_id,level,message) VALUES(?,?,?)').run(runId, 'error', `Import stopped: ${e.message}`);
    db.prepare("UPDATE import_runs SET finished_at=?, status='failed' WHERE id=?").run(now(), runId);
    throw new HttpError(500, `The import stopped with an error: ${e.message}`);
  } finally { importing = false; }
}
r.post('/import/run', wrap(async (req, res) => res.json(await doImport(req.user.id))));
const srcUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 40 * 1024 * 1024, files: 10 } });
r.post('/import/sources', srcUpload.array('files', 10), wrap((req, res) => {
  if (!req.files || !req.files.length) throw new HttpError(400, 'Choose at least one .html file.');
  const saved = [];
  for (const f of req.files) {
    if (!/\.html?$/i.test(f.originalname)) throw new HttpError(415, `"${f.originalname}" is not an .html file. Save the notes website as a single HTML page first.`);
    const name = U.slug(path.parse(f.originalname).name) + '.html';
    fs.mkdirSync(config.sourcesDir, { recursive: true });
    fs.writeFileSync(path.join(config.sourcesDir, name), f.buffer); saved.push(name);
  }
  res.status(201).json({ saved, message: 'Saved. Run the import to bring the notes into the library.' });
}));
r.delete('/import/sources/:file', wrap((req, res) => {
  const name = path.basename(req.params.file); const fp = path.join(config.sourcesDir, name);
  if (!fs.existsSync(fp)) throw new HttpError(404, 'Source file not found.');
  requireConfirm(req, 'delete'); fs.unlinkSync(fp); res.json({ ok: true });
}));
r.patch('/import/logs/:id', wrap((req, res) => {
  db.prepare('UPDATE import_logs SET resolved=? WHERE id=?').run(req.body.resolved ? 1 : 0, +req.params.id); res.json({ ok: true });
}));

module.exports = { router: r, doImport };
